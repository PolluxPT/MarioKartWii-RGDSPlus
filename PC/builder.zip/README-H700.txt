MARIO KART WII 3DS -> H700 HANDHELD: BUILD THE GAME FILES (PC, once)
=====================================================================
This folder holds no game files. It converts your own USA Mario Kart Wii disc
(RMCE01) into the files the H700 port needs. The PAL/Europe disc does not work.

BEFORE YOU START
- Windows PC or Mac, about 15 GB free, internet connection.
- Your USA disc as .iso or .wbfs. If it is .rvz or NKit: open Dolphin
  (https://dolphin-emu.org/download/), right-click the game > Convert File >
  Format: ISO.

INSTALL THESE FOUR TOOLS ONCE (accept defaults unless noted)
1. Git
   Windows: https://git-scm.com/download/win   Mac: https://git-scm.com/download/mac
   Run the installer, Next through everything.
2. Python 3.12 or 3.13 (3.11-3.14 work; 3.15 is NOT supported yet)
   https://www.python.org/downloads/  -> "Looking for a specific release" ->
   e.g. Python 3.13.x -> Windows installer (64-bit).
   On the FIRST installer screen tick "Add python.exe to PATH", then Install.
3. Node.js LTS
   https://nodejs.org  -> download the LTS version, Next through everything.
4. devkitPro, 3DS tools (only its small "tex3ds" texture tool is used)
   Windows: https://github.com/devkitPro/installer/releases/latest
     download devkitProUpdater-*.exe, run it, tick "3DS Development"
     (untick the rest), keep the folder C:\devkitPro.
   Mac: https://github.com/devkitPro/pacman/releases/latest  install the .pkg,
     then in Terminal:  sudo dkp-pacman -S 3ds-dev

BUILD
1. Unzip this builder somewhere simple, e.g. C:\mkw3ds-builder
   (not inside OneDrive/Dropbox/iCloud).
2. Windows: double-click "Build MKW H700.bat".
   Mac: double-click "Build MKW H700.command" (if macOS blocks it:
   System Settings > Privacy & Security > Open Anyway).
3. A black window asks for your disc: DRAG THE ISO FILE INTO THE WINDOW and
   press Enter.
4. Wait about an hour. It first downloads a few helper projects, then checks
   the disc, then converts everything. A few silent minutes at the start is
   normal. When it prints "done", the files are in:
       build\release\sd-card\3ds\mkw-3ds
   If it stops with an error, double-click the .bat again: finished steps are
   skipped. Fails twice? Send build-h700-log.txt from this folder.

COPY TO THE HANDHELD
1. Unzip the port zip (mkw3ds-h700-*.zip) into your PORTS folder on the SD
   card: "Mario Kart Wii 3DS.sh" and the "mkw3ds" folder.
2. Copy the whole "3ds" folder (build\release\sd-card\3ds) into ports\mkw3ds\
   so that this file exists:   ports\mkw3ds\3ds\mkw-3ds\content.txt
3. Launch "Mario Kart Wii 3DS" from the Ports list.
   If it won't start, send ports/mkw3ds/log.txt.

The game files belong to the port version they were built with. If a later
port update needs new files, its notes will say so.

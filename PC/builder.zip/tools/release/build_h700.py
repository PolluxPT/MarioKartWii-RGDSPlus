#!/usr/bin/env python3
"""Mario Kart Wii 3DS -> H700 handheld port: convert the game files from your own USA disc.

    python tools/release/build_h700.py "Mario Kart Wii (USA).iso"

Runs the same conversion steps as the 3DS builder (build_cia.py) and stops before anything
3DS-specific: no CIA, no 3DS code. The result is a folder of game files for the handheld:

    build/release/sd-card/3ds/mkw-3ds

Copy that folder into the port on the handheld's SD card (see README-H700.txt).
"""
import argparse, os, shutil, sys
from pathlib import Path
HERE=Path(__file__).parent
sys.path[:0]=[str(HERE), str(HERE.parents[1]/'tools')]
import build_cia as b

def stage_tools_h700():
    if not ((3,11) <= sys.version_info[:2] < (3,15)):
        raise SystemExit(f'Python 3.11 through 3.14 is required; running {sys.version.split()[0]} at {sys.executable}.')
    from devkitpro import tool
    if not tool('tex3ds').exists():
        raise SystemExit(f"Missing {tool('tex3ds')}: install devkitPro with the 3DS tools (https://devkitpro.org/wiki/Getting_Started); only its tex3ds texture converter is used.")
    missing=[m for m in ('numpy','PIL','Crypto') if not __import__('importlib.util').util.find_spec(m)]
    if missing:raise SystemExit(f'Missing Python packages {", ".join(missing)} in {sys.executable}: run "{sys.executable}" -m pip install -r requirements.txt')
    if not shutil.which('node'):raise SystemExit('Missing Node.js (https://nodejs.org), used by the model exporters')

def stage_package_h700():
    placeholder=b.ROOT/'build/mkw-3ds.3dsx'
    made=False
    if not placeholder.is_file():placeholder.parent.mkdir(parents=True,exist_ok=True);placeholder.write_bytes(b'');made=True
    b.run([sys.executable,'tools/package_sd.py','--no-zip'])
    if made:placeholder.unlink(missing_ok=True)
    out=b.SD_OUTPUT
    shutil.rmtree(out,ignore_errors=True)
    shutil.move(str(b.ROOT/'build/playable'),str(out))
    (out/'3ds/mkw-3ds/mkw-3ds.3dsx').unlink(missing_ok=True)
    (out/'3ds/mkw-3ds/content.txt').write_text(b.content_fingerprint()+'\n')
    return out/'3ds/mkw-3ds'

def main():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('disc',nargs='?',type=Path,help='your Mario Kart Wii (USA) ISO or WBFS')
    p.add_argument('--jobs',type=int,default=max(1,(os.cpu_count() or 2)-1))
    p.add_argument('--force-cook',action='store_true',help='re-run every conversion step')
    a=p.parse_args()
    stage_tools_h700();b.stage_sources();b.stage_disc(a.disc);b.check_game_code(a.disc);b.stage_cook(a.disc,a.jobs,a.force_cook)
    folder=stage_package_h700()
    b.log('done. Game files for the H700 port:',folder)
    b.log('Copy the whole "mkw-3ds" folder into ports/mkw3ds/ on the handheld SD card (README-H700.txt).')

if __name__=='__main__':main()

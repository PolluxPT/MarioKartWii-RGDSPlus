// Renders a textured quad through the shim's scene shader and dumps the window: checks the GL
// plumbing, texture untiling, TexEnv evaluation and the screen rotation without game assets.
#include <3ds.h>
#include <citro3d.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include "../src/shim.hpp"
#include "../../gen/shader_data.hpp"

extern "C" void shim_set_minimap_visible(bool on);
struct Vertex { float pos[3]; float normal[3]; float uv[4]; unsigned char color[4]; };

static unsigned morton(unsigned x, unsigned y) { return (x & 1) | ((y & 1) << 1) | ((x & 2) << 1) | ((y & 2) << 2) | ((x & 4) << 2) | ((y & 4) << 3); }

int main() {
  if (!shim::platform_init()) return 1;
  gfxInitDefault();
  if (!C3D_Init(0x100000)) return 1;
  C3D_RenderTarget* top = C3D_RenderTargetCreate(240, 400, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
  C3D_RenderTargetSetOutput(top, GFX_TOP, GFX_LEFT, 0);
  C3D_RenderTarget* bottom = C3D_RenderTargetCreate(240, 320, GPU_RB_RGBA8, C3D_DEPTHTYPE(-1));
  C3D_RenderTargetSetOutput(bottom, GFX_BOTTOM, GFX_LEFT, 0);
  DVLB_s* dvlb = DVLB_ParseFile(reinterpret_cast<u32*>(const_cast<uint8_t*>(mkw_shader)), sizeof mkw_shader);
  shaderProgram_s program; shaderProgramInit(&program); shaderProgramSetVsh(&program, &dvlb->DVLE[0]);
  const int projLoc = shaderInstanceGetUniformLocation(program.vertexShader, "projection");
  const int mvLoc = shaderInstanceGetUniformLocation(program.vertexShader, "modelView");
  const int lightLoc = shaderInstanceGetUniformLocation(program.vertexShader, "light");
  const int lightDirLoc = shaderInstanceGetUniformLocation(program.vertexShader, "lightDir");
  const int tintLoc = shaderInstanceGetUniformLocation(program.vertexShader, "tint");
  const int uvRow0 = shaderInstanceGetUniformLocation(program.vertexShader, "uvRow0");
  const int uvRow1 = shaderInstanceGetUniformLocation(program.vertexShader, "uvRow1");
  const int uv1Row0 = shaderInstanceGetUniformLocation(program.vertexShader, "uv1Row0");
  const int uv1Row1 = shaderInstanceGetUniformLocation(program.vertexShader, "uv1Row1");
  std::printf("locs %d %d %d %d %d\n", projLoc, mvLoc, lightLoc, tintLoc, uvRow0);
  // 64x64 RGBA8 texture in PICA tiled layout: red/green checker with a blue top-left corner marker
  C3D_Tex tex; C3D_TexInit(&tex, 64, 64, GPU_RGBA8);
  uint8_t* d = static_cast<uint8_t*>(tex.data);
  for (unsigned y = 0; y < 64; ++y) for (unsigned x = 0; x < 64; ++x) {
    const unsigned tile = (y / 8) * 8 + x / 8, idx = tile * 64 + morton(x % 8, y % 8);
    uint8_t r = ((x / 8 + y / 8) & 1) ? 255 : 0, g = 255 - r, b = 0;
    if (x < 16 && y < 16) { r = 0; g = 0; b = 255; } // marker at texel rows 0-15 (v near 0)
    d[idx * 4 + 0] = 255; d[idx * 4 + 1] = b; d[idx * 4 + 2] = g; d[idx * 4 + 3] = r; // ABGR
  }
  C3D_TexFlush(&tex); C3D_TexSetFilter(&tex, GPU_NEAREST, GPU_NEAREST); C3D_TexSetWrap(&tex, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);
  // quad covering the left half of the top screen in "screen pixel" space (0,0 top-left), via OrthoTilt
  Vertex* v = static_cast<Vertex*>(linearAlloc(sizeof(Vertex) * 6));
  auto set = [&](int i, float x, float y, float u, float vv) { v[i] = {{x, y, 0.5f}, {0, 0, 1}, {u, vv, 0, 0}, {255, 255, 255, 255}}; };
  set(0, 20, 20, 0, 0); set(1, 180, 20, 1, 0); set(2, 180, 220, 1, 1);
  set(3, 20, 20, 0, 0); set(4, 180, 220, 1, 1); set(5, 20, 220, 0, 1);
  GSPGPU_FlushDataCache(v, sizeof(Vertex) * 6); // as the game does after writing static geometry
  for (int frame = 0; frame < 8; ++frame) {
    if (frame == 5 && std::getenv("C3DTEST_MOVE")) { // CPU rewrite + flush: the cached GL buffer must pick it up
      set(0, 220, 20, 0, 0); set(1, 380, 20, 1, 0); set(2, 380, 220, 1, 1); set(3, 220, 20, 0, 0); set(4, 380, 220, 1, 1); set(5, 220, 220, 0, 1);
      GSPGPU_FlushDataCache(v, sizeof(Vertex) * 6);
    }
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    C3D_RenderTargetClear(top, C3D_CLEAR_ALL, 0x202040FF, 0);
    C3D_RenderTargetClear(bottom, C3D_CLEAR_ALL, 0x804040FF, 0);
    C3D_FrameDrawOn(top);
    C3D_BindProgram(&program);
    C3D_Mtx proj, mv; Mtx_OrthoTilt(&proj, 0, 400, 240, 0, -1, 1, false); Mtx_Identity(&mv);
    C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, projLoc, &proj); C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, mvLoc, &mv);
    C3D_FVUnifSet(GPU_VERTEX_SHADER, lightLoc, 1, 1, 1, 1); C3D_FVUnifSet(GPU_VERTEX_SHADER, lightDirLoc, 0, 0, 1, 1);
    C3D_FVUnifSet(GPU_VERTEX_SHADER, tintLoc, 1, 1, 1, 1);
    C3D_FVUnifSet(GPU_VERTEX_SHADER, uvRow0, 1, 0, 0, 0); C3D_FVUnifSet(GPU_VERTEX_SHADER, uvRow1, 0, 1, 0, 0);
    C3D_FVUnifSet(GPU_VERTEX_SHADER, uv1Row0, 1, 0, 0, 0); C3D_FVUnifSet(GPU_VERTEX_SHADER, uv1Row1, 0, 1, 0, 0);
    C3D_AttrInfo* attr = C3D_GetAttrInfo(); AttrInfo_Init(attr);
    AttrInfo_AddLoader(attr, 0, GPU_FLOAT, 3); AttrInfo_AddLoader(attr, 1, GPU_FLOAT, 3); AttrInfo_AddLoader(attr, 2, GPU_FLOAT, 4); AttrInfo_AddLoader(attr, 3, GPU_UNSIGNED_BYTE, 4);
    C3D_BufInfo* buf = C3D_GetBufInfo(); BufInfo_Init(buf); BufInfo_Add(buf, v, sizeof(Vertex), 4, 0x3210);
    for (int i = 0; i < 6; ++i) C3D_TexEnvInit(C3D_GetTexEnv(i));
    C3D_TexEnv* env = C3D_GetTexEnv(0); C3D_TexEnvSrc(env, C3D_Both, GPU_TEXTURE0, GPU_PRIMARY_COLOR); C3D_TexEnvFunc(env, C3D_Both, GPU_MODULATE);
    C3D_TexBind(0, &tex);
    C3D_DepthTest(false, GPU_GEQUAL, GPU_WRITE_ALL); C3D_CullFace(GPU_CULL_NONE);
    C3D_AlphaBlend(GPU_BLEND_ADD, GPU_BLEND_ADD, GPU_SRC_ALPHA, GPU_ONE_MINUS_SRC_ALPHA, GPU_ONE, GPU_ONE_MINUS_SRC_ALPHA);
    C3D_DrawArrays(GPU_TRIANGLES, 0, 6);
    if (frame == 1 && std::getenv("C3DTEST_FUZZ")) { // compile many combiner configurations
      unsigned seed = 12345;
      auto rnd = [&](unsigned n) { seed = seed * 1103515245u + 12345u; return (seed >> 16) % n; };
      const int srcs[] = {0, 1, 2, 3, 4, 5, 13, 14, 15};
      for (int k = 0; k < 300; ++k) {
        for (int i = 0; i < 6; ++i) {
          C3D_TexEnv* e = C3D_GetTexEnv(i);
          C3D_TexEnvSrc(e, C3D_RGB, (GPU_TEVSRC)srcs[rnd(9)], (GPU_TEVSRC)srcs[rnd(9)], (GPU_TEVSRC)srcs[rnd(9)]);
          C3D_TexEnvSrc(e, C3D_Alpha, (GPU_TEVSRC)srcs[rnd(9)], (GPU_TEVSRC)srcs[rnd(9)], (GPU_TEVSRC)srcs[rnd(9)]);
          C3D_TexEnvFunc(e, C3D_RGB, (GPU_COMBINEFUNC)rnd(10)); C3D_TexEnvFunc(e, C3D_Alpha, (GPU_COMBINEFUNC)rnd(10));
          C3D_TexEnvOpRgb(e, (GPU_TEVOP_RGB)rnd(14), (GPU_TEVOP_RGB)rnd(14), (GPU_TEVOP_RGB)rnd(14));
          C3D_TexEnvOpAlpha(e, (GPU_TEVOP_A)rnd(8), (GPU_TEVOP_A)rnd(8), (GPU_TEVOP_A)rnd(8));
          C3D_TexEnvScale(e, C3D_RGB, (GPU_TEVSCALE)rnd(3));
        }
        C3D_TexEnvBufUpdate(C3D_Both, rnd(16));
        C3D_AlphaTest(rnd(2), (GPU_TESTFUNC)rnd(8), 128);
        C3D_DrawArrays(GPU_TRIANGLES, 0, 6);
      }
      for (int i = 0; i < 6; ++i) C3D_TexEnvInit(C3D_GetTexEnv(i));
      C3D_AlphaTest(false, GPU_ALWAYS, 0);
    }
    if (std::getenv("C3DTEST_MINIMAP")) { shim_set_minimap_visible(true); C3D_FrameDrawOn(bottom); C3D_DrawArrays(GPU_TRIANGLES, 0, 6); }
    if (frame == 7) shim::platform_screenshot_request("c3dtest.ppm");
    C3D_FrameEnd(0);
  }
  C3D_Fini();
  shim::platform_shutdown();
  std::printf("done\n");
  return 0;
}

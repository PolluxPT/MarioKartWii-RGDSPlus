#pragma once

// H700 shim: citro3d subset used by Mario Kart Wii 3DS, implemented on OpenGL ES.

#ifdef __cplusplus
extern "C" {
#endif

#include "c3d/types.h"

#include "c3d/maths.h"

#include "c3d/uniforms.h"
#include "c3d/attribs.h"
#include "c3d/buffers.h"
#include "c3d/base.h"

#include "c3d/texenv.h"
#include "c3d/effect.h"
#include "c3d/texture.h"

#include "c3d/framebuffer.h"
#include "c3d/renderqueue.h"

#ifdef __cplusplus
}
#endif

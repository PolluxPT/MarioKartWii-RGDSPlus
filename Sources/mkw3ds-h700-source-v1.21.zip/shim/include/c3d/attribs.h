#pragma once
#include "types.h"
// H700 shim: attribute loaders kept as plain records (no PICA register packing).
typedef struct {
	u8 regId, format, count, fixed;
} C3D_AttrEntry;
typedef struct
{
	C3D_AttrEntry entries[12];
	int attrCount;
} C3D_AttrInfo;
void AttrInfo_Init(C3D_AttrInfo* info);
int  AttrInfo_AddLoader(C3D_AttrInfo* info, int regId, GPU_FORMATS format, int count);
int  AttrInfo_AddFixed(C3D_AttrInfo* info, int regId);
C3D_AttrInfo* C3D_GetAttrInfo(void);
void C3D_SetAttrInfo(C3D_AttrInfo* info);

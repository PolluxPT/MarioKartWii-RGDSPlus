#pragma once
#include "types.h"
// H700 shim: vertex buffer bindings keep their host pointers.
typedef struct
{
	const void* data;
	u32 stride;
	u32 attribCount;
	u64 permutation;
} C3D_BufCfg;
typedef struct
{
	int bufCount;
	C3D_BufCfg buffers[12];
} C3D_BufInfo;
void BufInfo_Init(C3D_BufInfo* info);
int  BufInfo_Add(C3D_BufInfo* info, const void* data, ptrdiff_t stride, int attribCount, u64 permutation);
C3D_BufInfo* C3D_GetBufInfo(void);
void C3D_SetBufInfo(C3D_BufInfo* info);

#pragma once
// libctru thread API on pthreads (H700 shim).
#include <3ds/types.h>
#include <3ds/result.h>
#include <3ds/synchronization.h>
#include <3ds/svc.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct Thread_tag* Thread;
Thread threadCreate(ThreadFunc entrypoint, void* arg, size_t stack_size, int prio, int core_id, bool detached);
Handle threadGetHandle(Thread thread);
int    threadGetExitCode(Thread thread);
void   threadFree(Thread thread);
Result threadJoin(Thread thread, u64 timeout_ns);
void   threadDetach(Thread thread);
Thread threadGetCurrent(void);
void   threadExit(int rc) __attribute__((noreturn));
#ifdef __cplusplus
}
#endif

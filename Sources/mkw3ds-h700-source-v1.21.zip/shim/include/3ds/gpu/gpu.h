#pragma once
// GPU command buffer API is not used on the H700 shim; citro3d state lives in CPU structs.
#include <3ds/types.h>
#include <3ds/gpu/enums.h>
#define GPUCMD_HEADER(incremental, mask, reg) 0

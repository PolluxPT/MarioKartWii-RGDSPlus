#pragma once
// libctru synchronization primitives on pthreads (H700 shim).
#include <3ds/types.h>
#include <pthread.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct { pthread_mutex_t m; } LightLock;
typedef struct { pthread_mutex_t m; } RecursiveLock;
typedef struct { pthread_mutex_t m; pthread_cond_t c; bool signaled; bool sticky; } LightEvent;
typedef struct { pthread_mutex_t m; pthread_cond_t c; int count; int max; } LightSemaphore;
typedef struct { pthread_cond_t c; } CondVar;
void LightLock_Init(LightLock* lock);
void LightLock_Lock(LightLock* lock);
int  LightLock_TryLock(LightLock* lock);
void LightLock_Unlock(LightLock* lock);
void RecursiveLock_Init(RecursiveLock* lock);
void RecursiveLock_Lock(RecursiveLock* lock);
int  RecursiveLock_TryLock(RecursiveLock* lock);
void RecursiveLock_Unlock(RecursiveLock* lock);
void LightEvent_Init(LightEvent* event, ResetType reset_type);
void LightEvent_Clear(LightEvent* event);
void LightEvent_Pulse(LightEvent* event);
void LightEvent_Signal(LightEvent* event);
bool LightEvent_TryWait(LightEvent* event);
void LightEvent_Wait(LightEvent* event);
int  LightEvent_WaitTimeout(LightEvent* event, s64 timeout_ns);
void LightSemaphore_Init(LightSemaphore* semaphore, s16 initial_count, s16 max_count);
void LightSemaphore_Acquire(LightSemaphore* semaphore, s32 count);
void LightSemaphore_Release(LightSemaphore* semaphore, s32 count);
void CondVar_Init(CondVar* cv);
void CondVar_Wait(CondVar* cv, LightLock* lock);
void CondVar_Signal(CondVar* cv);
void CondVar_Broadcast(CondVar* cv);
#ifdef __cplusplus
}
#endif

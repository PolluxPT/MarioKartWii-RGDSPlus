#pragma once
#include <3ds/types.h>
#ifdef __cplusplus
extern "C" {
#endif
Result dspInit(void);
void dspExit(void);
Result DSP_FlushDataCache(const void* address, u32 size);
Result DSP_InvalidateDataCache(const void* address, u32 size);
#ifdef __cplusplus
}
#endif

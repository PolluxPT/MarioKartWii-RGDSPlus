#pragma once
// Subset of libctru os.h (H700 shim).
#include <3ds/types.h>
#ifdef __cplusplus
extern "C" {
#endif
#define SYSCLOCK_ARM11 268111856
#define SYSCLOCK_SOC (SYSCLOCK_ARM11/2)
#define CPU_TICKS_PER_MSEC (SYSCLOCK_ARM11 / 1000.0)
#define CPU_TICKS_PER_USEC (SYSCLOCK_ARM11 / 1000000.0)
#define OS_VRAM_VADDR   0x1F000000
#define OS_VRAM_SIZE    0x00600000
#define OS_FCRAM_VADDR  0x30000000
#define OS_FCRAM_SIZE   0x08000000
typedef struct { u64 elapsed; u64 reference; } TickCounter;
u64  osGetTime(void);
float osGet3DSliderState(void);
void osSetSpeedupEnable(bool enable);
bool osIsHeadsetConnected(void);
u32  osConvertVirtToPhys(const void* vaddr);
static inline void osTickCounterStart(TickCounter* cnt) { cnt->reference = svcGetSystemTick(); cnt->elapsed = 0; }
static inline void osTickCounterUpdate(TickCounter* cnt) { u64 now = svcGetSystemTick(); cnt->elapsed = now - cnt->reference; cnt->reference = now; }
static inline double osTickCounterRead(const TickCounter* cnt) { return cnt->elapsed / CPU_TICKS_PER_MSEC; }
#ifdef __cplusplus
}
#endif

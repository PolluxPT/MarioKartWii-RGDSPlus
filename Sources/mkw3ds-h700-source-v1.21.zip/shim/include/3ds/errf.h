#pragma once
#include <3ds/types.h>
typedef struct { u32 type; } ERRF_ExceptionInfo;

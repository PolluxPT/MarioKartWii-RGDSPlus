#pragma once
#include <3ds/types.h>
#ifdef __cplusplus
extern "C" {
#endif
Result romfsInit(void);
Result romfsExit(void);
#ifdef __cplusplus
}
#endif

#pragma once
// Subset of libctru svc.h (H700 shim).
#include <3ds/types.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum { RESET_ONESHOT = 0, RESET_STICKY = 1, RESET_PULSE = 2 } ResetType;
Result svcSleepThread(s64 ns);
u64    svcGetSystemTick(void);
Result svcGetThreadPriority(s32* out, Handle handle);
Result svcSetThreadPriority(Handle handle, s32 prio);
Result svcCreateEvent(Handle* event, ResetType reset_type);
Result svcSignalEvent(Handle handle);
Result svcClearEvent(Handle handle);
Result svcWaitSynchronization(Handle handle, s64 nanoseconds);
Result svcCloseHandle(Handle handle);
Result svcGetProcessInfo(s64* out, Handle process, u32 type);
#define CUR_THREAD_HANDLE 0xFFFF8000
#define CUR_PROCESS_HANDLE 0xFFFF8001
#ifdef __cplusplus
}
#endif

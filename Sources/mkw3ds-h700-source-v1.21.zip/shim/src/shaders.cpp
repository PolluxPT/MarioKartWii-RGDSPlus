// GLSL translations of the PICA shaders (src/mkw.v.pica, src/effect.v.pica) and a fragment
// shader that evaluates the PICA texture combiner (6 TexEnv stages, buffer, alpha test).
#include "shaders.hpp"

namespace shim {

// Float uniform registers: one vec4 array shared by both vertex shaders. Names map to registers
// in uniform_location() (c3d.cpp); the scene shader's layout is below.
const char* kSceneVertexShader = R"GLSL(#version 300 es
precision highp float;
precision highp int;
uniform vec4 c[82];
uniform int b;
layout(location = 0) in vec3 inpos;
layout(location = 1) in vec3 innormal;
layout(location = 2) in vec4 inuv;
layout(location = 3) in vec4 incolor;
layout(location = 4) in float inbone;
out vec4 v_tc0;
out vec4 v_tc1;
out vec4 v_tc2;
out vec4 v_color;
#define projection(i) c[0 + (i)]
#define modelView(i) c[4 + (i)]
#define light c[8]
#define uvScroll c[9]
#define envRow0 c[10]
#define envRow1 c[11]
#define envRow2 c[12]
#define envParam c[13]
#define uvRow0 c[14]
#define uvRow1 c[15]
#define uvRow2 c[16]
#define uvRow3 c[17]
#define tint c[18]
#define uv1Row0 c[19]
#define uv1Row1 c[20]
#define lightDiff c[21]
#define lightDir c[22]
#define lightFn c[23]
#define fogParam c[24]
#define bones(i) c[25 + (i)]
#define B_RETAIL_LIGHT_TEXTURE 1
#define B_ENVIRONMENT_MAPPED 2
#define B_DIFFUSE_LIGHTING 4
#define B_SKINNED 8
#define B_SKINNED_NORMALS 16
void main() {
  vec3 n = innormal;
  vec4 p = vec4(inpos, 1.0);
  if ((b & B_SKINNED) != 0) {
    int a0 = int((b & B_SKINNED_NORMALS) != 0 ? inbone : innormal.x);
    vec4 b0 = bones(a0), b1 = bones(a0 + 1), b2 = bones(a0 + 2);
    vec3 skinned = vec3(dot(b0, p), dot(b1, p), dot(b2, p));
    if ((b & B_SKINNED_NORMALS) != 0) {
      // Cofactor(B)*n / det(B) = inverse-transpose(B)*n; sign of the determinant kept.
      vec3 r3 = b1.yzx * b2.zxy - b1.zxy * b2.yzx;
      float det = dot(b0.xyz, r3);
      vec3 r5;
      r5.x = dot(r3, innormal);
      r3 = b2.yzx * b0.zxy - b2.zxy * b0.yzx;
      r5.y = dot(r3, innormal);
      r3 = b0.yzx * b1.zxy - b0.zxy * b1.yzx;
      r5.z = dot(r3, innormal);
      if (det == 0.0) {
        n = vec3(dot(b0.xyz, innormal), dot(b1.xyz, innormal), dot(b2.xyz, innormal));
      } else {
        float s = (det >= 0.0 ? 1.0 : 0.0) * 2.0 - 1.0;
        n = r5 * s;
      }
      float len2 = max(0.000000000001, dot(n, n));
      n *= inversesqrt(len2);
    }
    p = vec4(skinned, 1.0);
  }
  vec4 view = vec4(dot(modelView(0), p), dot(modelView(1), p), dot(modelView(2), p), dot(modelView(3), p));
  vec4 clip = vec4(dot(projection(0), view), dot(projection(1), view), dot(projection(2), view), dot(projection(3), view));
  // PICA clip z is in [-w, 0]; GL wants [-w, w]. Depth then runs 1 (near) .. 0 (far) like the PICA
  // default depth map, so the game's GEQUAL test and clear-to-0 keep their meaning.
  gl_Position = vec4(clip.x, clip.y, -(2.0 * clip.z + clip.w), clip.w);
  vec3 r11 = vec3(inuv.xy, 1.0);
  vec4 r5 = vec4(dot(uvRow0.xyz, r11), dot(uvRow1.xyz, r11), 0.0, 1.0);
  r5.xy += uvScroll.xy;
  v_tc0 = r5;
  r11.xy = inuv.zw;
  r5 = vec4(dot(uvRow2.xyz, r11), dot(uvRow3.xyz, r11), 0.0, 1.0);
  r5.xy += uvScroll.zw;
  if ((b & B_ENVIRONMENT_MAPPED) != 0) {
    vec3 r7 = vec3(dot(envRow0.xyz, n), dot(envRow1.xyz, n), dot(envRow2.xyz, n));
    r7 *= inversesqrt(max(0.00392156863, dot(r7, r7)));
    vec2 r8 = vec2(envParam.x * r7.x + envParam.y * r7.z, r7.y);
    r8 = 0.5 * r8 + 0.5;
    r8 -= r5.xy;
    r8 *= envParam.z;
    r5.xy += r8;
  }
  vec2 r11b = vec2(dot(uv1Row0, r5), dot(uv1Row1, r5));
  r5.xy = r11b;
  v_tc1 = r5;
  vec4 r13 = vec4(fogParam.x * view.z + fogParam.y, 0.5, 0.0, 1.0);
  vec4 r3;
  if ((b & B_DIFFUSE_LIGHTING) != 0) {
    vec4 r0 = vec4(n, 0.0);
    vec3 r1 = vec3(dot(modelView(0), r0), dot(modelView(1), r0), dot(modelView(2), r0));
    r1 *= inversesqrt(max(0.00392156863, dot(r1, r1)));
    float d = dot(lightDir.xyz, r1);
    d = lightFn.x * d + lightFn.y;
    d = max(lightFn.z, d);
    r3 = lightDiff * d + light;
  } else {
    r3 = light;
  }
  r3 = min(vec4(lightDir.w), r3);
  vec4 r4 = 0.00392156863 * incolor;
  r4 = r4 * r3;
  r4 = tint * r4;
  v_tc2 = (b & B_RETAIL_LIGHT_TEXTURE) != 0 ? r5 : r13;
  v_color = r4;
}
)GLSL";

const char* kEffectVertexShader = R"GLSL(#version 300 es
precision highp float;
precision highp int;
uniform vec4 c[82];
layout(location = 0) in vec3 inpos;
layout(location = 1) in vec3 inuv0;
layout(location = 2) in vec4 inuv;
layout(location = 3) in vec4 incolor;
out vec4 v_tc0;
out vec4 v_tc1;
out vec4 v_tc2;
out vec4 v_color;
void main() {
  vec4 p = vec4(inpos, 1.0);
  vec4 clip = vec4(dot(c[0], p), dot(c[1], p), dot(c[2], p), dot(c[3], p));
  gl_Position = vec4(clip.x, clip.y, -(2.0 * clip.z + clip.w), clip.w);
  // texcoord0 with its projective w (PICA unit 0 in projection mode divides per pixel).
  v_tc0 = vec4(inuv0.xy, 0.0, inuv0.z);
  v_tc1 = vec4(inuv.xy, 0.0, 1.0);
  v_tc2 = vec4(inuv.zw, 0.0, 1.0);
  v_color = 0.00392156863 * incolor;
}
)GLSL";

// Texture combiner. Per stage: srcRgb[3], srcA[3], opRgb[3], opA[3], funcRgb, funcA, scaleRgb, scaleA
// packed into ivec4 pairs; constants as vec4. Matches 3dbrew/Citra semantics including the
// one-stage delay of the combiner buffer.
const char* kFragmentShader = R"GLSL(#version 300 es
precision mediump float;
precision highp int;
in vec4 v_tc0;
in vec4 v_tc1;
in vec4 v_tc2;
in vec4 v_color;
out vec4 fragColor;
uniform sampler2D tex0;
uniform sampler2D tex1;
uniform sampler2D tex2;
// x: unit0 projection mode, y: alpha test func (0 never..7 always, -1 off), z: alpha ref (0..255), w: unit 2 uses texcoord1
uniform ivec4 fragCfg;
uniform vec3 texFlip; // 1: uploaded texture (PICA memory row 0 = v 1), sample at 1 - v
uniform vec4 bufColor;
uniform int bufUpdate; // bits 8-11 rgb update per stage 0-3, bits 12-15 alpha update
// per stage: p0 = (srcRgb0, srcRgb1, srcRgb2, srcA0), p1 = (srcA1, srcA2, opRgb0, opRgb1),
//            p2 = (opRgb2, opA0, opA1, opA2), p3 = (funcRgb, funcA, scaleRgb, scaleA)
uniform ivec4 stage[24];
uniform vec4 stageColor[6];

vec4 g_tex0, g_tex1, g_tex2, g_prev, g_buf;

vec4 source(int s, vec4 constant) {
  if (s == 0) return v_color;              // PRIMARY_COLOR
  if (s == 1) return v_color;              // FRAGMENT_PRIMARY_COLOR (no PICA lighting here)
  if (s == 2) return vec4(0.0);            // FRAGMENT_SECONDARY_COLOR
  if (s == 3) return g_tex0;
  if (s == 4) return g_tex1;
  if (s == 5) return g_tex2;
  if (s == 6) return vec4(0.0);            // TEXTURE3
  if (s == 13) return g_buf;               // PREVIOUS_BUFFER
  if (s == 14) return constant;            // CONSTANT
  return g_prev;                           // PREVIOUS (15)
}
vec3 opRgb(int op, vec4 v) {
  switch (op) {
    case 0: return v.rgb;                  // SRC_COLOR
    case 1: return 1.0 - v.rgb;            // ONE_MINUS_SRC_COLOR
    case 2: return vec3(v.a);              // SRC_ALPHA
    case 3: return vec3(1.0 - v.a);        // ONE_MINUS_SRC_ALPHA
    case 4: return vec3(v.r);              // SRC_R
    case 5: return vec3(1.0 - v.r);
    case 8: return vec3(v.g);              // SRC_G
    case 9: return vec3(1.0 - v.g);
    case 12: return vec3(v.b);             // SRC_B
    case 13: return vec3(1.0 - v.b);
  }
  return v.rgb;
}
float opA(int op, vec4 v) {
  switch (op) {
    case 0: return v.a;                    // SRC_ALPHA
    case 1: return 1.0 - v.a;
    case 2: return v.r;                    // SRC_R
    case 3: return 1.0 - v.r;
    case 4: return v.g;
    case 5: return 1.0 - v.g;
    case 6: return v.b;
    case 7: return 1.0 - v.b;
  }
  return v.a;
}
vec3 combineRgb(int f, vec3 a, vec3 b, vec3 c) {
  switch (f) {
    case 0: return a;                                   // REPLACE
    case 1: return a * b;                               // MODULATE
    case 2: return min(a + b, 1.0);                     // ADD
    case 3: return clamp(a + b - 0.5, 0.0, 1.0);        // ADD_SIGNED
    case 4: return a * c + b * (1.0 - c);               // INTERPOLATE
    case 5: return max(a - b, 0.0);                     // SUBTRACT
    case 6: return vec3(clamp(4.0 * dot(a - 0.5, b - 0.5), 0.0, 1.0)); // DOT3_RGB
    case 7: return vec3(clamp(4.0 * dot(a - 0.5, b - 0.5), 0.0, 1.0)); // DOT3_RGBA
    case 8: return min(a * b + c, 1.0);                 // MULTIPLY_ADD
    case 9: return min(a + b, 1.0) * c;                 // ADD_MULTIPLY
  }
  return a;
}
float combineA(int f, float a, float b, float c) {
  switch (f) {
    case 0: return a;
    case 1: return a * b;
    case 2: return min(a + b, 1.0);
    case 3: return clamp(a + b - 0.5, 0.0, 1.0);
    case 4: return a * c + b * (1.0 - c);
    case 5: return max(a - b, 0.0);
    case 8: return min(a * b + c, 1.0);
    case 9: return min(a + b, 1.0) * c;
  }
  return a;
}
void main() {
  vec2 uv0 = fragCfg.x != 0 ? v_tc0.xy / v_tc0.w : v_tc0.xy;
  uv0.y = mix(uv0.y, 1.0 - uv0.y, texFlip.x);
  vec2 uv1 = vec2(v_tc1.x, mix(v_tc1.y, 1.0 - v_tc1.y, texFlip.y));
  vec2 uv2 = fragCfg.w != 0 ? v_tc1.xy : v_tc2.xy;
  uv2.y = mix(uv2.y, 1.0 - uv2.y, texFlip.z);
  g_tex0 = texture(tex0, uv0);
  g_tex1 = texture(tex1, uv1);
  g_tex2 = texture(tex2, uv2);
  g_prev = vec4(0.0);
  g_buf = bufColor;
  vec4 nextBuf = bufColor;
  for (int i = 0; i < 6; ++i) {
    ivec4 p0 = stage[i * 4], p1 = stage[i * 4 + 1], p2 = stage[i * 4 + 2], p3 = stage[i * 4 + 3];
    vec4 k = stageColor[i];
    vec3 ra = opRgb(p1.z, source(p0.x, k)), rb = opRgb(p1.w, source(p0.y, k)), rc = opRgb(p2.x, source(p0.z, k));
    float aa = opA(p2.y, source(p0.w, k)), ab = opA(p2.z, source(p1.x, k)), ac = opA(p2.w, source(p1.y, k));
    vec3 rgb = combineRgb(p3.x, ra, rb, rc);
    float a = p3.x == 7 ? rgb.r : combineA(p3.y, aa, ab, ac);
    rgb = min(rgb * float(p3.z), 1.0);
    a = min(a * float(p3.w), 1.0);
    vec4 result = vec4(rgb, a);
    // Combiner buffer: stage i reads what stage i-2 wrote (one stage of delay).
    g_buf = nextBuf;
    if (i < 4) {
      if ((bufUpdate & (256 << i)) != 0) nextBuf.rgb = result.rgb;
      if ((bufUpdate & (4096 << i)) != 0) nextBuf.a = result.a;
    }
    g_prev = result;
  }
  vec4 color = g_prev;
  if (fragCfg.y >= 0) {
    float ref = float(fragCfg.z) / 255.0;
    float a = color.a;
    bool pass = true;
    switch (fragCfg.y) {
      case 0: pass = false; break;               // NEVER
      case 1: pass = true; break;                // ALWAYS
      case 2: pass = abs(a - ref) < 0.5 / 255.0; break;   // EQUAL
      case 3: pass = abs(a - ref) >= 0.5 / 255.0; break;  // NOTEQUAL
      case 4: pass = a < ref; break;             // LESS
      case 5: pass = a <= ref + 0.25 / 255.0; break;      // LEQUAL
      case 6: pass = a > ref; break;             // GREATER
      case 7: pass = a >= ref - 0.25 / 255.0; break;      // GEQUAL
    }
    if (!pass) discard;
  }
  fragColor = color;
}
)GLSL";

// Full-screen blit used by the presenter (screen rotation) and by display transfers.
const char* kBlitVertexShader = R"GLSL(#version 300 es
precision highp float;
layout(location = 0) in vec2 inpos;
layout(location = 1) in vec2 inuv;
out vec2 v_uv;
void main() { gl_Position = vec4(inpos, 0.0, 1.0); v_uv = inuv; }
)GLSL";
// Round mini map: the bottom screen's map area, cut to a circle with a thin border.
const char* kMiniFragmentShader = R"GLSL(#version 300 es
precision mediump float;
in vec2 v_uv;
out vec4 fragColor;
uniform sampler2D tex0;
uniform vec4 uvRect;   // u0, v0, u1, v1 of the square to show
uniform float opacity;
void main() {
  vec2 local = v_uv * 2.0 - 1.0;                 // -1..1 across the circle
  float r = length(local);
  if (r > 1.0) discard;
  vec3 c = texture(tex0, mix(uvRect.xy, uvRect.zw, v_uv)).rgb;
  float ring = smoothstep(0.90, 0.93, r);
  c = mix(c, vec3(1.0), ring);
  float edge = 1.0 - smoothstep(0.97, 1.0, r);
  fragColor = vec4(c, opacity * edge);
}
)GLSL";
const char* kBlitFragmentShader = R"GLSL(#version 300 es
precision mediump float;
in vec2 v_uv;
out vec4 fragColor;
uniform sampler2D tex0;
void main() { fragColor = vec4(texture(tex0, v_uv).rgb, 1.0); }
)GLSL";

} // namespace shim

// ---------------------------------------------------------------- specialized fragment programs
#include <cstdio>
namespace shim {
FragKey make_frag_key(const StageDesc (&st)[6], unsigned bufUpdate, int alphaFunc, bool unit0Projection, bool unit2Tc1, unsigned flipMask, int vertexProgram) {
  FragKey k;
  for (int i = 0; i < 6; ++i) {
    const StageDesc& s = st[i];
    k.w[i * 2] = (s.srcRgb & 0xfffu) | (s.srcA & 0xfffu) << 12 | (s.funcRgb & 0xfu) << 24 | (s.funcA & 0xfu) << 28;
    k.w[i * 2 + 1] = (s.opRgb & 0xfffu) | (s.opA & 0xfffu) << 12 | (s.scaleRgb & 3u) << 24 | (s.scaleA & 3u) << 26;
  }
  k.w[12] = ((bufUpdate >> 8) & 0xffu) | static_cast<uint32_t>(alphaFunc + 1) << 8 | (unit0Projection ? 1u : 0u) << 12 | (unit2Tc1 ? 1u : 0u) << 13 |
            (flipMask & 7u) << 14 | static_cast<uint32_t>(vertexProgram & 1) << 20;
  return k;
}

namespace {
std::string src_expr(int s, int stage) {
  switch (s) {
    case 0: case 1: return "v_color";
    case 3: return "t0";
    case 4: return "t1";
    case 5: return "t2";
    case 13: return "buf";
    case 14: return "stageColor[" + std::to_string(stage) + "]";
    case 15: return "prev";
    default: return "vec4(0.0)";
  }
}
std::string op_rgb(int op, const std::string& v) {
  switch (op) {
    case 1: return "(1.0 - " + v + ".rgb)";
    case 2: return "vec3(" + v + ".a)";
    case 3: return "vec3(1.0 - " + v + ".a)";
    case 4: return "vec3(" + v + ".r)";
    case 5: return "vec3(1.0 - " + v + ".r)";
    case 8: return "vec3(" + v + ".g)";
    case 9: return "vec3(1.0 - " + v + ".g)";
    case 12: return "vec3(" + v + ".b)";
    case 13: return "vec3(1.0 - " + v + ".b)";
    default: return v + ".rgb";
  }
}
std::string op_a(int op, const std::string& v) {
  switch (op) {
    case 1: return "(1.0 - " + v + ".a)";
    case 2: return v + ".r";
    case 3: return "(1.0 - " + v + ".r)";
    case 4: return v + ".g";
    case 5: return "(1.0 - " + v + ".g)";
    case 6: return v + ".b";
    case 7: return "(1.0 - " + v + ".b)";
    default: return v + ".a";
  }
}
std::string combine(int f, const std::string& a, const std::string& b, const std::string& c, bool rgb) {
  const std::string one = rgb ? "vec3(1.0)" : "1.0", zero = rgb ? "vec3(0.0)" : "0.0";
  switch (f) {
    case 1: return a + " * " + b;
    case 2: return "min(" + a + " + " + b + ", " + one + ")";
    case 3: return "clamp(" + a + " + " + b + " - 0.5, " + zero + ", " + one + ")";
    case 4: return "mix(" + b + ", " + a + ", " + c + ")";
    case 5: return "max(" + a + " - " + b + ", " + zero + ")";
    case 6: case 7: return rgb ? "vec3(clamp(4.0 * dot(" + a + " - 0.5, " + b + " - 0.5), 0.0, 1.0))" : a;
    case 8: return "min(" + a + " * " + b + " + " + c + ", " + one + ")";
    case 9: return "min(" + a + " + " + b + ", " + one + ") * " + c;
    default: return a;
  }
}
} // namespace

std::string make_fragment_shader(const FragKey& k) {
  StageDesc st[6];
  bool usesTex[3] = {false, false, false}, usesBuf = false;
  for (int i = 0; i < 6; ++i) {
    const uint32_t a = k.w[i * 2], b = k.w[i * 2 + 1];
    st[i] = {static_cast<uint16_t>(a & 0xfff), static_cast<uint16_t>((a >> 12) & 0xfff), static_cast<uint16_t>(b & 0xfff), static_cast<uint16_t>((b >> 12) & 0xfff),
             static_cast<uint8_t>((a >> 24) & 0xf), static_cast<uint8_t>((a >> 28) & 0xf), static_cast<uint8_t>((b >> 24) & 3), static_cast<uint8_t>((b >> 26) & 3)};
  }
  // which inputs are read (only the operands a combiner function actually uses)
  auto operands = [](int f) { return f == 0 ? 1 : (f == 4 || f == 8 || f == 9) ? 3 : 2; };
  for (int i = 0; i < 6; ++i) {
    for (int j = 0; j < operands(st[i].funcRgb); ++j) { const int s = (st[i].srcRgb >> (4 * j)) & 15; if (s >= 3 && s <= 5) usesTex[s - 3] = true; if (s == 13) usesBuf = true; }
    if (st[i].funcRgb != 7) for (int j = 0; j < operands(st[i].funcA); ++j) { const int s = (st[i].srcA >> (4 * j)) & 15; if (s >= 3 && s <= 5) usesTex[s - 3] = true; if (s == 13) usesBuf = true; }
  }
  const unsigned bufUpdate = k.w[12] & 0xff;
  const int alphaFunc = static_cast<int>((k.w[12] >> 8) & 0xf) - 1;
  const bool proj0 = (k.w[12] >> 12) & 1, unit2Tc1 = (k.w[12] >> 13) & 1;
  const unsigned flip = (k.w[12] >> 14) & 7;
  std::string o;
  o.reserve(4096);
  o += "#version 300 es\nprecision mediump float;\nin vec4 v_tc0;\nin vec4 v_tc1;\nin vec4 v_tc2;\nin vec4 v_color;\nout vec4 fragColor;\n";
  o += "uniform sampler2D tex0;\nuniform sampler2D tex1;\nuniform sampler2D tex2;\nuniform vec4 stageColor[6];\nuniform vec4 bufColor;\nuniform float alphaRef;\n";
  o += "void main() {\n";
  if (usesTex[0]) {
    o += proj0 ? "  vec2 uv0 = v_tc0.xy / v_tc0.w;\n" : "  vec2 uv0 = v_tc0.xy;\n";
    if (flip & 1) o += "  uv0.y = 1.0 - uv0.y;\n";
    o += "  vec4 t0 = texture(tex0, uv0);\n";
  }
  if (usesTex[1]) o += (flip & 2) ? "  vec4 t1 = texture(tex1, vec2(v_tc1.x, 1.0 - v_tc1.y));\n" : "  vec4 t1 = texture(tex1, v_tc1.xy);\n";
  if (usesTex[2]) {
    const char* tc = unit2Tc1 ? "v_tc1" : "v_tc2";
    o += (flip & 4) ? std::string("  vec4 t2 = texture(tex2, vec2(") + tc + ".x, 1.0 - " + tc + ".y));\n" : std::string("  vec4 t2 = texture(tex2, ") + tc + ".xy);\n";
  }
  o += "  vec4 prev = vec4(0.0);\n";
  if (usesBuf) o += "  vec4 buf = bufColor;\n  vec4 nextBuf = bufColor;\n";
  for (int i = 0; i < 6; ++i) {
    const StageDesc& s = st[i];
    // a stage that passes the previous result through unchanged and feeds no buffer update
    const bool passRgb = s.funcRgb == 0 && (s.srcRgb & 15) == 15 && (s.opRgb & 15) == 0 && s.scaleRgb == 0;
    const bool passA = s.funcRgb != 7 && s.funcA == 0 && (s.srcA & 15) == 15 && (s.opA & 15) == 0 && s.scaleA == 0;
    const bool updates = usesBuf && i < 4 && ((bufUpdate >> i) & 0x11);
    if (passRgb && passA && !updates) { if (usesBuf) o += "  buf = nextBuf;\n"; continue; }
    o += "  {\n";
    std::string ra[3], aa[3];
    for (int j = 0; j < 3; ++j) {
      ra[j] = op_rgb((s.opRgb >> (4 * j)) & 15, src_expr((s.srcRgb >> (4 * j)) & 15, i));
      aa[j] = op_a((s.opA >> (4 * j)) & 15, src_expr((s.srcA >> (4 * j)) & 15, i));
    }
    o += "    vec3 r = " + combine(s.funcRgb, ra[0], ra[1], ra[2], true) + ";\n";
    if (s.funcRgb == 7) o += "    float a = r.r;\n";
    else o += "    float a = " + combine(s.funcA, aa[0], aa[1], aa[2], false) + ";\n";
    if (s.scaleRgb) o += "    r = min(r * " + std::to_string(1 << s.scaleRgb) + ".0, 1.0);\n";
    if (s.scaleA) o += "    a = min(a * " + std::to_string(1 << s.scaleA) + ".0, 1.0);\n";
    o += "    vec4 res = vec4(r, a);\n";
    if (usesBuf) {
      o += "    buf = nextBuf;\n";
      if (i < 4 && ((bufUpdate >> i) & 1)) o += "    nextBuf.rgb = res.rgb;\n";
      if (i < 4 && ((bufUpdate >> (i + 4)) & 1)) o += "    nextBuf.a = res.a;\n";
    }
    o += "    prev = res;\n  }\n";
  }
  if (alphaFunc >= 0) {
    static const char* cond[8] = {"true", "false", "abs(prev.a - alphaRef) >= 0.5 / 255.0", "abs(prev.a - alphaRef) < 0.5 / 255.0", "prev.a >= alphaRef",
                                  "prev.a > alphaRef + 0.25 / 255.0", "prev.a <= alphaRef", "prev.a < alphaRef - 0.25 / 255.0"};
    // cond = the FAIL condition for NEVER, ALWAYS, EQUAL, NOTEQUAL, LESS, LEQUAL, GREATER, GEQUAL
    if (alphaFunc != 1) o += std::string("  if (") + cond[alphaFunc] + ") discard;\n";
  }
  o += "  fragColor = prev;\n}\n";
  return o;
}
} // namespace shim

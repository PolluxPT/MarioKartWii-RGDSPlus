// GLES 3 / EGL entry points resolved at runtime (Mali blob on the H700, Mesa on the host).
#pragma once
// Prototypes stay declared so decltype() yields the signatures; nothing links against them.
#include <GLES3/gl3.h>
#include <GLES2/gl2ext.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>

#define SHIM_GL_FUNCS(X) \
  X(glGetString) X(glGetError) X(glEnable) X(glDisable) X(glViewport) X(glScissor) X(glClear) X(glClearColor) X(glClearDepthf) X(glClearStencil) \
  X(glGenTextures) X(glDeleteTextures) X(glBindTexture) X(glTexImage2D) X(glTexSubImage2D) X(glCompressedTexImage2D) X(glTexParameteri) X(glTexParameterfv) X(glActiveTexture) X(glGenerateMipmap) X(glPixelStorei) \
  X(glGenBuffers) X(glDeleteBuffers) X(glBindBuffer) X(glBufferData) X(glBufferSubData) \
  X(glGenVertexArrays) X(glDeleteVertexArrays) X(glBindVertexArray) X(glEnableVertexAttribArray) X(glDisableVertexAttribArray) X(glVertexAttribPointer) X(glVertexAttrib4f) \
  X(glCreateShader) X(glShaderSource) X(glCompileShader) X(glGetShaderiv) X(glGetShaderInfoLog) X(glDeleteShader) X(glCreateProgram) X(glAttachShader) X(glDetachShader) X(glLinkProgram) X(glGetProgramiv) X(glGetProgramInfoLog) X(glUseProgram) X(glDeleteProgram) X(glBindAttribLocation) \
  X(glGetUniformLocation) X(glUniform1i) X(glUniform1iv) X(glUniform1f) X(glUniform4f) X(glUniform3f) X(glUniform4fv) X(glUniform1fv) X(glUniformMatrix4fv) X(glUniform4iv) X(glUniform4i) \
  X(glDrawArrays) X(glDrawElements) X(glDrawRangeElements) \
  X(glGenFramebuffers) X(glDeleteFramebuffers) X(glBindFramebuffer) X(glFramebufferTexture2D) X(glFramebufferRenderbuffer) X(glCheckFramebufferStatus) X(glGenRenderbuffers) X(glDeleteRenderbuffers) X(glBindRenderbuffer) X(glRenderbufferStorage) X(glBlitFramebuffer) X(glReadPixels) X(glReadBuffer) X(glDrawBuffers) \
  X(glDepthFunc) X(glDepthMask) X(glDepthRangef) X(glColorMask) X(glBlendFuncSeparate) X(glBlendFunc) X(glBlendEquation) X(glBlendEquationSeparate) X(glBlendColor) X(glCullFace) X(glFrontFace) \
  X(glStencilFunc) X(glStencilOp) X(glStencilMask) X(glFlush) X(glFinish) X(glGetIntegerv) X(glFenceSync) X(glClientWaitSync) X(glDeleteSync)

#define SHIM_EGL_FUNCS(X) \
  X(eglGetDisplay) X(eglGetPlatformDisplay) X(eglInitialize) X(eglTerminate) X(eglChooseConfig) X(eglGetConfigAttrib) X(eglCreateContext) X(eglDestroyContext) \
  X(eglCreateWindowSurface) X(eglCreatePbufferSurface) X(eglDestroySurface) X(eglMakeCurrent) X(eglSwapBuffers) X(eglSwapInterval) X(eglGetError) X(eglBindAPI) X(eglQueryString) X(eglGetProcAddress)

namespace shim::gl {
#define SHIM_DECL(name) extern decltype(&::name) name;
SHIM_GL_FUNCS(SHIM_DECL)
SHIM_EGL_FUNCS(SHIM_DECL)
#undef SHIM_DECL
bool load_egl();   // dlopen libEGL + resolve EGL entry points
bool load_gl();    // after a context is current: resolve GL entry points through eglGetProcAddress/dlsym
} // namespace shim::gl

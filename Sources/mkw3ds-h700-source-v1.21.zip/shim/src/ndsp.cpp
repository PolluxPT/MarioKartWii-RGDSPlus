// ndsp (3DS DSP audio service) as a software mixer feeding SDL3 audio: 24 channels of PCM8/PCM16/
// DSP-ADPCM with pitch, per-channel mix, wave buffer queues, a mono IIR filter and a frame callback.
#include <3ds.h>
#include "shim.hpp"
#include <SDL3/SDL.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <mutex>

namespace {
constexpr int kChannels = 24;
constexpr int kRate = 32728;
constexpr int kFrameSamples = 160; // one DSP frame

struct Channel {
  bool playing = false, paused = false;
  u16 format = NDSP_FORMAT_MONO_PCM16;
  ndspInterpType interp = NDSP_INTERP_LINEAR;
  float rate = kRate;
  float mix[12] = {1, 1};
  s16 coefs[16] = {};
  bool iir = false; float iirA = 1.0f; float iirState = 0.f;
  ndspWaveBuf* head = nullptr; // queue
  ndspWaveBuf* current = nullptr;
  u32 samplePos = 0;           // position in the current buffer (sample frames)
  double frac = 0.0;           // resampling phase
  s16 lastL = 0, lastR = 0, prevL = 0, prevR = 0;
  // ADPCM decode state
  u16 adpcmIndex = 0; s16 hist1 = 0, hist2 = 0;
  u32 adpcmDecodedUpTo = 0;    // sample index up to which the decode state is valid
  s16 decoded[16]; u32 decodedBase = 0; u32 decodedCount = 0;
};
Channel g_ch[kChannels];
std::mutex g_mutex;
std::atomic<u32> g_frameCount{0};
ndspCallback g_callback = nullptr; void* g_callbackData = nullptr;
SDL_AudioStream* g_stream = nullptr;
float g_masterVol = 1.0f;
bool g_init = false;

inline int bytes_per_frame(u16 format) {
  const int ch = format & 3; const int enc = (format >> 2) & 3;
  return enc == NDSP_ENCODING_PCM16 ? 2 * ch : enc == NDSP_ENCODING_PCM8 ? ch : 0;
}

// Decode the ADPCM frame holding sample `index` (14 samples per 8-byte frame).
void adpcm_decode_frame(Channel& c, const ndspWaveBuf* b, u32 frameIndex) {
  const u8* p = static_cast<const u8*>(b->data_vaddr) + frameIndex * 8;
  const int predictor = (p[0] >> 4) & 7, shift = p[0] & 15;
  const int c1 = c.coefs[predictor * 2], c2 = c.coefs[predictor * 2 + 1];
  for (int i = 0; i < 14; ++i) {
    int nibble = (i & 1) ? (p[1 + i / 2] & 15) : (p[1 + i / 2] >> 4);
    if (nibble >= 8) nibble -= 16;
    int sample = ((nibble << shift) << 11) + 1024 + c1 * c.hist1 + c2 * c.hist2;
    sample >>= 11;
    sample = std::clamp(sample, -32768, 32767);
    c.hist2 = c.hist1; c.hist1 = static_cast<s16>(sample);
    c.decoded[i] = static_cast<s16>(sample);
  }
  c.decodedBase = frameIndex * 14; c.decodedCount = 14;
}

// Fetch sample frame `pos` of the current buffer as L/R.
inline void fetch(Channel& c, const ndspWaveBuf* b, u32 pos, s16& l, s16& r) {
  const int ch = c.format & 3; const int enc = (c.format >> 2) & 3;
  if (enc == NDSP_ENCODING_ADPCM) {
    const u32 frameIndex = pos / 14;
    if (c.decodedCount == 0 || pos < c.decodedBase) {
      // (re)start from the buffer's initial context and decode forward to this frame
      if (b->adpcm_data) { c.adpcmIndex = b->adpcm_data->index; c.hist1 = b->adpcm_data->history0; c.hist2 = b->adpcm_data->history1; }
      else { c.hist1 = c.hist2 = 0; }
      for (u32 f = 0; f <= frameIndex; ++f) adpcm_decode_frame(c, b, f);
    } else {
      while (pos >= c.decodedBase + c.decodedCount) adpcm_decode_frame(c, b, c.decodedBase / 14 + 1);
    }
    l = r = c.decoded[pos - c.decodedBase];
    return;
  }
  if (enc == NDSP_ENCODING_PCM16) {
    const s16* d = static_cast<const s16*>(b->data_vaddr);
    if (ch == 2) { l = d[pos * 2]; r = d[pos * 2 + 1]; } else { l = r = d[pos]; }
  } else {
    const s8* d = static_cast<const s8*>(b->data_vaddr);
    if (ch == 2) { l = static_cast<s16>(d[pos * 2] * 256); r = static_cast<s16>(d[pos * 2 + 1] * 256); } else { l = r = static_cast<s16>(d[pos] * 256); }
  }
}

inline u32 buffer_frames(const Channel& c, const ndspWaveBuf* b) {
  const int ch = c.format & 3; const int enc = (c.format >> 2) & 3;
  // nsamples counts sample frames: a stereo frame is one L/R pair (the game and the real DSP agree)
  (void)ch; (void)enc;
  return b->nsamples;
}

void advance_buffer(Channel& c) {
  // current buffer finished
  ndspWaveBuf* b = c.current;
  if (b->looping) { c.samplePos = 0; c.decodedCount = 0; return; }
  b->status = NDSP_WBUF_DONE;
  c.current = b->next;
  c.head = c.current;
  c.samplePos = 0; c.decodedCount = 0;
  if (c.current) c.current->status = NDSP_WBUF_PLAYING; else c.playing = false;
}

void mix_frame(float* out /* kFrameSamples*2 */) {
  std::memset(out, 0, sizeof(float) * kFrameSamples * 2);
  for (int id = 0; id < kChannels; ++id) {
    Channel& c = g_ch[id];
    if (!c.playing || c.paused || !c.current) continue;
    const double step = c.rate / kRate;
    const float vl = c.mix[0], vr = c.mix[1];
    for (int i = 0; i < kFrameSamples; ++i) {
      if (!c.current) break;
      // advance source position by `step` sample frames, keeping the last two samples for interpolation
      c.frac += step;
      while (c.frac >= 1.0) {
        c.frac -= 1.0;
        const u32 frames = buffer_frames(c, c.current);
        if (c.samplePos >= frames) { advance_buffer(c); if (!c.current) break; continue; }
        s16 l, r; fetch(c, c.current, c.samplePos, l, r);
        c.prevL = c.lastL; c.prevR = c.lastR; c.lastL = l; c.lastR = r;
        ++c.samplePos;
      }
      if (!c.current && c.frac >= 1.0) break;
      float sl, sr;
      if (c.interp == NDSP_INTERP_NONE) { sl = c.lastL; sr = c.lastR; }
      else { const float t = static_cast<float>(c.frac); sl = c.prevL + (c.lastL - c.prevL) * t; sr = c.prevR + (c.lastR - c.prevR) * t; }
      if (c.iir) { c.iirState += c.iirA * (sl - c.iirState); sl = c.iirState; sr = c.iirState; }
      out[i * 2] += sl * vl; out[i * 2 + 1] += sr * vr;
    }
    // a channel whose buffer ended exactly at a frame boundary
    if (c.current && c.samplePos >= buffer_frames(c, c.current) && c.frac < 1.0) {
      // leave it; next frame advances
    }
  }
}

void SDLCALL audio_callback(void*, SDL_AudioStream* stream, int additional, int) {
  static float mixBuf[kFrameSamples * 2];
  static s16 outBuf[kFrameSamples * 2];
  int remaining = additional;
  while (remaining > 0) {
    {
      std::lock_guard lock(g_mutex);
      mix_frame(mixBuf);
    }
    for (int i = 0; i < kFrameSamples * 2; ++i) {
      float v = mixBuf[i] * g_masterVol;
      // soft clip
      if (v > 32767.f) v = 32767.f; if (v < -32768.f) v = -32768.f;
      outBuf[i] = static_cast<s16>(v);
    }
    SDL_PutAudioStreamData(stream, outBuf, sizeof outBuf);
    g_frameCount.fetch_add(1, std::memory_order_relaxed);
    if (g_callback) g_callback(g_callbackData);
    remaining -= static_cast<int>(sizeof outBuf);
  }
}
} // namespace

extern "C" Result ndspInit(void) {
  if (g_init) return 0;
  SDL_AudioSpec spec{SDL_AUDIO_S16, 2, kRate};
  g_stream = SDL_OpenAudioDeviceStream(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, &spec, audio_callback, nullptr);
  if (!g_stream) { SHIM_LOG("[ndsp] audio device: %s", SDL_GetError()); return -1; }
  SDL_ResumeAudioStreamDevice(g_stream);
  g_init = true;
  SHIM_LOG("[ndsp] mixer running at %d Hz", kRate);
  return 0;
}
extern "C" void ndspExit(void) {
  if (!g_init) return;
  SDL_DestroyAudioStream(g_stream); g_stream = nullptr; g_init = false;
}
void shim::ndsp_shutdown() { ndspExit(); }
extern "C" void ndspUseComponent(const void*, u32, u16, u16) {}
extern "C" u32 ndspGetDroppedFrames(void) { return 0; }
extern "C" u32 ndspGetFrameCount(void) { return g_frameCount.load(std::memory_order_relaxed); }
extern "C" void ndspSetMasterVol(float v) { g_masterVol = v; }
extern "C" float ndspGetMasterVol(void) { return g_masterVol; }
extern "C" void ndspSetOutputMode(ndspOutputMode) {}
extern "C" ndspOutputMode ndspGetOutputMode(void) { return NDSP_OUTPUT_STEREO; }
extern "C" void ndspSetClippingMode(ndspClippingMode) {}
extern "C" ndspClippingMode ndspGetClippingMode(void) { return NDSP_CLIP_SOFT; }
extern "C" void ndspSetOutputCount(int) {}
extern "C" int ndspGetOutputCount(void) { return 2; }
extern "C" void ndspSetCapture(ndspWaveBuf*) {}
extern "C" void ndspSetCallback(ndspCallback callback, void* data) { std::lock_guard lock(g_mutex); g_callback = callback; g_callbackData = data; }
extern "C" void ndspSurroundSetDepth(u16) {}
extern "C" void ndspSurroundSetPos(ndspSpeakerPos) {}
extern "C" void ndspSurroundSetRearRatio(u16) {}
extern "C" void ndspAuxSetEnable(int, bool) {}
extern "C" bool ndspAuxIsEnabled(int) { return false; }
extern "C" void ndspAuxSetFrontBypass(int, bool) {}
extern "C" bool ndspAuxGetFrontBypass(int) { return false; }
extern "C" void ndspAuxSetVolume(int, float) {}
extern "C" float ndspAuxGetVolume(int) { return 0; }
extern "C" void ndspAuxSetCallback(int, ndspAuxCallback, void*) {}

#define CH(id) if ((id) < 0 || (id) >= kChannels) return; Channel& c = g_ch[id]; std::lock_guard lock(g_mutex)
extern "C" void ndspChnReset(int id) {
  CH(id);
  for (ndspWaveBuf* b = c.head; b;) { ndspWaveBuf* n = b->next; b->status = NDSP_WBUF_DONE; b = n; }
  c.head = c.current = nullptr; c.playing = false; c.paused = false; c.samplePos = 0; c.frac = 0; c.decodedCount = 0;
  c.lastL = c.lastR = c.prevL = c.prevR = 0; c.iir = false; c.iirState = 0; c.rate = kRate; c.interp = NDSP_INTERP_LINEAR; c.format = NDSP_FORMAT_MONO_PCM16;
  float mix[12] = {1, 1}; std::memcpy(c.mix, mix, sizeof mix);
}
extern "C" void ndspChnInitParams(int id) { ndspChnReset(id); }
extern "C" bool ndspChnIsPlaying(int id) { if (id < 0 || id >= kChannels) return false; std::lock_guard lock(g_mutex); return g_ch[id].playing; }
extern "C" u32 ndspChnGetSamplePos(int id) { if (id < 0 || id >= kChannels) return 0; std::lock_guard lock(g_mutex); return g_ch[id].samplePos; }
extern "C" u16 ndspChnGetWaveBufSeq(int id) { if (id < 0 || id >= kChannels) return 0; std::lock_guard lock(g_mutex); return g_ch[id].current ? g_ch[id].current->sequence_id : 0; }
extern "C" bool ndspChnIsPaused(int id) { if (id < 0 || id >= kChannels) return false; std::lock_guard lock(g_mutex); return g_ch[id].paused; }
extern "C" void ndspChnSetPaused(int id, bool paused) { CH(id); c.paused = paused; }
extern "C" void ndspChnSetFormat(int id, u16 format) { CH(id); c.format = format; }
extern "C" u16 ndspChnGetFormat(int id) { if (id < 0 || id >= kChannels) return 0; return g_ch[id].format; }
extern "C" void ndspChnSetInterp(int id, ndspInterpType type) { CH(id); c.interp = type; }
extern "C" ndspInterpType ndspChnGetInterp(int id) { return id >= 0 && id < kChannels ? g_ch[id].interp : NDSP_INTERP_NONE; }
extern "C" void ndspChnSetRate(int id, float rate) { CH(id); c.rate = rate; }
extern "C" float ndspChnGetRate(int id) { return id >= 0 && id < kChannels ? g_ch[id].rate : 0; }
extern "C" void ndspChnSetMix(int id, float mix[12]) { CH(id); std::memcpy(c.mix, mix, sizeof c.mix); }
extern "C" void ndspChnGetMix(int id, float mix[12]) { if (id < 0 || id >= kChannels) return; std::lock_guard lock(g_mutex); std::memcpy(mix, g_ch[id].mix, sizeof g_ch[id].mix); }
extern "C" void ndspChnSetAdpcmCoefs(int id, u16 coefs[16]) { CH(id); for (int i = 0; i < 16; ++i) c.coefs[i] = static_cast<s16>(coefs[i]); }
extern "C" void ndspChnWaveBufClear(int id) {
  CH(id);
  for (ndspWaveBuf* b = c.head; b;) { ndspWaveBuf* n = b->next; b->status = NDSP_WBUF_DONE; b = n; }
  c.head = c.current = nullptr; c.playing = false; c.samplePos = 0; c.frac = 0; c.decodedCount = 0;
}
extern "C" void ndspChnWaveBufAdd(int id, ndspWaveBuf* buf) {
  CH(id);
  static u16 seq = 0;
  buf->next = nullptr; buf->status = NDSP_WBUF_QUEUED; buf->sequence_id = ++seq;
  if (!c.head) { c.head = c.current = buf; buf->status = NDSP_WBUF_PLAYING; c.samplePos = 0; c.frac = 0; c.decodedCount = 0; c.playing = true; }
  else { ndspWaveBuf* t = c.head; while (t->next) t = t->next; t->next = buf; }
}
extern "C" void ndspChnIirMonoSetEnable(int id, bool enable) { CH(id); c.iir = enable; if (!enable) c.iirState = 0; }
extern "C" bool ndspChnIirMonoSetParamsCustomFilter(int id, float a0, float, float) { if (id < 0 || id >= kChannels) return false; std::lock_guard lock(g_mutex); g_ch[id].iirA = std::clamp(a0, 0.f, 1.f); return true; }
extern "C" bool ndspChnIirMonoSetParamsLowPassFilter(int id, float f0) {
  if (id < 0 || id >= kChannels) return false;
  std::lock_guard lock(g_mutex);
  const float x = std::exp(-2.0f * 3.14159265f * f0 / kRate);
  g_ch[id].iirA = 1.0f - x;
  return true;
}
extern "C" bool ndspChnIirMonoSetParamsHighPassFilter(int id, float) { return id >= 0 && id < kChannels; }
extern "C" void ndspChnIirBiquadSetEnable(int, bool) {}
extern "C" bool ndspChnIirBiquadSetParamsCustomFilter(int, float, float, float, float, float, float) { return true; }
extern "C" bool ndspChnIirBiquadSetParamsLowPassFilter(int, float, float) { return true; }
extern "C" bool ndspChnIirBiquadSetParamsHighPassFilter(int, float, float) { return true; }
extern "C" bool ndspChnIirBiquadSetParamsBandPassFilter(int, float, float) { return true; }
extern "C" bool ndspChnIirBiquadSetParamsNotchFilter(int, float, float) { return true; }
extern "C" bool ndspChnIirBiquadSetParamsPeakingEqualizer(int, float, float, float) { return true; }

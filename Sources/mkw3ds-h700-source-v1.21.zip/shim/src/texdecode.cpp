// PICA texture memory -> GL-uploadable images: 8x8 Morton tiles (RGBA8/RGB8/RGBA5551/RGB565/
// RGBA4/LA8/HILO8/L8/A8/LA4/L4/A4) and ETC1/ETC1A4 (4x4 blocks in 8x8 tiles, little-endian words).
#include "texdecode.hpp"
#include <cstring>

namespace shim::texdecode {
namespace {
inline unsigned morton(unsigned x, unsigned y) {
  return (x & 1) | ((y & 1) << 1) | ((x & 2) << 1) | ((y & 2) << 2) | ((x & 4) << 2) | ((y & 4) << 3);
}
inline uint8_t expand4(unsigned v) { return static_cast<uint8_t>(v * 17); }
inline uint8_t expand5(unsigned v) { return static_cast<uint8_t>((v << 3) | (v >> 2)); }
inline uint8_t expand6(unsigned v) { return static_cast<uint8_t>((v << 2) | (v >> 4)); }

// ETC1 block decode (standard byte order: big-endian 64-bit as the Khronos spec lays it out).
const int kEtc1Mod[8][4] = {{2, 8, -2, -8},    {5, 17, -5, -17},  {9, 29, -9, -29},    {13, 42, -13, -42},
                            {18, 60, -18, -60}, {24, 80, -24, -80}, {33, 106, -33, -106}, {47, 183, -47, -183}};
inline uint8_t clamp8(int v) { return static_cast<uint8_t>(v < 0 ? 0 : v > 255 ? 255 : v); }
// `block` holds the 8 bytes in standard order; writes 16 RGB texels (x fastest) to out[4][4][3].
void decode_etc1_block(const uint8_t block[8], uint8_t out[4][4][3]) {
  const bool diff = block[3] & 2, flip = block[3] & 1;
  int r[2], g[2], b[2];
  if (diff) {
    const int r0 = block[0] >> 3, g0 = block[1] >> 3, b0 = block[2] >> 3;
    const int dr = static_cast<int>(block[0] & 7) - ((block[0] & 4) ? 8 : 0);
    const int dg = static_cast<int>(block[1] & 7) - ((block[1] & 4) ? 8 : 0);
    const int db = static_cast<int>(block[2] & 7) - ((block[2] & 4) ? 8 : 0);
    r[0] = expand5(r0); g[0] = expand5(g0); b[0] = expand5(b0);
    r[1] = expand5(static_cast<unsigned>(r0 + dr) & 31); g[1] = expand5(static_cast<unsigned>(g0 + dg) & 31); b[1] = expand5(static_cast<unsigned>(b0 + db) & 31);
  } else {
    r[0] = expand4(block[0] >> 4); r[1] = expand4(block[0] & 15);
    g[0] = expand4(block[1] >> 4); g[1] = expand4(block[1] & 15);
    b[0] = expand4(block[2] >> 4); b[1] = expand4(block[2] & 15);
  }
  const int table[2] = {block[3] >> 5, (block[3] >> 2) & 7};
  const uint32_t low = (static_cast<uint32_t>(block[4]) << 24) | (static_cast<uint32_t>(block[5]) << 16) |
                       (static_cast<uint32_t>(block[6]) << 8) | block[7];
  for (int x = 0; x < 4; ++x)
    for (int y = 0; y < 4; ++y) {
      const int idx = x * 4 + y; // texel index: column-major in the spec's bit layout
      const int sub = flip ? (y >= 2) : (x >= 2);
      const unsigned msb = (low >> (idx + 16)) & 1, lsb = (low >> idx) & 1;
      const unsigned code = (msb << 1) | lsb;
      const int mod = kEtc1Mod[table[sub]][code];
      out[y][x][0] = clamp8(r[sub] + mod); out[y][x][1] = clamp8(g[sub] + mod); out[y][x][2] = clamp8(b[sub] + mod);
    }
}
} // namespace

size_t bytes_per_pixel_x8(GPU_TEXCOLOR fmt) {
  switch (fmt) {
    case GPU_RGBA8: return 32; case GPU_RGB8: return 24; case GPU_RGBA5551: case GPU_RGB565: case GPU_RGBA4: case GPU_LA8: case GPU_HILO8: return 16;
    case GPU_L8: case GPU_A8: case GPU_LA4: case GPU_ETC1A4: return 8; case GPU_L4: case GPU_A4: case GPU_ETC1: return 4;
  }
  return 32;
}

// Untile one mip level into linear RGBA8 (bottom row of memory first, i.e. texel row 0 first).
void to_rgba8(GPU_TEXCOLOR fmt, unsigned width, unsigned height, const uint8_t* src, uint8_t* dst) {
  const unsigned tilesX = width / 8;
  if (fmt == GPU_ETC1 || fmt == GPU_ETC1A4) {
    const size_t blockBytes = fmt == GPU_ETC1A4 ? 16 : 8;
    const uint8_t* p = src;
    for (unsigned ty = 0; ty < height / 8; ++ty)
      for (unsigned tx = 0; tx < tilesX; ++tx)
        for (unsigned by = 0; by < 8; by += 4)
          for (unsigned bx = 0; bx < 8; bx += 4) {
            uint8_t alpha[8] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
            const uint8_t* color = p;
            if (fmt == GPU_ETC1A4) { std::memcpy(alpha, p, 8); color = p + 8; }
            uint8_t std8[8];
            for (int i = 0; i < 8; ++i) std8[i] = color[7 - i]; // little-endian word -> spec order
            uint8_t rgb[4][4][3];
            decode_etc1_block(std8, rgb);
            for (unsigned y = 0; y < 4; ++y)
              for (unsigned x = 0; x < 4; ++x) {
                uint8_t a = 0xff;
                if (fmt == GPU_ETC1A4) { const uint8_t v = alpha[2 * x + y / 2]; a = expand4((y & 1) ? (v >> 4) : (v & 15)); }
                uint8_t* o = dst + ((ty * 8 + by + y) * width + tx * 8 + bx + x) * 4;
                o[0] = rgb[y][x][0]; o[1] = rgb[y][x][1]; o[2] = rgb[y][x][2]; o[3] = a;
              }
            p += blockBytes;
          }
    return;
  }
  const size_t bpp8 = bytes_per_pixel_x8(fmt);
  for (unsigned ty = 0; ty < height / 8; ++ty)
    for (unsigned tx = 0; tx < tilesX; ++tx) {
      const size_t tileIndex = ty * tilesX + tx;
      const uint8_t* tile = src + tileIndex * 64 * bpp8 / 8;
      for (unsigned y = 0; y < 8; ++y)
        for (unsigned x = 0; x < 8; ++x) {
          const unsigned m = morton(x, y);
          uint8_t* o = dst + ((ty * 8 + y) * width + tx * 8 + x) * 4;
          switch (fmt) {
            case GPU_RGBA8: { const uint8_t* q = tile + m * 4; o[0] = q[3]; o[1] = q[2]; o[2] = q[1]; o[3] = q[0]; break; } // stored ABGR
            case GPU_RGB8: { const uint8_t* q = tile + m * 3; o[0] = q[2]; o[1] = q[1]; o[2] = q[0]; o[3] = 0xff; break; }
            case GPU_RGBA5551: { uint16_t v; std::memcpy(&v, tile + m * 2, 2); o[0] = expand5(v >> 11); o[1] = expand5((v >> 6) & 31); o[2] = expand5((v >> 1) & 31); o[3] = (v & 1) ? 0xff : 0; break; }
            case GPU_RGB565: { uint16_t v; std::memcpy(&v, tile + m * 2, 2); o[0] = expand5(v >> 11); o[1] = expand6((v >> 5) & 63); o[2] = expand5(v & 31); o[3] = 0xff; break; }
            case GPU_RGBA4: { uint16_t v; std::memcpy(&v, tile + m * 2, 2); o[0] = expand4(v >> 12); o[1] = expand4((v >> 8) & 15); o[2] = expand4((v >> 4) & 15); o[3] = expand4(v & 15); break; }
            case GPU_LA8: { const uint8_t* q = tile + m * 2; o[0] = o[1] = o[2] = q[1]; o[3] = q[0]; break; }
            case GPU_HILO8: { const uint8_t* q = tile + m * 2; o[0] = q[1]; o[1] = q[0]; o[2] = 0; o[3] = 0xff; break; }
            case GPU_L8: { o[0] = o[1] = o[2] = tile[m]; o[3] = 0xff; break; }
            case GPU_A8: { o[0] = o[1] = o[2] = 0; o[3] = tile[m]; break; }
            case GPU_LA4: { const uint8_t v = tile[m]; o[0] = o[1] = o[2] = expand4(v >> 4); o[3] = expand4(v & 15); break; }
            case GPU_L4: { const uint8_t v = tile[m / 2]; const unsigned n = (m & 1) ? (v >> 4) : (v & 15); o[0] = o[1] = o[2] = expand4(n); o[3] = 0xff; break; }
            case GPU_A4: { const uint8_t v = tile[m / 2]; const unsigned n = (m & 1) ? (v >> 4) : (v & 15); o[0] = o[1] = o[2] = 0; o[3] = expand4(n); break; }
            default: o[0] = o[1] = o[2] = 0xff; o[3] = 0xff; break;
          }
        }
    }
}

// Reorder PICA ETC1 data (8x8 tiles of four little-endian 4x4 blocks) into linear ETC1 blocks in
// the Khronos byte order, for direct compressed upload (ETC1 is an ETC2_RGB8 subset).
void etc1_to_linear(unsigned width, unsigned height, const uint8_t* src, uint8_t* dst) {
  const unsigned blocksX = width / 4;
  const uint8_t* p = src;
  for (unsigned ty = 0; ty < height / 8; ++ty)
    for (unsigned tx = 0; tx < width / 8; ++tx)
      for (unsigned by = 0; by < 2; ++by)
        for (unsigned bx = 0; bx < 2; ++bx) {
          uint8_t* o = dst + ((ty * 2 + by) * blocksX + tx * 2 + bx) * 8;
          for (int i = 0; i < 8; ++i) o[i] = p[7 - i];
          p += 8;
        }
}
} // namespace shim::texdecode

// Internal interface of the 3DS compatibility layer for the H700 (Linux/aarch64, Mali GLES) and
// the x86 host (Mesa) used for testing.
#pragma once
#include <cstdint>
#include <cstddef>
#include <string>

namespace shim {

// --- platform (platform.cpp)
struct ScreenSize { int width, height; };
bool platform_init();                 // SDL, EGL context, audio device
void platform_shutdown();
ScreenSize platform_screen();         // physical output size
void platform_swap();                 // eglSwapBuffers
bool platform_make_current();         // bind the EGL context to the calling (GL) thread
bool platform_headless();
bool platform_screenshot_pending(std::string& path);
bool platform_pump_events();
void platform_request_quit();          // false when the app should exit
const char* platform_data_dir();      // where sdmc:/ maps to
void platform_log(const char* fmt, ...);
uint64_t platform_now_ns();
void platform_screenshot_request(const char* path); // dump next presented frame as PNG

// --- gfx (gfx.cpp): the two LCD framebuffers as CPU buffers + GL textures
void gfx_present_frame();             // compose the screens and swap
unsigned gfx_screen_texture(int screen);   // GL texture the C3D presenter draws into
void gfx_screen_dirty_cpu(int screen);     // CPU framebuffer was swapped: upload it
void gfx_vblank_wait();
uint32_t gfx_frame_counter();

// --- input (ctru.cpp)
void input_update();

// --- audio (ndsp.cpp)
void ndsp_shutdown();

} // namespace shim

#define SHIM_LOG(...) ::shim::platform_log(__VA_ARGS__)

#pragma once
#include <3ds.h>
#include <cstddef>
#include <cstdint>
namespace shim::texdecode {
size_t bytes_per_pixel_x8(GPU_TEXCOLOR fmt); // bits per texel
void to_rgba8(GPU_TEXCOLOR fmt, unsigned width, unsigned height, const uint8_t* src, uint8_t* dst);
void etc1_to_linear(unsigned width, unsigned height, const uint8_t* src, uint8_t* dst);
}

// 3DS path prefixes: "sdmc:/..." is the SD card root and "romfs:/..." the title's read-only data.
// Both map into the port's data directory (MKW_DATA_DIR, default "."). Linked with
// --wrap=fopen,mkdir,chdir,remove,rename,access,stat,opendir,open.
#include "shim.hpp"
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstdarg>

namespace {
const char* translate(const char* path, char* buf, size_t size) {
  if (!path) return path;
  const char* rest = nullptr;
  if (std::strncmp(path, "sdmc:/", 6) == 0) rest = path + 6;
  else if (std::strncmp(path, "romfs:/", 7) == 0) rest = path + 7;
  else if (std::strncmp(path, "sdmc:", 5) == 0) rest = path + 5;
  else if (std::strncmp(path, "romfs:", 6) == 0) rest = path + 6;
  if (!rest) return path;
  std::snprintf(buf, size, "%s/%s", shim::platform_data_dir(), rest);
  return buf;
}
} // namespace

extern "C" {
FILE* __real_fopen(const char*, const char*);
int __real_mkdir(const char*, mode_t);
int __real_chdir(const char*);
int __real_remove(const char*);
int __real_rename(const char*, const char*);
int __real_access(const char*, int);
int __real_stat(const char*, struct stat*);
DIR* __real_opendir(const char*);
int __real_open(const char*, int, ...);

FILE* __wrap_fopen(const char* path, const char* mode) { char b[1024]; return __real_fopen(translate(path, b, sizeof b), mode); }
int __wrap_mkdir(const char* path, mode_t m) { char b[1024]; return __real_mkdir(translate(path, b, sizeof b), m); }
int __wrap_chdir(const char* path) { char b[1024]; return __real_chdir(translate(path, b, sizeof b)); }
int __wrap_remove(const char* path) { char b[1024]; return __real_remove(translate(path, b, sizeof b)); }
int __wrap_rename(const char* a, const char* c) { char b1[1024], b2[1024]; return __real_rename(translate(a, b1, sizeof b1), translate(c, b2, sizeof b2)); }
int __wrap_access(const char* path, int mode) { char b[1024]; return __real_access(translate(path, b, sizeof b), mode); }
int __wrap_stat(const char* path, struct stat* st) { char b[1024]; return __real_stat(translate(path, b, sizeof b), st); }
DIR* __wrap_opendir(const char* path) { char b[1024]; return __real_opendir(translate(path, b, sizeof b)); }
int __wrap_open(const char* path, int flags, ...) {
  char b[1024];
  mode_t mode = 0;
  if (flags & O_CREAT) { va_list ap; va_start(ap, flags); mode = static_cast<mode_t>(va_arg(ap, int)); va_end(ap); }
  return __real_open(translate(path, b, sizeof b), flags, mode);
}
}

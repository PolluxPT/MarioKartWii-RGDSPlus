// citro3d on OpenGL ES 3: calls record into a per-frame command list on whichever thread the game
// uses; one GL thread owns the EGL context and replays frames, so the Mali context never moves
// between threads. Vertex data referenced by draws is copied at record time.
#include <3ds.h>
#include <citro3d.h>
#include "shim.hpp"
#include "gl.hpp"
#include "shaders.hpp"
#include "texdecode.hpp"
#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <memory>
#include <mutex>
#include <map>
#include <algorithm>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>
#include <csignal>
#include <dlfcn.h>
#include <execinfo.h>
#include <pthread.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/syscall.h>

using namespace shim;
bool shim_linear_lookup(const void* p, const void** base, size_t* size); // ctru.cpp

// citro3d uniform globals (c3d/uniforms.h)
C3D_FVec C3D_FVUnif[2][C3D_FVUNIF_COUNT];
C3D_IVec C3D_IVUnif[2][C3D_IVUNIF_COUNT];
u16 C3D_BoolUnifs[2];
bool C3D_FVUnifDirty[2][C3D_FVUNIF_COUNT];
bool C3D_IVUnifDirty[2][C3D_IVUNIF_COUNT];
bool C3D_BoolUnifsDirty[2];

namespace {

constexpr int kFloatRegs = 82; // registers the GLSL declares
constexpr unsigned kScreenW[2] = {400, 320}, kScreenH = 240;

// ---------------------------------------------------------------- shader name tables
struct UniformName { const char* name; int reg; };
const UniformName kSceneUniforms[] = {
    {"projection", 0}, {"modelView", 4}, {"light", 8}, {"uvScroll", 9}, {"envRow0", 10}, {"envRow1", 11}, {"envRow2", 12},
    {"envParam", 13}, {"uvRow0", 14}, {"uvRow1", 15}, {"uvRow2", 16}, {"uvRow3", 17}, {"tint", 18}, {"uv1Row0", 19},
    {"uv1Row1", 20}, {"lightDiff", 21}, {"lightDir", 22}, {"lightFn", 23}, {"fogParam", 24}, {"bones", 25},
    // bools: C3D_BoolUnifSet subtracts 0x68
    {"retailLightTexture", 0x68 + 0}, {"environmentMapped", 0x68 + 1}, {"diffuseLighting", 0x68 + 2}, {"skinned", 0x68 + 3},
    {"skinnedNormals", 0x68 + 4},
};
const UniformName kEffectUniforms[] = {{"projection", 0}};

// ---------------------------------------------------------------- recorded state
struct EffectState {
  bool depthTest = false; GPU_TESTFUNC depthFunc = GPU_GREATER; int writeMask = GPU_WRITE_ALL;
  bool alphaTest = false; GPU_TESTFUNC alphaFunc = GPU_ALWAYS; int alphaRef = 0;
  GPU_BLENDEQUATION eqRgb = GPU_BLEND_ADD, eqA = GPU_BLEND_ADD;
  GPU_BLENDFACTOR srcRgb = GPU_ONE, dstRgb = GPU_ZERO, srcA = GPU_ONE, dstA = GPU_ZERO;
  bool blendEnabled = true; u32 blendColor = 0;
  GPU_CULLMODE cull = GPU_CULL_BACK_CCW;
  bool stencil = false; GPU_TESTFUNC stencilFunc = GPU_ALWAYS; int stencilWriteMask = 0xff, stencilRef = 0, stencilInputMask = 0xff;
  GPU_STENCILOP sfail = GPU_STENCIL_KEEP, dfail = GPU_STENCIL_KEEP, pass = GPU_STENCIL_KEEP;
};
struct TexBinding { const void* key = nullptr; u32 param = 0; }; // key: C3D_Tex::data

struct TargetImpl {
  C3D_RenderTarget base{};
  unsigned id = 0;
  int width = 0, height = 0;          // as the game sees it (rotated: 240 x 400 for the top screen)
  const void* colorTexKey = nullptr;  // render-to-texture: C3D_Tex data pointer
  bool depth = false, stencil = false;
};
inline TargetImpl* impl_of(C3D_RenderTarget* t) { return reinterpret_cast<TargetImpl*>(t); }

enum class Op : uint8_t { Target, Clear, Viewport, Scissor, Program, Uniforms, Bools, TexEnv, Effect, BindTex, Draw, UploadTex, DeleteTex,
                          CreateTarget, DeleteTarget, SetOutput, Present, ReadTarget, ScreenCpu, Split, UploadBuf, DeleteBuf };
struct Cmd {
  Op op;
  union {
    struct { unsigned target; } target;
    struct { unsigned target; u32 bits, color, depth; } clear;
    struct { int x, y, w, h; } viewport;
    struct { int mode, left, top, right, bottom; } scissor;
    struct { int index; } program;
    struct { size_t arena; int first, count; } uniforms; // floats copied into the arena
    struct { u32 bits; } bools;
    struct { size_t arena; u32 bufUpdate, bufColor; } texenv;   // 6 C3D_TexEnv in the arena
    struct { size_t arena; } effect;                             // EffectState in the arena
    struct { int unit; const void* key; u32 param; } bindTex;
    struct { int prim; unsigned count; size_t vertexArena, indexArena; int indexType; u32 attrMask; size_t layoutArena; const void* indexKey; int first; } draw;
    struct { const void* key; size_t offset, size, arena; bool create; } uploadBuf; // LINEAR allocation -> GL buffer
    struct { const void* key; } deleteBuf;
    struct { const void* key; unsigned width, height; int fmt; size_t arena; size_t bytes; bool compressed; } uploadTex;
    struct { const void* key; } deleteTex;
    struct { unsigned target; int width, height; const void* colorTexKey; bool depth, stencil; } createTarget;
    struct { unsigned target; } deleteTarget;
    struct { unsigned target; int screen, side; } setOutput;
    struct { unsigned target; void* dest; int width, height; bool rgb8; } readTarget;
    struct { int screen; size_t arena; } screenCpu;
  };
};
struct DrawLayout { // one per draw: which attributes, their formats and arena offsets
  struct Attr { int reg, count, format; size_t offset, stride; const void* key; }; // key: cached GL buffer (null = this frame's geo)
  Attr attrs[12]; int attrCount;
};
// Growable byte buffer without zero-filling (frames are recycled, so capacity sticks).
struct ByteBuf {
  std::unique_ptr<uint8_t[]> p; size_t n = 0, cap = 0;
  uint8_t* data() { return p.get(); }
  const uint8_t* data() const { return p.get(); }
  size_t size() const { return n; }
  bool empty() const { return n == 0; }
  void clear() { n = 0; }
  size_t push(const void* src, size_t size, size_t align = 16) {
    const size_t at = (n + align - 1) / align * align;
    if (at + size > cap) {
      size_t nc = cap ? cap : (1u << 20);
      while (nc < at + size) nc *= 2;
      std::unique_ptr<uint8_t[]> np(new uint8_t[nc]);
      if (n) std::memcpy(np.get(), p.get(), n);
      p = std::move(np); cap = nc;
    }
    if (src) std::memcpy(p.get() + at, src, size);
    n = at + size;
    return at;
  }
};
struct Frame {
  std::vector<Cmd> cmds;
  ByteBuf arena; // CPU-side data: uniforms, layouts, texture pixels, CPU framebuffers
  ByteBuf geo;   // vertices + indices: uploaded to one GL buffer per frame
  bool present = false;
  std::atomic<bool> done{false};
  // stats
  unsigned draws = 0; size_t texBytes = 0;
  size_t push(const void* data, size_t size, size_t align = 16) { return arena.push(data, size, align); }
  void reset() { cmds.clear(); arena.clear(); geo.clear(); present = false; done = false; draws = 0; texBytes = 0; }
};

// Recorder: the state citro3d's API mutates between draws.
struct Recorder {
  std::mutex mutex; // serializes record-side calls (the game drives them from more than one thread, never concurrently in practice)
  std::unique_ptr<Frame> frame;
  shaderProgram_s* program = nullptr;
  C3D_AttrInfo attrInfo{};
  C3D_BufInfo bufInfo{};
  C3D_TexEnv texEnv[6]{};
  u32 texEnvBuf = 0, texEnvBufClr = 0;
  EffectState effect;
  TexBinding tex[3];
  bool texEnvDirty = true, effectDirty = true, texDirty[3] = {true, true, true}, programDirty = true;
  unsigned nextTargetId = 1;
  TargetImpl* currentTarget = nullptr;
  struct TexRecord { unsigned width, height; GPU_TEXCOLOR fmt; size_t bytes; bool vram; };
  std::unordered_map<const void*, TexRecord> textures; // keyed by C3D_Tex::data
  std::map<uintptr_t, const void*> texByAddr;          // start address -> key, for cache-flush lookups
  std::vector<const void*> pendingUploads;             // textures the CPU wrote and flushed
  // Vertex/index memory the GPU reads lives in LINEAR allocations; each gets a GL buffer uploaded
  // once, then only the ranges the game flushes (GSPGPU_FlushDataCache) are re-sent.
  // An allocation is cached only once it has been flushed and then left alone for a couple of
  // frames (static models). Memory the game rewrites (animated karts, sprites, text) is flushed
  // every frame, so it stays on the per-draw copy path; the game flushes after recording its draws.
  struct BufRecord { size_t size = 0; bool uploaded = false; uint32_t lastFlushFrame = 0; bool flushed = false; };
  std::map<uintptr_t, BufRecord> buffers;
  uint32_t frameIndex = 1;
  std::unordered_map<const void*, TargetImpl*> targetByFrameBuf; // &target->frameBuf -> impl
  std::vector<TargetImpl*> targets;
  int inFrame = 0;
  bool skipping = false; // drawing into the hidden bottom screen: drop the work
  std::atomic<uint32_t> framesPresented{0};
};
Recorder g_rec;
// The 3DS bottom screen (map + standings) is not shown unless MKW_BOTTOM=1: its drawing is dropped.
bool show_bottom() { static const bool on = std::getenv("MKW_BOTTOM") && std::atoi(std::getenv("MKW_BOTTOM")) != 0; return on; }
// MKW_MINIMAP (default on): with the bottom screen hidden, its map is shown as a round mini map on
// the main screen while the game says the race HUD is up (shim_set_minimap_visible).
bool minimap_enabled() { static const bool on = std::getenv("MKW_ROUND_MAP") && std::atoi(std::getenv("MKW_ROUND_MAP")) != 0; return on && !show_bottom(); } // experimental; the game draws its own mini map
std::atomic<bool> g_minimapVisible{false};
bool hidden_target(const TargetImpl* t) {
  if (!t || !t->base.linked || t->base.screen != GFX_BOTTOM || show_bottom()) return false;
  return !(minimap_enabled() && g_minimapVisible.load(std::memory_order_relaxed));
}

// GL executor
struct GlTexture { GLuint id = 0; unsigned width = 0, height = 0; u32 appliedParam = 0xffffffff; bool valid = false; bool flipV = false; };
struct GlTarget { GLuint fbo = 0, color = 0, depth = 0; int width = 0, height = 0; float scale = 1; int pw = 0, ph = 0; /* stored size */ const void* colorTexKey = nullptr; bool ownsColor = false; int screen = -1, side = 0; };
struct GlProgram {
  GLuint id = 0; GLint locC = -1, locB = -1, locStageColor = -1, locBufColor = -1, locAlphaRef = -1;
  uint32_t verC[kFloatRegs] = {}; uint32_t verB = 0, verFrag = 0; // last uploaded versions of the shared uniform state
};
struct Executor {
  std::thread thread;
  std::mutex mutex;
  std::condition_variable cv, doneCv;
  std::deque<std::unique_ptr<Frame>> queue;
  std::vector<std::unique_ptr<Frame>> pool; // finished frames, reused by the recorder
  std::atomic<bool> stop{false};
  size_t inFlight = 0;
  // GL objects
  std::unordered_map<const void*, GlTexture> textures;
  std::unordered_map<unsigned, GlTarget> targets;
  std::unordered_map<const void*, GLuint> buffers; // cached LINEAR allocations
  std::unordered_map<FragKey, GlProgram, FragKeyHash> programs;
  GLuint vertexShaders[2] = {0, 0};
  unsigned programsBuilt = 0; bool warming = false;
  GLuint blitProgram = 0, blitVbo = 0, vao = 0, arenaVbo[3] = {}, arenaIbo[3] = {};
  int arenaSlot = 0;
  GLuint screenTex[2] = {0, 0};
  int screenTexW[2] = {0, 0}, screenTexH[2] = {0, 0};
  GLuint readFbo = 0, readTex = 0; int readW = 0, readH = 0; // scaled readbacks
  GLuint screenFbo[2] = {0, 0};
  GLuint whiteTex = 0;
  int screenLastWriter[2] = {0, 0}; // 0 none, 1 target, 2 cpu
  bool bottomDrawn = false; // the bottom target was rendered this frame (mini map source)
  GLuint miniProgram = 0; GLint miniUvRect = -1, miniOpacity = -1;
  double drawingMs = 0, processingMs = 0;
  // vblank
  std::mutex vblankMutex; std::condition_variable vblankCv; uint32_t vblankCount = 0;
  std::vector<uint8_t> scratch;
  // watchdog: what the executor is doing, for a log line when frames stop coming
  std::atomic<int> curOp{-1}; std::atomic<size_t> curCmd{0}, curCmds{0}; std::atomic<bool> inExecute{false};
};
Executor g_ex;
std::atomic<const char*> g_mainState{"running"}; // what the game thread waits on (watchdog)

// ---------------------------------------------------------------- GL helpers
GLuint compile(GLenum type, const char* src, const char* label) {
  GLuint s = gl::glCreateShader(type);
  gl::glShaderSource(s, 1, &src, nullptr);
  gl::glCompileShader(s);
  GLint ok = 0; gl::glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
  if (!ok) { char log[4096]; gl::glGetShaderInfoLog(s, sizeof log, nullptr, log); SHIM_LOG("[gl] %s shader: %s", label, log); }
  return s;
}
GLuint link(const char* vs, const char* fs, const char* label) {
  GLuint p = gl::glCreateProgram();
  GLuint v = compile(GL_VERTEX_SHADER, vs, label), f = compile(GL_FRAGMENT_SHADER, fs, label);
  gl::glAttachShader(p, v); gl::glAttachShader(p, f);
  gl::glLinkProgram(p);
  GLint ok = 0; gl::glGetProgramiv(p, GL_LINK_STATUS, &ok);
  if (!ok) { char log[4096]; gl::glGetProgramInfoLog(p, sizeof log, nullptr, log); SHIM_LOG("[gl] %s link: %s", label, log); }
  gl::glDeleteShader(v); gl::glDeleteShader(f);
  return p;
}
GLenum gl_blend_factor(int f) {
  static const GLenum t[] = {GL_ZERO, GL_ONE, GL_SRC_COLOR, GL_ONE_MINUS_SRC_COLOR, GL_DST_COLOR, GL_ONE_MINUS_DST_COLOR, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA,
                             GL_DST_ALPHA, GL_ONE_MINUS_DST_ALPHA, GL_CONSTANT_COLOR, GL_ONE_MINUS_CONSTANT_COLOR, GL_CONSTANT_ALPHA, GL_ONE_MINUS_CONSTANT_ALPHA, GL_SRC_ALPHA_SATURATE};
  return f >= 0 && f < 15 ? t[f] : GL_ONE;
}
GLenum gl_blend_eq(int e) { static const GLenum t[] = {GL_FUNC_ADD, GL_FUNC_SUBTRACT, GL_FUNC_REVERSE_SUBTRACT, GL_MIN, GL_MAX}; return e >= 0 && e < 5 ? t[e] : GL_FUNC_ADD; }
GLenum gl_func(int f) { static const GLenum t[] = {GL_NEVER, GL_ALWAYS, GL_EQUAL, GL_NOTEQUAL, GL_LESS, GL_LEQUAL, GL_GREATER, GL_GEQUAL}; return f >= 0 && f < 8 ? t[f] : GL_ALWAYS; }
GLenum gl_stencil_op(int o) { static const GLenum t[] = {GL_KEEP, GL_ZERO, GL_REPLACE, GL_INCR, GL_DECR, GL_INVERT, GL_INCR_WRAP, GL_DECR_WRAP}; return o >= 0 && o < 8 ? t[o] : GL_KEEP; }
bool g_cullFlip = false;
// MKW_SCALE: the screens' render targets are this many times the 3DS resolution (1 = 400x240).
float render_scale() {
  static const float s = [] { const char* e = std::getenv("MKW_SCALE"); float v = e ? static_cast<float>(std::atof(e)) : 1.f; return v < 1.f ? 1.f : v > 3.f ? 3.f : v; }();
  return s;
}
int scaled(int v, float s) { return static_cast<int>(static_cast<float>(v) * s + 0.5f); }

void apply_effect(const EffectState& e) {
  if (e.depthTest) { gl::glEnable(GL_DEPTH_TEST); gl::glDepthFunc(gl_func(e.depthFunc)); } else gl::glDisable(GL_DEPTH_TEST);
  gl::glDepthMask((e.writeMask & GPU_WRITE_DEPTH) ? GL_TRUE : GL_FALSE);
  gl::glColorMask((e.writeMask & GPU_WRITE_RED) != 0, (e.writeMask & GPU_WRITE_GREEN) != 0, (e.writeMask & GPU_WRITE_BLUE) != 0, (e.writeMask & GPU_WRITE_ALPHA) != 0);
  if (e.blendEnabled) {
    gl::glEnable(GL_BLEND);
    gl::glBlendEquationSeparate(gl_blend_eq(e.eqRgb), gl_blend_eq(e.eqA));
    gl::glBlendFuncSeparate(gl_blend_factor(e.srcRgb), gl_blend_factor(e.dstRgb), gl_blend_factor(e.srcA), gl_blend_factor(e.dstA));
    gl::glBlendColor((e.blendColor & 0xff) / 255.f, ((e.blendColor >> 8) & 0xff) / 255.f, ((e.blendColor >> 16) & 0xff) / 255.f, ((e.blendColor >> 24) & 0xff) / 255.f);
  } else gl::glDisable(GL_BLEND);
  if (e.cull == GPU_CULL_NONE) gl::glDisable(GL_CULL_FACE);
  else {
    gl::glEnable(GL_CULL_FACE);
    gl::glFrontFace(g_cullFlip ? GL_CW : GL_CCW);
    gl::glCullFace(e.cull == GPU_CULL_FRONT_CCW ? GL_FRONT : GL_BACK);
  }
  if (e.stencil) {
    gl::glEnable(GL_STENCIL_TEST);
    gl::glStencilFunc(gl_func(e.stencilFunc), e.stencilRef, static_cast<GLuint>(e.stencilInputMask));
    gl::glStencilMask(static_cast<GLuint>(e.stencilWriteMask));
    gl::glStencilOp(gl_stencil_op(e.sfail), gl_stencil_op(e.dfail), gl_stencil_op(e.pass));
  } else { gl::glDisable(GL_STENCIL_TEST); gl::glStencilMask(0xff); }
}

extern "C" void shim_set_minimap_visible(bool on) { g_minimapVisible.store(on, std::memory_order_relaxed); }

void apply_tex_params(GlTexture& t, u32 param) {
  if (t.appliedParam == param) return;
  t.appliedParam = param;
  const int mag = (param >> 1) & 1, min = (param >> 2) & 1, mip = (param >> 24) & 1;
  const int wrapS = (param >> 12) & 3, wrapT = (param >> 8) & 3;
  auto wrap = [](int w) { return w == 0 ? GL_CLAMP_TO_EDGE : w == 1 ? GL_CLAMP_TO_EDGE /* border */ : w == 2 ? GL_REPEAT : GL_MIRRORED_REPEAT; };
  gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, mag ? GL_LINEAR : GL_NEAREST);
  gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, min ? GL_LINEAR : GL_NEAREST);
  (void)mip;
  gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrap(wrapS));
  gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrap(wrapT));
}

GlTexture& gl_texture(const void* key) {
  auto& t = g_ex.textures[key];
  if (!t.id) gl::glGenTextures(1, &t.id);
  return t;
}

void ensure_target(GlTarget& t) {
  if (t.fbo) return;
  t.scale = t.colorTexKey ? 1.f : render_scale(); // render-to-texture keeps the size the game reads back
  t.pw = scaled(t.width, t.scale); t.ph = scaled(t.height, t.scale);
  gl::glGenFramebuffers(1, &t.fbo);
  gl::glBindFramebuffer(GL_FRAMEBUFFER, t.fbo);
  if (t.colorTexKey) {
    GlTexture& tex = gl_texture(t.colorTexKey);
    gl::glBindTexture(GL_TEXTURE_2D, tex.id);
    if (!tex.valid) { gl::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, t.width, t.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr); tex.valid = true; tex.width = t.width; tex.height = t.height; }
    tex.flipV = false; // rendered by GL: rows already match PICA sampling
    t.color = tex.id;
  } else {
    gl::glGenTextures(1, &t.color);
    gl::glBindTexture(GL_TEXTURE_2D, t.color);
    gl::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, t.pw, t.ph, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    t.ownsColor = true;
  }
  gl::glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t.color, 0);
  if (t.depth) {
    gl::glGenRenderbuffers(1, &t.depth);
    gl::glBindRenderbuffer(GL_RENDERBUFFER, t.depth);
    gl::glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, t.pw, t.ph);
    gl::glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, t.depth);
  }
  const GLenum status = gl::glCheckFramebufferStatus(GL_FRAMEBUFFER);
  if (status != GL_FRAMEBUFFER_COMPLETE) SHIM_LOG("[gl] target %dx%d incomplete: 0x%x", t.width, t.height, status);
}

// Draw a texture onto the current framebuffer with the given quad (NDC) and uv corners.
void blit_with(GLuint program, GLuint tex, const float quad[8], const float uv[8], bool blend) {
  gl::glUseProgram(program);
  gl::glDisable(GL_DEPTH_TEST);
  if (blend) { gl::glEnable(GL_BLEND); gl::glBlendEquation(GL_FUNC_ADD); gl::glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); } else gl::glDisable(GL_BLEND); gl::glDisable(GL_CULL_FACE); gl::glDisable(GL_STENCIL_TEST); gl::glDisable(GL_SCISSOR_TEST);
  gl::glColorMask(1, 1, 1, 1);
  gl::glActiveTexture(GL_TEXTURE0); gl::glBindTexture(GL_TEXTURE_2D, tex);
  gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  float verts[16];
  for (int i = 0; i < 4; ++i) { verts[i * 4] = quad[i * 2]; verts[i * 4 + 1] = quad[i * 2 + 1]; verts[i * 4 + 2] = uv[i * 2]; verts[i * 4 + 3] = uv[i * 2 + 1]; }
  gl::glBindBuffer(GL_ARRAY_BUFFER, g_ex.blitVbo);
  gl::glBufferData(GL_ARRAY_BUFFER, sizeof verts, verts, GL_STREAM_DRAW);
  gl::glEnableVertexAttribArray(0); gl::glEnableVertexAttribArray(1);
  for (int i = 2; i < 5; ++i) gl::glDisableVertexAttribArray(i);
  gl::glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 16, nullptr);
  gl::glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 16, reinterpret_cast<void*>(8));
  gl::glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}
void blit(GLuint tex, const float quad[8], const float uv[8]) { blit_with(g_ex.blitProgram, tex, quad, uv, false); }

void executor_init() {
  gl::glGenVertexArrays(1, &g_ex.vao); gl::glBindVertexArray(g_ex.vao);
  gl::glGenBuffers(3, g_ex.arenaVbo); gl::glGenBuffers(3, g_ex.arenaIbo); gl::glGenBuffers(1, &g_ex.blitVbo);
  g_ex.blitProgram = link(kBlitVertexShader, kBlitFragmentShader, "blit");
  g_ex.miniProgram = link(kBlitVertexShader, kMiniFragmentShader, "minimap");
  g_ex.miniUvRect = gl::glGetUniformLocation(g_ex.miniProgram, "uvRect"); g_ex.miniOpacity = gl::glGetUniformLocation(g_ex.miniProgram, "opacity");
  g_ex.vertexShaders[0] = compile(GL_VERTEX_SHADER, kSceneVertexShader, "scene vs");
  g_ex.vertexShaders[1] = compile(GL_VERTEX_SHADER, kEffectVertexShader, "effect vs");
  gl::glGenTextures(1, &g_ex.whiteTex); gl::glBindTexture(GL_TEXTURE_2D, g_ex.whiteTex);
  const uint8_t white[4] = {255, 255, 255, 255};
  gl::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, white);
  for (int s = 0; s < 2; ++s) {
    gl::glGenTextures(1, &g_ex.screenTex[s]); gl::glBindTexture(GL_TEXTURE_2D, g_ex.screenTex[s]);
    gl::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, kScreenW[s], kScreenH, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    g_ex.screenTexW[s] = static_cast<int>(kScreenW[s]); g_ex.screenTexH[s] = static_cast<int>(kScreenH);
    gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    gl::glGenFramebuffers(1, &g_ex.screenFbo[s]); gl::glBindFramebuffer(GL_FRAMEBUFFER, g_ex.screenFbo[s]);
    gl::glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_ex.screenTex[s], 0);
  }
  gl::glBindFramebuffer(GL_FRAMEBUFFER, 0);
  g_cullFlip = std::getenv("MKW_CULL_FLIP") != nullptr;
}

// Screen (400x240 / 320x240, landscape, row 0 = top) from a rotated target (240 wide x 400 tall).
// Target texel (x, y) shows at screen pixel (sx = W-1 - y, sy = 239 - x); verified against
// Mtx_OrthoTilt with shim/test/c3dtest.cpp.
// The per-screen texture follows the size of whatever last wrote it (scaled target or CPU framebuffer).
void ensure_screen_tex(int screen, int w, int h) {
  if (g_ex.screenTexW[screen] == w && g_ex.screenTexH[screen] == h) return;
  g_ex.screenTexW[screen] = w; g_ex.screenTexH[screen] = h;
  gl::glActiveTexture(GL_TEXTURE0 + 3); gl::glBindTexture(GL_TEXTURE_2D, g_ex.screenTex[screen]);
  gl::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
}
void target_to_screen(const GlTarget& t, int screen) {
  ensure_screen_tex(screen, t.ph, t.pw); // rotated: the target's height is the screen's width
  gl::glBindFramebuffer(GL_FRAMEBUFFER, g_ex.screenFbo[screen]);
  gl::glViewport(0, 0, t.ph, t.pw);
  // quad corners: (-1,-1)=screen bottom-left ... uv in target space (u along the 240 axis, v along 400)
  static float quad[8] = {-1, -1, 1, -1, -1, 1, 1, 1};
  float uv[8] = {0, 1, 0, 0, 1, 1, 1, 0};
  if (std::getenv("MKW_ROT_ALT")) { float alt[8] = {0, 0, 0, 1, 1, 0, 1, 1}; std::memcpy(uv, alt, sizeof uv); }
  blit(t.color, quad, uv);
}
void present_screens() {
  const ScreenSize s = platform_screen();
  gl::glBindFramebuffer(GL_FRAMEBUFFER, 0);
  gl::glViewport(0, 0, s.width, s.height);
  gl::glClearColor(0, 0, 0, 1); gl::glClear(GL_COLOR_BUFFER_BIT);
  // Layout (MKW_LAYOUT): "full" (default) = the top screen stretched over the whole display;
  // "fit" = top screen at its own 5:3 shape, centered. With MKW_BOTTOM=1 the bottom screen goes
  // below the top screen when there is room ("fit"), or as an inset at the bottom-right.
  static const char* layoutEnv = std::getenv("MKW_LAYOUT");
  const bool fit = layoutEnv && std::strcmp(layoutEnv, "fit") == 0;
  const float W = static_cast<float>(s.width), H = static_cast<float>(s.height);
  const float uvPlain[8] = {0, 0, 1, 0, 0, 1, 1, 1};
  auto quad_px = [&](float x0, float y0, float w, float h, float out[8]) { // pixel rect, y down from the top
    const float nx0 = x0 / W * 2.f - 1.f, nx1 = (x0 + w) / W * 2.f - 1.f;
    const float ny1 = 1.f - y0 / H * 2.f, ny0 = 1.f - (y0 + h) / H * 2.f;
    const float q[8] = {nx0, ny0, nx1, ny0, nx0, ny1, nx1, ny1};
    std::memcpy(out, q, sizeof q);
  };
  float q[8];
  if (!fit) {
    quad_px(0, 0, W, H, q);
    blit(g_ex.screenTex[0], q, uvPlain);
  } else {
    const float topH = std::min(H, W * 240.f / 400.f), topW = topH * 400.f / 240.f, band = H - topH;
    const bool stack = show_bottom() && band >= H * 0.25f;
    quad_px((W - topW) * 0.5f, stack ? 0.f : (H - topH) * 0.5f, topW, topH, q);
    blit(g_ex.screenTex[0], q, uvPlain);
    if (stack) {
      float w = band * 320.f / 240.f, h = band;
      if (w > W) { w = W; h = w * 240.f / 320.f; }
      quad_px((W - w) * 0.5f, topH + (band - h) * 0.5f, w, h, q);
      blit(g_ex.screenTex[1], q, uvPlain);
      return;
    }
  }
  if (show_bottom()) {
    const float h = H * 0.3f, w = h * 320.f / 240.f;
    quad_px(W - w - 4.f, H - h - 4.f, w, h, q);
    blit(g_ex.screenTex[1], q, uvPlain);
  }
  if (minimap_enabled() && g_ex.bottomDrawn && g_ex.screenLastWriter[1] == 1) {
    // Bottom screen (320x240): the map is the area right of the standings column, centred on the
    // player at (201, 120). Show a 150x150 square around the player, as a circle on the right side.
    const float cx = 201.f, cy = 122.f, half = 75.f;
    const float u0 = (cx - half) / 320.f, u1 = (cx + half) / 320.f;
    const float v0 = 1.f - (cy + half) / 240.f, v1 = 1.f - (cy - half) / 240.f; // GL rows: 0 = bottom
    const float d = H * 0.30f, x0 = W - d - W * 0.025f, y0 = H * 0.52f - d * 0.5f;
    quad_px(x0, y0, d, d, q);
    const float uvLocal[8] = {0, 0, 1, 0, 0, 1, 1, 1};
    gl::glUseProgram(g_ex.miniProgram);
    gl::glUniform4f(g_ex.miniUvRect, u0, v0, u1, v1);
    gl::glUniform1f(g_ex.miniOpacity, 0.9f);
    blit_with(g_ex.miniProgram, g_ex.screenTex[1], q, uvLocal, true);
  }
}

std::string shader_list_path() { return std::string(platform_data_dir()) + "/shaders.cache"; }
GlProgram& get_program(const FragKey& key) {
  auto it = g_ex.programs.find(key);
  if (it != g_ex.programs.end()) return it->second;
  GlProgram& p = g_ex.programs[key];
  const std::string fs = make_fragment_shader(key);
  const GLuint f = compile(GL_FRAGMENT_SHADER, fs.c_str(), "combiner fs");
  p.id = gl::glCreateProgram();
  gl::glAttachShader(p.id, g_ex.vertexShaders[(key.w[12] >> 20) & 1]); gl::glAttachShader(p.id, f);
  gl::glLinkProgram(p.id);
  GLint ok = 0; gl::glGetProgramiv(p.id, GL_LINK_STATUS, &ok);
  if (!ok) { char log[4096]; gl::glGetProgramInfoLog(p.id, sizeof log, nullptr, log); SHIM_LOG("[gl] combiner link: %s\n%s", log, fs.c_str()); }
  gl::glDetachShader(p.id, f); gl::glDeleteShader(f);
  p.locC = gl::glGetUniformLocation(p.id, "c"); p.locB = gl::glGetUniformLocation(p.id, "b");
  p.locStageColor = gl::glGetUniformLocation(p.id, "stageColor"); p.locBufColor = gl::glGetUniformLocation(p.id, "bufColor");
  p.locAlphaRef = gl::glGetUniformLocation(p.id, "alphaRef");
  gl::glUseProgram(p.id);
  const char* texNames[3] = {"tex0", "tex1", "tex2"};
  for (int u = 0; u < 3; ++u) { const GLint l = gl::glGetUniformLocation(p.id, texNames[u]); if (l >= 0) gl::glUniform1i(l, u); }
  ++g_ex.programsBuilt;
  // Remember the key so the next launch builds this program before the game starts.
  if (!g_ex.warming) {
    if (FILE* f = std::fopen(shader_list_path().c_str(), "ab")) { std::fwrite(key.w.data(), sizeof(uint32_t), key.w.size(), f); std::fclose(f); }
  }
  return p;
}
// Programs seen by earlier runs: compiled now, so races do not stall on first use.
void warm_programs() {
  FILE* f = std::fopen(shader_list_path().c_str(), "rb");
  if (!f) return;
  g_ex.warming = true;
  const uint64_t t0 = platform_now_ns();
  unsigned n = 0;
  FragKey k;
  while (std::fread(k.w.data(), sizeof(uint32_t), k.w.size(), f) == k.w.size()) { get_program(k); if (++n > 400) break; }
  std::fclose(f);
  g_ex.warming = false;
  SHIM_LOG("[gl] %u combiner programs prebuilt in %.0f ms", n, (platform_now_ns() - t0) / 1e6);
}

// Uniform state shared by every program: a shadow copy plus a version per register, so a program
// only receives the registers that changed since it was last used.
struct UniformShadow {
  float c[kFloatRegs * 4] = {}; uint32_t verC[kFloatRegs] = {}; int b = 0; uint32_t verB = 1;
  float stageColor[6 * 4] = {}; float bufColor[4] = {}; float alphaRef = 0; uint32_t verFrag = 1;
  uint32_t counter = 1;
};
UniformShadow g_uni;
void sync_uniforms(GlProgram& p) {
  for (int i = 0; i < kFloatRegs;) {
    if (p.verC[i] == g_uni.verC[i]) { ++i; continue; }
    int j = i;
    while (j < kFloatRegs && p.verC[j] != g_uni.verC[j]) { p.verC[j] = g_uni.verC[j]; ++j; }
    if (p.locC >= 0) gl::glUniform4fv(p.locC + i, j - i, g_uni.c + i * 4);
    i = j;
  }
  if (p.verB != g_uni.verB) { p.verB = g_uni.verB; if (p.locB >= 0) gl::glUniform1i(p.locB, g_uni.b); }
  if (p.verFrag != g_uni.verFrag) {
    p.verFrag = g_uni.verFrag;
    if (p.locStageColor >= 0) gl::glUniform4fv(p.locStageColor, 6, g_uni.stageColor);
    if (p.locBufColor >= 0) gl::glUniform4fv(p.locBufColor, 1, g_uni.bufColor);
    if (p.locAlphaRef >= 0) gl::glUniform1f(p.locAlphaRef, g_uni.alphaRef);
  }
}

struct PerfStats { uint64_t windowStart = 0, execNs = 0, swapNs = 0; unsigned frames = 0, draws = 0, progSwitches = 0; size_t geo = 0, tex = 0; };
PerfStats g_perf;

void execute(Frame& f) {
  const auto t0 = platform_now_ns();
  GlProgram* prog = nullptr;
  int curTarget = -1;
  int alphaFunc = -1, unit0Projection = 0, vertexProgram = 0;
  unsigned flipMask = 0, bufUpdate = 0;
  StageDesc stages[6] = {};
  bool programDirty = true;
  GLuint boundProgram = 0;
  bool scissorOn = false; int scissorBox[4] = {0, 0, 0, 0};
  auto restore_scissor = [&] { if (scissorOn) { gl::glEnable(GL_SCISSOR_TEST); gl::glScissor(scissorBox[0], scissorBox[1], scissorBox[2], scissorBox[3]); } else gl::glDisable(GL_SCISSOR_TEST); };
  int targetW = 0, targetH = 0; float curScale = 1.f;
  gl::glBindVertexArray(g_ex.vao);
  const int slot = g_ex.arenaSlot; g_ex.arenaSlot = (g_ex.arenaSlot + 1) % 3;
  if (!f.geo.empty()) {
    // one buffer holds the frame's vertices and indices (GLES 3 allows binding it to both targets)
    gl::glBindBuffer(GL_ARRAY_BUFFER, g_ex.arenaVbo[slot]);
    gl::glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(f.geo.size()), f.geo.data(), GL_STREAM_DRAW);
    gl::glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_ex.arenaVbo[slot]);
  }
  const uint8_t* arena = f.arena.data();
  static const bool glDebug = std::getenv("MKW_GL_DEBUG") != nullptr;
  size_t cmdIndex = 0;
  g_ex.inExecute.store(true); g_ex.curCmds.store(f.cmds.size());
  for (const Cmd& c : f.cmds) {
    g_ex.curOp.store(static_cast<int>(c.op)); g_ex.curCmd.store(cmdIndex);
    if (glDebug) { for (GLenum e; (e = gl::glGetError()) != GL_NO_ERROR;) SHIM_LOG("[gl] error 0x%x before cmd %zu (op %d)", e, cmdIndex, static_cast<int>(c.op)); }
    ++cmdIndex;
    switch (c.op) {
      case Op::CreateTarget: {
        GlTarget& t = g_ex.targets[c.createTarget.target];
        t.width = c.createTarget.width; t.height = c.createTarget.height; t.colorTexKey = c.createTarget.colorTexKey; t.depth = c.createTarget.depth;
        ensure_target(t);
        break;
      }
      case Op::DeleteTarget: {
        auto it = g_ex.targets.find(c.deleteTarget.target);
        if (it != g_ex.targets.end()) {
          GlTarget& t = it->second;
          if (t.fbo) gl::glDeleteFramebuffers(1, &t.fbo);
          if (t.ownsColor && t.color) gl::glDeleteTextures(1, &t.color);
          if (t.depth) gl::glDeleteRenderbuffers(1, &t.depth);
          g_ex.targets.erase(it);
        }
        break;
      }
      case Op::SetOutput: {
        auto it = g_ex.targets.find(c.setOutput.target);
        if (it != g_ex.targets.end()) { it->second.screen = c.setOutput.screen; it->second.side = c.setOutput.side; }
        break;
      }
      case Op::Target: {
        auto it = g_ex.targets.find(c.target.target);
        if (it == g_ex.targets.end()) break;
        ensure_target(it->second);
        gl::glBindFramebuffer(GL_FRAMEBUFFER, it->second.fbo);
        if (it->second.screen == 1) g_ex.bottomDrawn = true;
        curTarget = static_cast<int>(c.target.target); targetW = it->second.pw; targetH = it->second.ph; curScale = it->second.scale;
        gl::glViewport(0, 0, targetW, targetH);
        scissorOn = false; restore_scissor();
        break;
      }
      case Op::Clear: {
        auto it = g_ex.targets.find(c.clear.target);
        if (it == g_ex.targets.end()) break;
        ensure_target(it->second);
        gl::glBindFramebuffer(GL_FRAMEBUFFER, it->second.fbo);
        gl::glDisable(GL_SCISSOR_TEST);
        gl::glColorMask(1, 1, 1, 1); gl::glDepthMask(GL_TRUE); gl::glStencilMask(0xff);
        GLbitfield bits = 0;
        if (c.clear.bits & C3D_CLEAR_COLOR) { const u32 col = c.clear.color; gl::glClearColor(((col >> 24) & 0xff) / 255.f, ((col >> 16) & 0xff) / 255.f, ((col >> 8) & 0xff) / 255.f, (col & 0xff) / 255.f); bits |= GL_COLOR_BUFFER_BIT; }
        if (c.clear.bits & C3D_CLEAR_DEPTH) { gl::glClearDepthf((c.clear.depth & 0xffffff) / 16777215.f); gl::glClearStencil(static_cast<GLint>(c.clear.depth >> 24)); bits |= GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT; }
        gl::glClear(bits);
        // restore the draw target binding and the state the clear touched
        if (curTarget >= 0) { auto cur = g_ex.targets.find(static_cast<unsigned>(curTarget)); if (cur != g_ex.targets.end()) gl::glBindFramebuffer(GL_FRAMEBUFFER, cur->second.fbo); }
        restore_scissor();
        g_rec.effectDirty = true; // next draw re-applies masks (record side flag is safe: frames are sequential)
        break;
      }
      case Op::Viewport: gl::glViewport(scaled(c.viewport.x, curScale), scaled(c.viewport.y, curScale), scaled(c.viewport.w, curScale), scaled(c.viewport.h, curScale)); break;
      case Op::Scissor: {
        scissorOn = c.scissor.mode != GPU_SCISSOR_DISABLE;
        scissorBox[0] = scaled(c.scissor.left, curScale); scissorBox[1] = scaled(c.scissor.top, curScale);
        scissorBox[2] = scaled(c.scissor.right, curScale) - scissorBox[0]; scissorBox[3] = scaled(c.scissor.bottom, curScale) - scissorBox[1];
        restore_scissor();
        break;
      }
      case Op::Program: {
        if ((c.program.index & 1) != vertexProgram) { vertexProgram = c.program.index & 1; programDirty = true; }
        break;
      }
      case Op::Uniforms: {
        std::memcpy(g_uni.c + c.uniforms.first * 4, arena + c.uniforms.arena, static_cast<size_t>(c.uniforms.count) * 16);
        const uint32_t v = ++g_uni.counter;
        for (int i = 0; i < c.uniforms.count; ++i) g_uni.verC[c.uniforms.first + i] = v;
        break;
      }
      case Op::Bools: if (g_uni.b != static_cast<int>(c.bools.bits)) { g_uni.b = static_cast<int>(c.bools.bits); ++g_uni.verB; } break;
      case Op::TexEnv: {
        const C3D_TexEnv* env = reinterpret_cast<const C3D_TexEnv*>(arena + c.texenv.arena);
        for (int k = 0; k < 6; ++k) {
          const C3D_TexEnv& e = env[k];
          const StageDesc d{static_cast<uint16_t>(e.srcRgb), static_cast<uint16_t>(e.srcAlpha), static_cast<uint16_t>(e.opRgb), static_cast<uint16_t>(e.opAlpha),
                            static_cast<uint8_t>(e.funcRgb), static_cast<uint8_t>(e.funcAlpha), static_cast<uint8_t>(e.scaleRgb & 3), static_cast<uint8_t>(e.scaleAlpha & 3)};
          if (std::memcmp(&d, &stages[k], sizeof d) != 0) { stages[k] = d; programDirty = true; }
          g_uni.stageColor[k * 4] = (e.color & 0xff) / 255.f; g_uni.stageColor[k * 4 + 1] = ((e.color >> 8) & 0xff) / 255.f;
          g_uni.stageColor[k * 4 + 2] = ((e.color >> 16) & 0xff) / 255.f; g_uni.stageColor[k * 4 + 3] = ((e.color >> 24) & 0xff) / 255.f;
        }
        const u32 bc = c.texenv.bufColor;
        g_uni.bufColor[0] = (bc & 0xff) / 255.f; g_uni.bufColor[1] = ((bc >> 8) & 0xff) / 255.f; g_uni.bufColor[2] = ((bc >> 16) & 0xff) / 255.f; g_uni.bufColor[3] = ((bc >> 24) & 0xff) / 255.f;
        ++g_uni.verFrag;
        if (c.texenv.bufUpdate != bufUpdate) { bufUpdate = c.texenv.bufUpdate; programDirty = true; }
        break;
      }
      case Op::Effect: {
        const EffectState& e = *reinterpret_cast<const EffectState*>(arena + c.effect.arena);
        apply_effect(e);
        const int af = e.alphaTest ? static_cast<int>(e.alphaFunc) : -1;
        if (af != alphaFunc) { alphaFunc = af; programDirty = true; }
        if (g_uni.alphaRef != e.alphaRef / 255.f) { g_uni.alphaRef = e.alphaRef / 255.f; ++g_uni.verFrag; }
        break;
      }
      case Op::BindTex: {
        if (c.bindTex.unit == 0) { const int proj = c.bindTex.key && ((c.bindTex.param >> 28) & 7) == GPU_TEX_PROJECTION; if (proj != unit0Projection) { unit0Projection = proj; programDirty = true; } }
        gl::glActiveTexture(GL_TEXTURE0 + c.bindTex.unit);
        if (!c.bindTex.key) { gl::glBindTexture(GL_TEXTURE_2D, g_ex.whiteTex); if (flipMask & (1u << c.bindTex.unit)) { flipMask &= ~(1u << c.bindTex.unit); programDirty = true; } break; }
        GlTexture& t = gl_texture(c.bindTex.key);
        { const unsigned bit = 1u << c.bindTex.unit, fl = t.valid && t.flipV ? bit : 0u; if ((flipMask & bit) != fl) { flipMask = (flipMask & ~bit) | fl; programDirty = true; } }
        gl::glBindTexture(GL_TEXTURE_2D, t.valid ? t.id : g_ex.whiteTex);
        if (t.valid) apply_tex_params(t, c.bindTex.param);
        break;
      }
      case Op::UploadTex: {
        GlTexture& t = gl_texture(c.uploadTex.key);
        gl::glActiveTexture(GL_TEXTURE0 + 3); // scratch unit
        gl::glBindTexture(GL_TEXTURE_2D, t.id);
        const uint8_t* pixels = arena + c.uploadTex.arena;
        gl::glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        if (c.uploadTex.compressed) {
          gl::glCompressedTexImage2D(GL_TEXTURE_2D, 0, GL_COMPRESSED_RGB8_ETC2, c.uploadTex.width, c.uploadTex.height, 0, static_cast<GLsizei>(c.uploadTex.bytes), pixels);
        } else if (t.valid && t.width == c.uploadTex.width && t.height == c.uploadTex.height && c.uploadTex.fmt == 0) {
          gl::glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, c.uploadTex.width, c.uploadTex.height, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
        } else {
          gl::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, c.uploadTex.width, c.uploadTex.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
        }
        t.valid = true; t.flipV = true; t.width = c.uploadTex.width; t.height = c.uploadTex.height; t.appliedParam = 0xffffffff;
        gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); gl::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        break;
      }
      case Op::DeleteTex: {
        auto it = g_ex.textures.find(c.deleteTex.key);
        if (it != g_ex.textures.end()) { if (it->second.id) gl::glDeleteTextures(1, &it->second.id); g_ex.textures.erase(it); }
        break;
      }
      case Op::Draw: {
        if (programDirty || !prog) {
          prog = &get_program(make_frag_key(stages, bufUpdate, alphaFunc, unit0Projection != 0, false, flipMask, vertexProgram));
          programDirty = false;
        }
        if (prog->id != boundProgram) { boundProgram = prog->id; gl::glUseProgram(prog->id); ++g_perf.progSwitches; }
        sync_uniforms(*prog);
        const DrawLayout& layout = *reinterpret_cast<const DrawLayout*>(arena + c.draw.layoutArena);
        const void* boundKey = reinterpret_cast<const void*>(1);
        unsigned enabled = 0;
        for (int i = 0; i < layout.attrCount; ++i) {
          const DrawLayout::Attr& a = layout.attrs[i];
          if (a.key != boundKey) {
            boundKey = a.key;
            if (!a.key) gl::glBindBuffer(GL_ARRAY_BUFFER, g_ex.arenaVbo[slot]);
            else { auto it = g_ex.buffers.find(a.key); gl::glBindBuffer(GL_ARRAY_BUFFER, it != g_ex.buffers.end() ? it->second : 0); }
          }
          GLenum type = GL_FLOAT; GLboolean norm = GL_FALSE;
          switch (a.format) { case GPU_BYTE: type = GL_BYTE; break; case GPU_UNSIGNED_BYTE: type = GL_UNSIGNED_BYTE; break; case GPU_SHORT: type = GL_SHORT; break; default: type = GL_FLOAT; }
          gl::glEnableVertexAttribArray(static_cast<GLuint>(a.reg));
          gl::glVertexAttribPointer(static_cast<GLuint>(a.reg), a.count, type, norm, static_cast<GLsizei>(a.stride), reinterpret_cast<const void*>(a.offset));
          enabled |= 1u << a.reg;
        }
        for (int r = 0; r < 5; ++r) if (!(enabled & (1u << r))) gl::glDisableVertexAttribArray(static_cast<GLuint>(r));
        const GLenum prim = c.draw.prim == GPU_TRIANGLE_STRIP ? GL_TRIANGLE_STRIP : c.draw.prim == GPU_TRIANGLE_FAN ? GL_TRIANGLE_FAN : GL_TRIANGLES;
        if (c.draw.indexType >= 0) {
          if (c.draw.indexKey) {
            auto it = g_ex.buffers.find(c.draw.indexKey);
            gl::glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, it != g_ex.buffers.end() ? it->second : 0);
            gl::glDrawElements(prim, static_cast<GLsizei>(c.draw.count), c.draw.indexType == 0 ? GL_UNSIGNED_BYTE : GL_UNSIGNED_SHORT, reinterpret_cast<const void*>(c.draw.indexArena));
          } else {
            gl::glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_ex.arenaVbo[slot]);
            gl::glDrawElements(prim, static_cast<GLsizei>(c.draw.count), GL_UNSIGNED_SHORT /* indices are widened to 16 bits at record time */, reinterpret_cast<const void*>(c.draw.indexArena));
          }
        } else {
          gl::glDrawArrays(prim, c.draw.first, static_cast<GLsizei>(c.draw.count));
        }
        break;
      }
      case Op::Split: gl::glFlush(); break;
      case Op::UploadBuf: {
        GLuint& b = g_ex.buffers[c.uploadBuf.key];
        if (!b) gl::glGenBuffers(1, &b);
        gl::glBindBuffer(GL_ARRAY_BUFFER, b);
        if (c.uploadBuf.create) gl::glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(c.uploadBuf.size), arena + c.uploadBuf.arena, GL_DYNAMIC_DRAW);
        else gl::glBufferSubData(GL_ARRAY_BUFFER, static_cast<GLintptr>(c.uploadBuf.offset), static_cast<GLsizeiptr>(c.uploadBuf.size), arena + c.uploadBuf.arena);
        break;
      }
      case Op::DeleteBuf: {
        auto it = g_ex.buffers.find(c.deleteBuf.key);
        if (it != g_ex.buffers.end()) { gl::glDeleteBuffers(1, &it->second); g_ex.buffers.erase(it); }
        break;
      }
      case Op::ReadTarget: {
        auto it = g_ex.targets.find(c.readTarget.target);
        if (it == g_ex.targets.end()) break;
        ensure_target(it->second);
        gl::glBindFramebuffer(GL_FRAMEBUFFER, it->second.fbo);
        if (it->second.scale != 1.f) { // shrink a scaled target to the size the game expects, then read that
          if (!g_ex.readFbo) { gl::glGenFramebuffers(1, &g_ex.readFbo); gl::glGenTextures(1, &g_ex.readTex); }
          if (g_ex.readW != c.readTarget.width || g_ex.readH != c.readTarget.height) {
            g_ex.readW = c.readTarget.width; g_ex.readH = c.readTarget.height;
            gl::glActiveTexture(GL_TEXTURE0 + 3); gl::glBindTexture(GL_TEXTURE_2D, g_ex.readTex);
            gl::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, g_ex.readW, g_ex.readH, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
            gl::glBindFramebuffer(GL_DRAW_FRAMEBUFFER, g_ex.readFbo);
            gl::glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_ex.readTex, 0);
          }
          gl::glDisable(GL_SCISSOR_TEST);
          gl::glBindFramebuffer(GL_READ_FRAMEBUFFER, it->second.fbo); gl::glBindFramebuffer(GL_DRAW_FRAMEBUFFER, g_ex.readFbo);
          gl::glBlitFramebuffer(0, 0, it->second.pw, it->second.ph, 0, 0, g_ex.readW, g_ex.readH, GL_COLOR_BUFFER_BIT, GL_LINEAR);
          gl::glBindFramebuffer(GL_FRAMEBUFFER, g_ex.readFbo);
          restore_scissor();
        }
        const size_t n = static_cast<size_t>(c.readTarget.width) * c.readTarget.height;
        g_ex.scratch.resize(n * 4);
        gl::glReadPixels(0, 0, c.readTarget.width, c.readTarget.height, GL_RGBA, GL_UNSIGNED_BYTE, g_ex.scratch.data());
        uint8_t* d = static_cast<uint8_t*>(c.readTarget.dest);
        if (c.readTarget.rgb8) for (size_t i = 0; i < n; ++i) { d[i * 3] = g_ex.scratch[i * 4 + 2]; d[i * 3 + 1] = g_ex.scratch[i * 4 + 1]; d[i * 3 + 2] = g_ex.scratch[i * 4]; }
        else for (size_t i = 0; i < n; ++i) { d[i * 4] = g_ex.scratch[i * 4 + 3]; d[i * 4 + 1] = g_ex.scratch[i * 4 + 2]; d[i * 4 + 2] = g_ex.scratch[i * 4 + 1]; d[i * 4 + 3] = g_ex.scratch[i * 4]; }
        if (curTarget >= 0) { auto cur = g_ex.targets.find(static_cast<unsigned>(curTarget)); if (cur != g_ex.targets.end()) gl::glBindFramebuffer(GL_FRAMEBUFFER, cur->second.fbo); }
        break;
      }
      case Op::ScreenCpu: {
        // 3DS framebuffer: 240 x W BGR8, column-major (screen x advances by 240*3 bytes), row 0 = screen bottom.
        const int s = c.screenCpu.screen;
        const unsigned W = kScreenW[s];
        const uint8_t* fb = arena + c.screenCpu.arena;
        g_ex.scratch.resize(static_cast<size_t>(W) * kScreenH * 4);
        for (unsigned sx = 0; sx < W; ++sx)
          for (unsigned sy = 0; sy < kScreenH; ++sy) {
            const uint8_t* p = fb + (sx * kScreenH + (kScreenH - 1 - sy)) * 3;
            uint8_t* o = g_ex.scratch.data() + ((kScreenH - 1 - sy) * W + sx) * 4; // GL row 0 = bottom
            o[0] = p[2]; o[1] = p[1]; o[2] = p[0]; o[3] = 255;
          }
        ensure_screen_tex(s, static_cast<int>(W), static_cast<int>(kScreenH));
        gl::glActiveTexture(GL_TEXTURE0 + 3); gl::glBindTexture(GL_TEXTURE_2D, g_ex.screenTex[s]);
        gl::glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, W, kScreenH, GL_RGBA, GL_UNSIGNED_BYTE, g_ex.scratch.data());
        g_ex.screenLastWriter[s] = 2;
        break;
      }
      case Op::Present: {
        for (auto& [id, t] : g_ex.targets) if (t.screen >= 0 && t.side == 0 && t.fbo && (t.screen == 0 || show_bottom() || g_ex.bottomDrawn)) { target_to_screen(t, t.screen); g_ex.screenLastWriter[t.screen] = 1; }
        present_screens();
        g_ex.bottomDrawn = false;
        boundProgram = 0;
        {
          static int every = std::getenv("MKW_SCREENSHOT_EVERY") ? std::atoi(std::getenv("MKW_SCREENSHOT_EVERY")) : 0;
          static unsigned presented = 0;
          std::string path;
          ++presented;
          const bool periodic = every > 0 && presented % static_cast<unsigned>(every) == 0;
          if (platform_screenshot_pending(path) || periodic) {
            if (periodic) path = std::string(std::getenv("MKW_SCREENSHOT_DIR") ? std::getenv("MKW_SCREENSHOT_DIR") : ".") + "/frame_" + std::to_string(presented) + ".ppm";
            const ScreenSize s = platform_screen();
            g_ex.scratch.resize(static_cast<size_t>(s.width) * s.height * 4);
            gl::glReadPixels(0, 0, s.width, s.height, GL_RGBA, GL_UNSIGNED_BYTE, g_ex.scratch.data());
            if (FILE* f = std::fopen(path.c_str(), "wb")) {
              std::fprintf(f, "P6\n%d %d\n255\n", s.width, s.height);
              for (int y = s.height - 1; y >= 0; --y) for (int x = 0; x < s.width; ++x) std::fwrite(g_ex.scratch.data() + (static_cast<size_t>(y) * s.width + x) * 4, 1, 3, f);
              std::fclose(f);
            }
          }
        }
        { const uint64_t s0 = platform_now_ns(); platform_swap(); g_perf.swapNs += platform_now_ns() - s0; }
        { std::lock_guard lock(g_ex.vblankMutex); ++g_ex.vblankCount; }
        g_ex.vblankCv.notify_all();
        g_rec.framesPresented.fetch_add(1, std::memory_order_relaxed);
        break;
      }
    }
  }
  g_ex.inExecute.store(false);
  const uint64_t t1 = platform_now_ns();
  g_ex.processingMs = (t1 - t0) / 1e6;
  g_perf.execNs += t1 - t0; g_perf.draws += f.draws; g_perf.geo += f.geo.size(); g_perf.tex += f.texBytes;
  if (f.present) ++g_perf.frames;
  if (!g_perf.windowStart) g_perf.windowStart = t1;
  if (t1 - g_perf.windowStart >= 2000000000ull && g_perf.frames) {
    const double secs = (t1 - g_perf.windowStart) / 1e9, n = g_perf.frames;
    SHIM_LOG("[perf] fps=%.1f gpu-thread=%.1fms (swap %.1fms) draws=%.0f geo=%.0fKB tex=%.0fKB/frame programs=%u switches=%.0f",
             n / secs, g_perf.execNs / 1e6 / n, g_perf.swapNs / 1e6 / n, g_perf.draws / n, g_perf.geo / 1024.0 / n, g_perf.tex / 1024.0 / n,
             g_ex.programsBuilt, g_perf.progSwitches / n);
    g_perf = PerfStats{}; g_perf.windowStart = t1;
  }
}

void executor_main() {
  platform_make_current();
  executor_init();
  warm_programs();
  for (;;) {
    std::unique_ptr<Frame> f;
    {
      std::unique_lock lock(g_ex.mutex);
      g_ex.cv.wait(lock, [] { return g_ex.stop.load() || !g_ex.queue.empty(); });
      if (g_ex.stop.load() && g_ex.queue.empty()) break;
      f = std::move(g_ex.queue.front()); g_ex.queue.pop_front();
    }
    execute(*f);
    f->done.store(true);
    { std::lock_guard lock(g_ex.mutex); --g_ex.inFlight; if (g_ex.pool.size() < 4) g_ex.pool.push_back(std::move(f)); }
    g_ex.doneCv.notify_all();
  }
}

// ---------------------------------------------------------------- recorder helpers
// The game records GPU work on its render thread, but creates/flushes textures on loader and
// movie threads too; every entry point that touches the recorder takes this lock.
std::recursive_mutex g_recMutex;
// Who holds the recorder lock (hang reports): thread and the shim function it is in.
std::atomic<const char*> g_recOwnerSite{nullptr}; std::atomic<unsigned long> g_recOwnerThread{0};
struct RecGuard {
  const char* prevSite; unsigned long prevThread; bool outer;
  explicit RecGuard(const char* site) {
    g_recMutex.lock();
    prevSite = g_recOwnerSite.load(); prevThread = g_recOwnerThread.load();
    outer = prevThread != (unsigned long)pthread_self();
    g_recOwnerSite.store(site); g_recOwnerThread.store((unsigned long)pthread_self());
  }
  ~RecGuard() {
    if (outer) { g_recOwnerSite.store(nullptr); g_recOwnerThread.store(0); }
    else g_recOwnerSite.store(prevSite);
    g_recMutex.unlock();
  }
};
#define REC_LOCK RecGuard recLock_(__func__)
Frame& frame() {
  if (!g_rec.frame) {
    { std::lock_guard lock(g_ex.mutex); if (!g_ex.pool.empty()) { g_rec.frame = std::move(g_ex.pool.back()); g_ex.pool.pop_back(); } }
    if (g_rec.frame) g_rec.frame->reset(); else g_rec.frame = std::make_unique<Frame>();
  }
  return *g_rec.frame;
}
Cmd& emit(Op op) { Cmd c{}; c.op = op; frame().cmds.push_back(c); return frame().cmds.back(); }
void submit_frame(bool present) {
  if (!g_rec.frame) return;
  g_rec.frame->present = present;
  if (present) ++g_rec.frameIndex;
  {
    std::unique_lock lock(g_ex.mutex);
    // at most one frame executing + one queued: FrameBegin pacing comes from here
    g_mainState.store("submit_frame");
    g_ex.doneCv.wait(lock, [] { return g_ex.inFlight < 2; });
    g_mainState.store("running");
    g_ex.queue.push_back(std::move(g_rec.frame));
    ++g_ex.inFlight;
  }
  g_ex.cv.notify_all();
  // state that the executor keeps across frames must be re-emitted into the next frame
  g_rec.texEnvDirty = g_rec.effectDirty = g_rec.programDirty = true;
  for (bool& d : g_rec.texDirty) d = true;
  for (int i = 0; i < kFloatRegs; ++i) C3D_FVUnifDirty[0][i] = true;
  C3D_BoolUnifsDirty[0] = true;
}
void wait_idle() {
  g_mainState.store("wait_idle");
  std::unique_lock lock(g_ex.mutex);
  g_ex.doneCv.wait(lock, [] { return g_ex.inFlight == 0; });
  g_mainState.store("running");
}
void record_tex_upload(const void* key);
void flush_state_for_draw() {
  if (!g_rec.pendingUploads.empty()) { for (const void* key : g_rec.pendingUploads) record_tex_upload(key); g_rec.pendingUploads.clear(); }
  Frame& f = frame();
  if (g_rec.programDirty) { Cmd& c = emit(Op::Program); c.program.index = g_rec.program && g_rec.program->vertexShader && g_rec.program->vertexShader->dvle ? static_cast<int>(g_rec.program->vertexShader->dvle->mainOffset) : 0; g_rec.programDirty = false; }
  int first = -1, last = -1;
  for (int i = 0; i < kFloatRegs; ++i) if (C3D_FVUnifDirty[0][i]) { if (first < 0) first = i; last = i; C3D_FVUnifDirty[0][i] = false; }
  if (first >= 0) {
    Cmd& c = emit(Op::Uniforms);
    c.uniforms.first = first; c.uniforms.count = last - first + 1;
    // C3D_FVec is stored w,z,y,x in memory (PICA register order); GL wants x,y,z,w
    c.uniforms.arena = f.push(nullptr, sizeof(C3D_FVec) * static_cast<size_t>(c.uniforms.count), 16);
    float* dst = reinterpret_cast<float*>(f.arena.data() + c.uniforms.arena);
    for (int i = 0; i < c.uniforms.count; ++i) { const C3D_FVec& v = C3D_FVUnif[0][first + i]; dst[i * 4] = v.x; dst[i * 4 + 1] = v.y; dst[i * 4 + 2] = v.z; dst[i * 4 + 3] = v.w; }
  }
  if (C3D_BoolUnifsDirty[0]) { Cmd& c = emit(Op::Bools); c.bools.bits = C3D_BoolUnifs[0]; C3D_BoolUnifsDirty[0] = false; }
  if (g_rec.texEnvDirty) { Cmd& c = emit(Op::TexEnv); c.texenv.arena = f.push(g_rec.texEnv, sizeof g_rec.texEnv); c.texenv.bufUpdate = g_rec.texEnvBuf; c.texenv.bufColor = g_rec.texEnvBufClr; g_rec.texEnvDirty = false; }
  if (g_rec.effectDirty) { Cmd& c = emit(Op::Effect); c.effect.arena = f.push(&g_rec.effect, sizeof g_rec.effect); g_rec.effectDirty = false; }
  for (int u = 0; u < 3; ++u) if (g_rec.texDirty[u]) { Cmd& c = emit(Op::BindTex); c.bindTex.unit = u; c.bindTex.key = g_rec.tex[u].key; c.bindTex.param = g_rec.tex[u].param; g_rec.texDirty[u] = false; }
}
size_t attr_size(int format, int count) { return static_cast<size_t>(format == GPU_FLOAT ? 4 : format == GPU_SHORT ? 2 : 1) * static_cast<size_t>(count); }

bool buffer_cache_enabled() { static const bool on = !std::getenv("MKW_VBO_CACHE") || std::atoi(std::getenv("MKW_VBO_CACHE")) != 0; return on; }
// The GL buffer for the allocation holding p, when it is stable; returns the key and p's offset.
const void* cached_buffer(const void* p, size_t* offset) {
  if (!buffer_cache_enabled()) return nullptr;
  const void* base; size_t size;
  if (!shim_linear_lookup(p, &base, &size)) return nullptr;
  Recorder::BufRecord& r = g_rec.buffers[reinterpret_cast<uintptr_t>(base)];
  if (!r.flushed || g_rec.frameIndex - r.lastFlushFrame < 3) return nullptr;
  if (!r.uploaded || r.size != size) {
    Frame& f = frame();
    r.size = size; r.uploaded = true;
    Cmd& c = emit(Op::UploadBuf); c.uploadBuf.key = base; c.uploadBuf.offset = 0; c.uploadBuf.size = size; c.uploadBuf.create = true;
    c.uploadBuf.arena = f.push(base, size, 16);
    f.texBytes += size;
  }
  *offset = static_cast<size_t>(static_cast<const uint8_t*>(p) - static_cast<const uint8_t*>(base));
  return base;
}
// A CPU write was flushed: the allocation is dynamic for now; drop its GL copy.
void buffer_mark_dirty(const void* addr, size_t size) {
  (void)size;
  const void* base; size_t allocSize;
  if (!shim_linear_lookup(addr, &base, &allocSize)) return;
  Recorder::BufRecord& r = g_rec.buffers[reinterpret_cast<uintptr_t>(base)];
  r.flushed = true; r.lastFlushFrame = g_rec.frameIndex;
  if (r.uploaded) { r.uploaded = false; Cmd& c = emit(Op::DeleteBuf); c.deleteBuf.key = base; }
}
extern "C" void shim_buffer_freed(const void* base) {
  REC_LOCK;
  auto it = g_rec.buffers.find(reinterpret_cast<uintptr_t>(base));
  if (it == g_rec.buffers.end()) return;
  g_rec.buffers.erase(it);
  Cmd& c = emit(Op::DeleteBuf); c.deleteBuf.key = base;
}

void record_draw(int prim, int first, int count, int indexType, const void* indices) {
  if (g_rec.skipping) return; // state stays dirty and is emitted with the next visible draw
  if (count <= 0) return;
  flush_state_for_draw();
  Frame& f = frame();
  // Fast path: every buffer (and the indices) lives in cached LINEAR memory.
  {
    bool cached = buffer_cache_enabled();
    const void* keys[12] = {}; size_t offs[12] = {};
    for (int b = 0; cached && b < g_rec.bufInfo.bufCount; ++b) { keys[b] = cached_buffer(g_rec.bufInfo.buffers[b].data, &offs[b]); if (!keys[b]) cached = false; }
    const void* indexKey = nullptr; size_t indexOff = 0;
    if (cached && indexType >= 0) { indexKey = cached_buffer(indices, &indexOff); if (!indexKey) cached = false; }
    if (cached) {
      DrawLayout layout{}; layout.attrCount = 0;
      for (int b = 0; b < g_rec.bufInfo.bufCount; ++b) {
        const C3D_BufCfg& buf = g_rec.bufInfo.buffers[b];
        size_t within = 0;
        for (unsigned i = 0; i < buf.attribCount; ++i) {
          const int attrIndex = static_cast<int>((buf.permutation >> (i * 4)) & 0xf);
          if (attrIndex >= g_rec.attrInfo.attrCount) break;
          const C3D_AttrEntry& e = g_rec.attrInfo.entries[attrIndex];
          const size_t sz = attr_size(e.format, e.count);
          if (e.format == GPU_FLOAT && (within & 3)) within = (within + 3) & ~size_t(3);
          DrawLayout::Attr& a = layout.attrs[layout.attrCount++];
          a.reg = e.regId; a.count = e.count; a.format = e.format; a.offset = offs[b] + within; a.stride = buf.stride; a.key = keys[b];
          within += sz;
        }
      }
      Cmd& c = emit(Op::Draw);
      c.draw.prim = prim; c.draw.count = static_cast<unsigned>(count); c.draw.indexType = indexType; c.draw.first = first;
      c.draw.layoutArena = f.push(&layout, sizeof layout, 16);
      c.draw.indexKey = indexKey; c.draw.indexArena = indexOff;
      ++f.draws;
      return;
    }
  }
  // vertex range
  unsigned minV = static_cast<unsigned>(first), maxV = static_cast<unsigned>(first + count - 1);
  std::vector<uint16_t>& idx16 = *[]() { static thread_local std::vector<uint16_t> v; return &v; }();
  if (indexType >= 0) {
    minV = 0xffffffffu; maxV = 0;
    if (indexType == 0) { const uint8_t* p = static_cast<const uint8_t*>(indices); for (int i = 0; i < count; ++i) { minV = std::min<unsigned>(minV, p[i]); maxV = std::max<unsigned>(maxV, p[i]); } }
    else { const uint16_t* p = static_cast<const uint16_t*>(indices); for (int i = 0; i < count; ++i) { minV = std::min<unsigned>(minV, p[i]); maxV = std::max<unsigned>(maxV, p[i]); } }
    if (count <= 0) return;
    idx16.resize(static_cast<size_t>(count));
    if (indexType == 0) { const uint8_t* p = static_cast<const uint8_t*>(indices); for (int i = 0; i < count; ++i) idx16[i] = static_cast<uint16_t>(p[i] - minV); }
    else { const uint16_t* p = static_cast<const uint16_t*>(indices); for (int i = 0; i < count; ++i) idx16[i] = static_cast<uint16_t>(p[i] - minV); }
  }
  const unsigned vertexCount = maxV - minV + 1;
  // layout: walk the attribute loaders and the buffers they live in
  DrawLayout layout{}; layout.attrCount = 0;
  size_t attrOffset[16] = {};
  for (int b = 0; b < g_rec.bufInfo.bufCount; ++b) {
    const C3D_BufCfg& buf = g_rec.bufInfo.buffers[b];
    const size_t bytes = static_cast<size_t>(buf.stride) * vertexCount;
    const size_t at = f.geo.push(static_cast<const uint8_t*>(buf.data) + static_cast<size_t>(minV) * buf.stride, bytes, 16);
    size_t within = 0;
    for (unsigned i = 0; i < buf.attribCount; ++i) {
      const int attrIndex = static_cast<int>((buf.permutation >> (i * 4)) & 0xf);
      if (attrIndex >= g_rec.attrInfo.attrCount) break;
      const C3D_AttrEntry& e = g_rec.attrInfo.entries[attrIndex];
      // PICA pads attribute loads to 4-byte alignment between differently sized attributes
      const size_t sz = attr_size(e.format, e.count);
      if (e.format == GPU_FLOAT && (within & 3)) within = (within + 3) & ~size_t(3);
      DrawLayout::Attr& a = layout.attrs[layout.attrCount++];
      a.reg = e.regId; a.count = e.count; a.format = e.format; a.offset = at + within; a.stride = buf.stride; a.key = nullptr;
      within += sz; (void)attrOffset;
    }
  }
  Cmd& c = emit(Op::Draw);
  c.draw.prim = prim; c.draw.count = static_cast<unsigned>(count); c.draw.indexType = indexType; c.draw.first = 0; c.draw.indexKey = nullptr;
  c.draw.layoutArena = f.push(&layout, sizeof layout, 16);
  c.draw.indexArena = indexType >= 0 ? f.geo.push(idx16.data(), idx16.size() * 2, 16) : 0;
  ++f.draws;
}

void record_tex_upload(const void* key) {
  auto it = g_rec.textures.find(key);
  if (it == g_rec.textures.end()) return;
  const Recorder::TexRecord& r = it->second;
  Frame& f = frame();
  Cmd& c = emit(Op::UploadTex);
  c.uploadTex.key = key; c.uploadTex.width = r.width; c.uploadTex.height = r.height; c.uploadTex.fmt = 0;
  if (r.fmt == GPU_ETC1) {
    const size_t bytes = static_cast<size_t>(r.width) * r.height / 2;
    c.uploadTex.arena = f.push(nullptr, bytes, 16); c.uploadTex.bytes = bytes; c.uploadTex.compressed = true; f.texBytes += bytes;
    texdecode::etc1_to_linear(r.width, r.height, static_cast<const uint8_t*>(key), f.arena.data() + c.uploadTex.arena);
  } else {
    const size_t bytes = static_cast<size_t>(r.width) * r.height * 4;
    c.uploadTex.arena = f.push(nullptr, bytes, 16); c.uploadTex.bytes = bytes; c.uploadTex.compressed = false; f.texBytes += bytes;
    texdecode::to_rgba8(r.fmt, r.width, r.height, static_cast<const uint8_t*>(key), f.arena.data() + c.uploadTex.arena);
  }
}
} // namespace

// GSPGPU_FlushDataCache: the CPU wrote memory the GPU reads. Texture memory gets re-uploaded
// before the next draw (the intro movie streams its frames this way).
extern "C" void shim_cpu_flush(const void* addr, u32 size) {
  REC_LOCK;
  if (!size) return;
  buffer_mark_dirty(addr, size);
  if (g_rec.texByAddr.empty()) return;
  const uintptr_t a = reinterpret_cast<uintptr_t>(addr);
  auto it = g_rec.texByAddr.upper_bound(a);
  if (it == g_rec.texByAddr.begin()) return;
  --it;
  auto rec = g_rec.textures.find(it->second);
  if (rec == g_rec.textures.end() || a >= it->first + rec->second.bytes) return;
  if (std::find(g_rec.pendingUploads.begin(), g_rec.pendingUploads.end(), it->second) == g_rec.pendingUploads.end()) g_rec.pendingUploads.push_back(it->second);
}

int shim_uniform_location(int program, const char* name) {
  if (program == 0) { for (const UniformName& u : kSceneUniforms) if (std::strcmp(u.name, name) == 0) return u.reg; }
  else { for (const UniformName& u : kEffectUniforms) if (std::strcmp(u.name, name) == 0) return u.reg; }
  return -1;
}

// ---------------------------------------------------------------- public API: base
// Hang report: the watchdog asks the game thread where it is (addresses relative to the binary).
static pthread_t g_gameThread; static pid_t g_gameTid = 0; static uintptr_t g_exeBase = 0;
static void hang_report(int) {
  void* pcs[48]; const int n = backtrace(pcs, 48);
  char line[96];
  for (int i = 0; i < n; ++i) {
    const int len = std::snprintf(line, sizeof line, "[hang] t%ld #%d +0x%lx\n", (long)gettid(), i, (unsigned long)(reinterpret_cast<uintptr_t>(pcs[i]) - g_exeBase));
    if (len > 0) { ssize_t w = write(2, line, size_t(len)); (void)w; }
  }
}
extern "C" bool C3D_Init(size_t) {
  g_gameThread = pthread_self(); g_gameTid = gettid();
  { Dl_info info{}; if (dladdr(reinterpret_cast<void*>(&hang_report), &info)) g_exeBase = reinterpret_cast<uintptr_t>(info.dli_fbase); }
  std::signal(SIGUSR2, hang_report);
  std::memset(C3D_FVUnif, 0, sizeof C3D_FVUnif); std::memset(C3D_BoolUnifs, 0, sizeof C3D_BoolUnifs);
  for (int i = 0; i < 6; ++i) C3D_TexEnvInit(&g_rec.texEnv[i]);
  g_ex.stop = false;
  g_ex.thread = std::thread(executor_main);
  static std::thread watchdog([] {
    uint32_t last = 0; int quiet = 0;
    while (!g_ex.stop.load()) {
      std::this_thread::sleep_for(std::chrono::seconds(2));
      const uint32_t now = g_rec.framesPresented.load();
      if (now == last) {
        if (++quiet >= 2) SHIM_LOG("[watchdog] no frame presented for %d s: executor %s op %d, cmd %zu/%zu, queued frames %zu, in flight %zu, game thread: %s",
                                   quiet * 2, g_ex.inExecute.load() ? "inside" : "idle", g_ex.curOp.load(), g_ex.curCmd.load(), g_ex.curCmds.load(), g_ex.queue.size(), g_ex.inFlight, g_mainState.load());
        // Game thread stuck outside the GPU path: log where (twice), then quit after 20 s so the
        // handheld is not left frozen (no other way out: the quit buttons are read by that thread).
        if ((quiet == 3 || quiet == 6) && !g_ex.inExecute.load()) {
          const unsigned long owner = g_recOwnerThread.load(); const char* site = g_recOwnerSite.load();
          SHIM_LOG("[hang] game thread:"); pthread_kill(g_gameThread, SIGUSR2);
          std::this_thread::sleep_for(std::chrono::milliseconds(300));
          SHIM_LOG("[hang] recorder lock held by %s thread in %s", owner == 0 ? "no" : owner == (unsigned long)g_gameThread ? "the game" : "another", site ? site : "-");
          if (owner && owner != (unsigned long)g_gameThread) pthread_kill(pthread_t(owner), SIGUSR2);
          std::this_thread::sleep_for(std::chrono::milliseconds(300));
          if (quiet == 6) { // every thread, so a lock cycle shows both sides
            SHIM_LOG("[hang] all threads (game thread is t%ld):", (long)g_gameTid);
            if (DIR* d = opendir("/proc/self/task")) {
              while (dirent* e = readdir(d)) {
                const long tid = std::atol(e->d_name); if (tid <= 0 || tid == (long)gettid()) continue;
                char path[64], name[32] = "?"; std::snprintf(path, sizeof path, "/proc/self/task/%ld/comm", tid);
                if (FILE* f = std::fopen(path, "r")) { if (std::fgets(name, sizeof name, f)) name[std::strcspn(name, "\n")] = 0; std::fclose(f); }
                SHIM_LOG("[hang] thread t%ld %s", tid, name);
                syscall(SYS_tgkill, getpid(), tid, SIGUSR2);
                std::this_thread::sleep_for(std::chrono::milliseconds(150));
              }
              closedir(d);
            }
          }
        }
        if (quiet >= 10 && g_ex.queue.empty() && g_ex.inFlight == 0 && !g_ex.inExecute.load() && !std::getenv("MKW_NO_HANG_EXIT")) { SHIM_LOG("[watchdog] game stuck for 20 s, quitting"); std::fflush(nullptr); _exit(3); }
      } else quiet = 0;
      last = now;
    }
  });
  watchdog.detach();
  return true;
}
extern "C" void C3D_Fini(void) {
  wait_idle();
  g_ex.stop = true; g_ex.cv.notify_all();
  if (g_ex.thread.joinable()) g_ex.thread.join();
}
extern "C" float C3D_GetCmdBufUsage(void) { return 0.1f; }
extern "C" void C3D_BindProgram(shaderProgram_s* program) { REC_LOCK; g_rec.program = program; g_rec.programDirty = true; }
extern "C" void C3D_SetViewport(u32 x, u32 y, u32 w, u32 h) { REC_LOCK; if (g_rec.skipping) return; Cmd& c = emit(Op::Viewport); c.viewport = {static_cast<int>(x), static_cast<int>(y), static_cast<int>(w), static_cast<int>(h)}; }
extern "C" void C3D_SetScissor(GPU_SCISSORMODE mode, u32 left, u32 top, u32 right, u32 bottom) { REC_LOCK; if (g_rec.skipping) return; Cmd& c = emit(Op::Scissor); c.scissor = {mode, static_cast<int>(left), static_cast<int>(top), static_cast<int>(right), static_cast<int>(bottom)}; }
extern "C" void C3D_DrawArrays(GPU_Primitive_t primitive, int first, int size) { REC_LOCK; record_draw(primitive, first, size, -1, nullptr); }
extern "C" void C3D_DrawElements(GPU_Primitive_t primitive, int count, int type, const void* indices) { REC_LOCK; record_draw(primitive, 0, count, type, indices); }
extern "C" void C3D_ImmDrawBegin(GPU_Primitive_t) {}
extern "C" void C3D_ImmSendAttrib(float, float, float, float) {}
extern "C" void C3D_ImmDrawEnd(void) {}
extern "C" C3D_FVec* C3D_FixedAttribGetWritePtr(int) { REC_LOCK; static C3D_FVec dummy; return &dummy; }
extern "C" void C3D_UpdateUniforms(GPU_SHADER_TYPE) {}

// attribs / buffers
extern "C" void AttrInfo_Init(C3D_AttrInfo* info) { REC_LOCK; std::memset(info, 0, sizeof *info); }
extern "C" int AttrInfo_AddLoader(C3D_AttrInfo* info, int regId, GPU_FORMATS format, int count) { REC_LOCK;
  if (info->attrCount >= 12) return -1;
  info->entries[info->attrCount] = {static_cast<u8>(regId), static_cast<u8>(format), static_cast<u8>(count), 0};
  return info->attrCount++;
}
extern "C" int AttrInfo_AddFixed(C3D_AttrInfo* info, int regId) { REC_LOCK; if (info->attrCount >= 12) return -1; info->entries[info->attrCount] = {static_cast<u8>(regId), 0, 0, 1}; return info->attrCount++; }
extern "C" C3D_AttrInfo* C3D_GetAttrInfo(void) { REC_LOCK; return &g_rec.attrInfo; }
extern "C" void C3D_SetAttrInfo(C3D_AttrInfo* info) { REC_LOCK; if (info) g_rec.attrInfo = *info; }
extern "C" void BufInfo_Init(C3D_BufInfo* info) { REC_LOCK; std::memset(info, 0, sizeof *info); }
extern "C" int BufInfo_Add(C3D_BufInfo* info, const void* data, ptrdiff_t stride, int attribCount, u64 permutation) { REC_LOCK;
  if (info->bufCount >= 12) return -1;
  info->buffers[info->bufCount] = {data, static_cast<u32>(stride), static_cast<u32>(attribCount), permutation};
  return info->bufCount++;
}
extern "C" C3D_BufInfo* C3D_GetBufInfo(void) { REC_LOCK; return &g_rec.bufInfo; }
extern "C" void C3D_SetBufInfo(C3D_BufInfo* info) { REC_LOCK; if (info) g_rec.bufInfo = *info; }

// effect state (c3d/effect.h)
extern "C" void C3D_DepthMap(bool, float, float) { REC_LOCK;}
extern "C" void C3D_CullFace(GPU_CULLMODE mode) { REC_LOCK; g_rec.effect.cull = mode; g_rec.effectDirty = true; }
extern "C" void C3D_StencilTest(bool enable, GPU_TESTFUNC function, int ref, int inputMask, int writeMask) { REC_LOCK;
  g_rec.effect.stencil = enable; g_rec.effect.stencilFunc = function; g_rec.effect.stencilRef = ref; g_rec.effect.stencilInputMask = inputMask; g_rec.effect.stencilWriteMask = writeMask; g_rec.effectDirty = true;
}
extern "C" void C3D_StencilOp(GPU_STENCILOP sfail, GPU_STENCILOP dfail, GPU_STENCILOP pass) { REC_LOCK; g_rec.effect.sfail = sfail; g_rec.effect.dfail = dfail; g_rec.effect.pass = pass; g_rec.effectDirty = true; }
extern "C" void C3D_BlendingColor(u32 color) { REC_LOCK; g_rec.effect.blendColor = color; g_rec.effectDirty = true; }
extern "C" void C3D_EarlyDepthTest(bool, GPU_EARLYDEPTHFUNC, u32) {}
extern "C" void C3D_DepthTest(bool enable, GPU_TESTFUNC function, GPU_WRITEMASK writemask) { REC_LOCK; g_rec.effect.depthTest = enable; g_rec.effect.depthFunc = function; g_rec.effect.writeMask = writemask; g_rec.effectDirty = true; }
extern "C" void C3D_AlphaTest(bool enable, GPU_TESTFUNC function, int ref) { REC_LOCK; g_rec.effect.alphaTest = enable; g_rec.effect.alphaFunc = function; g_rec.effect.alphaRef = ref; g_rec.effectDirty = true; }
extern "C" void C3D_AlphaBlend(GPU_BLENDEQUATION colorEq, GPU_BLENDEQUATION alphaEq, GPU_BLENDFACTOR srcClr, GPU_BLENDFACTOR dstClr, GPU_BLENDFACTOR srcAlpha, GPU_BLENDFACTOR dstAlpha) { REC_LOCK;
  g_rec.effect.blendEnabled = true; g_rec.effect.eqRgb = colorEq; g_rec.effect.eqA = alphaEq; g_rec.effect.srcRgb = srcClr; g_rec.effect.dstRgb = dstClr; g_rec.effect.srcA = srcAlpha; g_rec.effect.dstA = dstAlpha; g_rec.effectDirty = true;
}
extern "C" void C3D_ColorLogicOp(GPU_LOGICOP) { REC_LOCK; g_rec.effect.blendEnabled = false; g_rec.effectDirty = true; }
extern "C" void C3D_FragOpMode(GPU_FRAGOPMODE) {}
extern "C" void C3D_FragOpShadow(float, float) {}

// texenv (c3d/texenv.h)
extern "C" C3D_TexEnv* C3D_GetTexEnv(int id) { REC_LOCK; g_rec.texEnvDirty = true; return &g_rec.texEnv[id]; }
extern "C" void C3D_SetTexEnv(int id, C3D_TexEnv* env) { REC_LOCK; g_rec.texEnv[id] = *env; g_rec.texEnvDirty = true; }
extern "C" void C3D_DirtyTexEnv(C3D_TexEnv*) { REC_LOCK; g_rec.texEnvDirty = true; }
extern "C" void C3D_TexEnvBufUpdate(int mode, int mask) { REC_LOCK;
  if (mode & C3D_RGB) g_rec.texEnvBuf = (g_rec.texEnvBuf & ~(0xf << 8)) | ((mask & 0xf) << 8);
  if (mode & C3D_Alpha) g_rec.texEnvBuf = (g_rec.texEnvBuf & ~(0xf << 12)) | ((mask & 0xf) << 12);
  g_rec.texEnvDirty = true;
}
extern "C" void C3D_TexEnvBufColor(u32 color) { REC_LOCK; g_rec.texEnvBufClr = color; g_rec.texEnvDirty = true; }

// textures (c3d/texture.h)
extern "C" bool C3D_TexInitWithParams(C3D_Tex* tex, C3D_TexCube* cube, C3D_TexInitParams p) { REC_LOCK;
  (void)cube;
  if (p.width < 8 || p.height < 8 || p.width > 1024 || p.height > 1024) return false;
  const size_t size = static_cast<size_t>(p.width) * p.height * texdecode::bytes_per_pixel_x8(p.format) / 8;
  const size_t total = C3D_TexCalcTotalSize(static_cast<u32>(size), p.maxLevel);
  void* data = p.onVram ? vramAlloc(total) : linearAlloc(total);
  if (!data) return false;
  std::memset(tex, 0, sizeof *tex);
  tex->data = data; tex->fmt = p.format; tex->size = size & 0x0fffffff; tex->width = p.width; tex->height = p.height;
  tex->param = GPU_TEXTURE_MODE(p.type) | GPU_TEXTURE_MAG_FILTER(GPU_NEAREST) | GPU_TEXTURE_MIN_FILTER(GPU_NEAREST) | GPU_TEXTURE_WRAP_S(GPU_CLAMP_TO_EDGE) | GPU_TEXTURE_WRAP_T(GPU_CLAMP_TO_EDGE);
  if (p.format == GPU_ETC1 || p.format == GPU_ETC1A4) tex->param |= GPU_TEXTURE_ETC1_PARAM;
  tex->maxLevel = p.maxLevel;
  g_rec.textures[data] = {p.width, p.height, p.format, total, p.onVram};
  g_rec.texByAddr[reinterpret_cast<uintptr_t>(data)] = data;
  return true;
}
extern "C" void C3D_TexLoadImage(C3D_Tex* tex, const void* data, GPU_TEXFACE, int level) { REC_LOCK;
  if (level > 0) return; // mip levels beyond 0 are not used by GL here
  // level < 0: the whole chain (tex3ds VRAM imports pass -1)
  const size_t bytes = level < 0 ? C3D_TexCalcTotalSize(tex->size, tex->maxLevel) : tex->size;
  std::memcpy(tex->data, data, bytes);
  record_tex_upload(tex->data);
}
extern "C" void C3D_TexGenerateMipmap(C3D_Tex*, GPU_TEXFACE) {}
extern "C" void C3D_TexBind(int unitId, C3D_Tex* tex) { REC_LOCK;
  if (unitId < 0 || unitId > 2) return;
  g_rec.tex[unitId].key = tex ? tex->data : nullptr; g_rec.tex[unitId].param = tex ? tex->param : 0; g_rec.texDirty[unitId] = true;
}
extern "C" void C3D_TexFlush(C3D_Tex* tex) { REC_LOCK; if (tex && tex->data) record_tex_upload(tex->data); }
extern "C" void C3D_TexDelete(C3D_Tex* tex) { REC_LOCK;
  if (!tex || !tex->data) return;
  Cmd& c = emit(Op::DeleteTex); c.deleteTex.key = tex->data;
  auto it = g_rec.textures.find(tex->data);
  const bool vram = it != g_rec.textures.end() && it->second.vram;
  if (it != g_rec.textures.end()) g_rec.textures.erase(it);
  g_rec.texByAddr.erase(reinterpret_cast<uintptr_t>(tex->data));
  g_rec.pendingUploads.erase(std::remove(g_rec.pendingUploads.begin(), g_rec.pendingUploads.end(), tex->data), g_rec.pendingUploads.end());
  // The executor may still read the pixels of a queued upload (they were copied into the arena,
  // so freeing now is safe).
  if (vram) vramFree(tex->data); else linearFree(tex->data);
  tex->data = nullptr;
}
extern "C" void C3D_TexShadowParams(bool, float) {}

// render targets / frames (c3d/renderqueue.h, c3d/framebuffer.h)
static TargetImpl* make_target(int width, int height, bool depth, bool stencil, const void* colorTexKey) {
  auto* t = new TargetImpl{};
  t->id = g_rec.nextTargetId++;
  t->width = width; t->height = height; t->depth = depth; t->stencil = stencil; t->colorTexKey = colorTexKey;
  t->base.frameBuf.width = static_cast<u16>(width); t->base.frameBuf.height = static_cast<u16>(height);
  t->base.frameBuf.colorBuf = const_cast<void*>(colorTexKey); t->base.screen = GFX_TOP; t->base.side = GFX_LEFT;
  g_rec.targetByFrameBuf[&t->base.frameBuf] = t;
  g_rec.targets.push_back(t);
  Cmd& c = emit(Op::CreateTarget);
  c.createTarget.target = t->id; c.createTarget.width = width; c.createTarget.height = height; c.createTarget.colorTexKey = colorTexKey; c.createTarget.depth = depth; c.createTarget.stencil = stencil;
  return t;
}
extern "C" C3D_RenderTarget* C3D_RenderTargetCreate(int width, int height, GPU_COLORBUF, C3D_DEPTHTYPE depthFmt) { REC_LOCK;
  const bool depth = C3D_DEPTHTYPE_OK(depthFmt);
  return &make_target(width, height, depth, depth, nullptr)->base;
}
extern "C" C3D_RenderTarget* C3D_RenderTargetCreateFromTex(C3D_Tex* tex, GPU_TEXFACE, int, C3D_DEPTHTYPE depthFmt) { REC_LOCK;
  const bool depth = C3D_DEPTHTYPE_OK(depthFmt);
  return &make_target(tex->width, tex->height, depth, depth, tex->data)->base;
}
extern "C" void C3D_RenderTargetDelete(C3D_RenderTarget* target) { REC_LOCK;
  TargetImpl* t = impl_of(target);
  Cmd& c = emit(Op::DeleteTarget); c.deleteTarget.target = t->id;
  g_rec.targetByFrameBuf.erase(&t->base.frameBuf);
  g_rec.targets.erase(std::remove(g_rec.targets.begin(), g_rec.targets.end(), t), g_rec.targets.end());
  if (g_rec.currentTarget == t) g_rec.currentTarget = nullptr;
  // the executor still references the id until the DeleteTarget command runs; the struct itself is
  // only read on the record side
  wait_idle();
  delete t;
}
extern "C" void C3D_RenderTargetSetOutput(C3D_RenderTarget* target, gfxScreen_t screen, gfx3dSide_t side, u32) { REC_LOCK;
  if (target) { TargetImpl* t = impl_of(target); t->base.linked = true; t->base.screen = screen; t->base.side = side; Cmd& c = emit(Op::SetOutput); c.setOutput.target = t->id; c.setOutput.screen = screen; c.setOutput.side = side; }
  else for (TargetImpl* t : g_rec.targets) if (t->base.linked && t->base.screen == screen && t->base.side == side) { t->base.linked = false; Cmd& c = emit(Op::SetOutput); c.setOutput.target = t->id; c.setOutput.screen = -1; c.setOutput.side = side; }
}
extern "C" void C3D_FrameBufClear(C3D_FrameBuf* fb, C3D_ClearBits clearBits, u32 clearColor, u32 clearDepth) { REC_LOCK;
  auto it = g_rec.targetByFrameBuf.find(fb);
  if (it == g_rec.targetByFrameBuf.end() || hidden_target(it->second)) return;
  Cmd& c = emit(Op::Clear); c.clear.target = it->second->id; c.clear.bits = clearBits; c.clear.color = clearColor; c.clear.depth = clearDepth;
}
extern "C" void C3D_FrameBufTransfer(C3D_FrameBuf*, gfxScreen_t, gfx3dSide_t, u32) {}
extern "C" float C3D_FrameRate(float fps) { return fps; }
extern "C" void C3D_FrameSync(void) { gfx_vblank_wait(); }
extern "C" u32 C3D_FrameCounter(int) { REC_LOCK; return g_rec.framesPresented.load(std::memory_order_relaxed); }
extern "C" bool C3D_FrameBegin(u8 flags) {
  if (flags & C3D_FRAME_SYNCDRAW) gfx_vblank_wait();
  REC_LOCK;
  ++g_rec.inFrame;
  return true;
}
extern "C" bool C3D_FrameDrawOn(C3D_RenderTarget* target) { REC_LOCK;
  TargetImpl* t = impl_of(target);
  g_rec.currentTarget = t;
  g_rec.skipping = hidden_target(t);
  if (g_rec.skipping) return true;
  Cmd& c = emit(Op::Target); c.target.target = t->id;
  return true;
}
extern "C" void C3D_FrameSplit(u8) { REC_LOCK; emit(Op::Split); }
extern "C" void C3D_FrameEnd(u8) { REC_LOCK;
  emit(Op::Present);
  submit_frame(true);
  g_rec.inFrame = 0;
  g_rec.skipping = false;
}
extern "C" void C3D_FrameEndHook(void (*)(void*), void*) {}
extern "C" float C3D_GetDrawingTime(void) { return static_cast<float>(g_ex.processingMs); }
extern "C" float C3D_GetProcessingTime(void) { return static_cast<float>(g_ex.processingMs); }

// Synchronous transfers. The game uses them for CPU readbacks of a target (captures) and for
// copying raw texture memory (movie frames, VRAM moves).
extern "C" void C3D_SyncDisplayTransfer(u32* inadr, u32 indim, u32* outadr, u32 outdim, u32 flags) { REC_LOCK;
  (void)indim; (void)flags;
  // inadr is a target's colorBuf: find it. Our colorBuf is the color texture key (null for
  // screen targets), so match on the frameBuf pointer the game got the value from instead.
  TargetImpl* found = nullptr;
  for (TargetImpl* t : g_rec.targets) if (t->base.frameBuf.colorBuf == inadr) { found = t; break; }
  if (!found) { for (TargetImpl* t : g_rec.targets) if (!t->colorTexKey) { found = t; break; } }
  if (!found) return;
  const int w = static_cast<int>(outdim & 0xffff), h = static_cast<int>(outdim >> 16);
  Cmd& c = emit(Op::ReadTarget); c.readTarget.target = found->id; c.readTarget.dest = outadr; c.readTarget.width = found->width; c.readTarget.height = found->height; c.readTarget.rgb8 = false;
  (void)w; (void)h;
  submit_frame(false);
  wait_idle();
}
extern "C" void C3D_SyncTextureCopy(u32* inadr, u32, u32* outadr, u32, u32 size, u32) { REC_LOCK;
  std::memcpy(outadr, inadr, size);
  // Find the texture whose memory contains outadr and mark it for upload.
  const uint8_t* dst = reinterpret_cast<const uint8_t*>(outadr);
  for (auto& [key, rec] : g_rec.textures) {
    const uint8_t* base = static_cast<const uint8_t*>(key);
    if (dst >= base && dst < base + rec.bytes) {
      // whole-texture upload once the copy reaches the end of the texture (streamed chunks)
      if (dst + size >= base + rec.bytes) record_tex_upload(key);
      break;
    }
  }
}
extern "C" void C3D_SyncMemoryFill(u32*, u32, u32*, u16, u32*, u32, u32*, u16) {}

// ---------------------------------------------------------------- gfx (framebuffers) + vblank
namespace {
struct ScreenCpuBuffer { std::vector<uint8_t> buf[2]; int front = 0; };
ScreenCpuBuffer g_screenCpu[2];
}
extern "C" void gfxInitDefault(void) { REC_LOCK; gfxInit(GSP_BGR8_OES, GSP_BGR8_OES, false); }
extern "C" void gfxInit(GSPGPU_FramebufferFormat, GSPGPU_FramebufferFormat, bool) { REC_LOCK;
  for (int s = 0; s < 2; ++s) for (auto& b : g_screenCpu[s].buf) b.assign(static_cast<size_t>(kScreenW[s]) * kScreenH * 3, 0);
}
extern "C" void gfxExit(void) {}
extern "C" void gfxSet3D(bool) {}
extern "C" bool gfxIs3D(void) { return false; }
extern "C" bool gfxIsWide(void) { return false; }
extern "C" void gfxSetWide(bool) {}
extern "C" void gfxSetScreenFormat(gfxScreen_t, GSPGPU_FramebufferFormat) {}
extern "C" GSPGPU_FramebufferFormat gfxGetScreenFormat(gfxScreen_t) { return GSP_BGR8_OES; }
extern "C" void gfxSetDoubleBuffering(gfxScreen_t, bool) {}
extern "C" u8* gfxGetFramebuffer(gfxScreen_t screen, gfx3dSide_t, u16* width, u16* height) { REC_LOCK;
  const int s = screen == GFX_TOP ? 0 : 1;
  if (width) *width = kScreenH; if (height) *height = static_cast<u16>(kScreenW[s]);
  return g_screenCpu[s].buf[g_screenCpu[s].front ^ 1].data();
}
extern "C" void gfxFlushBuffers(void) {}
extern "C" void gfxScreenSwapBuffers(gfxScreen_t scr, bool) { REC_LOCK;
  const int s = scr == GFX_TOP ? 0 : 1;
  g_screenCpu[s].front ^= 1;
  if (s == 1 && !show_bottom()) { if (!g_rec.inFrame) { emit(Op::Present); submit_frame(true); } return; }
  Cmd& c = emit(Op::ScreenCpu); c.screenCpu.screen = s;
  c.screenCpu.arena = frame().push(g_screenCpu[s].buf[g_screenCpu[s].front].data(), g_screenCpu[s].buf[g_screenCpu[s].front].size(), 16);
  if (!g_rec.inFrame) { emit(Op::Present); submit_frame(true); }
}
extern "C" void gfxSwapBuffers(void) { REC_LOCK; gfxScreenSwapBuffers(GFX_TOP, false); gfxScreenSwapBuffers(GFX_BOTTOM, false); }
extern "C" void gfxSwapBuffersGpu(void) { REC_LOCK; gfxSwapBuffers(); }
extern "C" void gfxConfigScreen(gfxScreen_t, bool) {}

void shim::gfx_vblank_wait() {
  std::unique_lock lock(g_ex.vblankMutex);
  const uint32_t start = g_ex.vblankCount;
  // Frames are presented by the executor; if nothing is queued, pace at 60 Hz anyway.
  g_ex.vblankCv.wait_for(lock, std::chrono::milliseconds(17), [&] { return g_ex.vblankCount != start; });
}
uint32_t shim::gfx_frame_counter() { return g_rec.framesPresented.load(); }
void shim::gfx_present_frame() {}
unsigned shim::gfx_screen_texture(int) { return 0; }
void shim::gfx_screen_dirty_cpu(int) {}

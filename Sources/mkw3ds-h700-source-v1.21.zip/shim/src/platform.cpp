// SDL + EGL platform layer: Mali fbdev window on the H700, Mesa surfaceless pbuffer on the host.
#include "shim.hpp"
#include <execinfo.h>
#include <csignal>
#include <cstring>
#include <unistd.h>
#include "gl.hpp"
#include <SDL3/SDL.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>

namespace shim::gl {
#define SHIM_DEF(name) decltype(&::name) name = nullptr;
SHIM_GL_FUNCS(SHIM_DEF)
SHIM_EGL_FUNCS(SHIM_DEF)
#undef SHIM_DEF
static void* s_eglLib = nullptr;
static void* s_glLib = nullptr;
bool load_egl() {
  const char* custom = std::getenv("MKW_EGL_LIBRARY");
  const char* names[] = {custom, "libEGL.so.1", "libEGL.so", "libmali.so", "libmali.so.1"};
  for (const char* n : names) {
    if (!n) continue;
    s_eglLib = dlopen(n, RTLD_NOW | RTLD_GLOBAL);
    if (s_eglLib) { SHIM_LOG("[egl] %s", n); break; }
  }
  if (!s_eglLib) { SHIM_LOG("[egl] no libEGL: %s", dlerror()); return false; }
  bool ok = true;
#define SHIM_RESOLVE(name) name = reinterpret_cast<decltype(name)>(dlsym(s_eglLib, #name)); if (!name) { SHIM_LOG("[egl] missing %s", #name); if (std::strcmp(#name, "eglGetPlatformDisplay") != 0) ok = false; }
  SHIM_EGL_FUNCS(SHIM_RESOLVE)
#undef SHIM_RESOLVE
  return ok;
}
bool load_gl() {
  const char* names[] = {"libGLESv2.so.2", "libGLESv2.so", "libmali.so", "libmali.so.1"};
  for (const char* n : names) { s_glLib = dlopen(n, RTLD_NOW | RTLD_GLOBAL); if (s_glLib) break; }
  bool ok = true;
#define SHIM_RESOLVE(name) \
  name = reinterpret_cast<decltype(name)>(eglGetProcAddress(#name)); \
  if (!name && s_glLib) name = reinterpret_cast<decltype(name)>(dlsym(s_glLib, #name)); \
  if (!name && s_eglLib) name = reinterpret_cast<decltype(name)>(dlsym(s_eglLib, #name)); \
  if (!name) { SHIM_LOG("[gl] missing %s", #name); ok = false; }
  SHIM_GL_FUNCS(SHIM_RESOLVE)
#undef SHIM_RESOLVE
  return ok;
}
} // namespace shim::gl

namespace shim {
namespace {
std::mutex g_logMutex;
FILE* g_logFile = nullptr;
EGLDisplay g_display = EGL_NO_DISPLAY;
EGLSurface g_surface = EGL_NO_SURFACE;
EGLContext g_context = EGL_NO_CONTEXT;
ScreenSize g_screen{640, 480};
bool g_headless = false;
std::string g_dataDir = ".";
struct FbdevWindow { uint16_t width, height; }; // Mali fbdev EGLNativeWindowType
FbdevWindow* g_fbWindow = nullptr;
std::string g_screenshotPath;
bool g_quit = false;

void fbdev_size(int& w, int& h) {
  w = 0; h = 0;
  if (const char* e = std::getenv("MKW_FB_WIDTH")) w = std::atoi(e);
  if (const char* e = std::getenv("MKW_FB_HEIGHT")) h = std::atoi(e);
  if (w > 0 && h > 0) return;
  const int fd = open("/dev/fb0", O_RDONLY);
  if (fd >= 0) {
    fb_var_screeninfo info{};
    if (ioctl(fd, FBIOGET_VSCREENINFO, &info) == 0) { w = static_cast<int>(info.xres); h = static_cast<int>(info.yres); }
    close(fd);
  }
  if (w <= 0 || h <= 0) { w = 640; h = 480; }
}
} // namespace

void platform_log(const char* fmt, ...) {
  std::lock_guard lock(g_logMutex);
  va_list ap; va_start(ap, fmt);
  char buf[1024];
  std::vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  std::fprintf(stderr, "%s\n", buf);
  if (g_logFile) { std::fprintf(g_logFile, "%s\n", buf); std::fflush(g_logFile); }
}
uint64_t platform_now_ns() {
  timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
  return static_cast<uint64_t>(ts.tv_sec) * 1000000000ull + static_cast<uint64_t>(ts.tv_nsec);
}
const char* platform_data_dir() { return g_dataDir.c_str(); }
ScreenSize platform_screen() { return g_screen; }
void platform_screenshot_request(const char* path) { g_screenshotPath = path ? path : ""; }
bool platform_screenshot_pending(std::string& out) { if (g_screenshotPath.empty()) return false; out = g_screenshotPath; g_screenshotPath.clear(); return true; }
bool platform_headless() { return g_headless; }

// Crash log: signal name, fault address and raw return addresses (resolve with addr2line against
// the unstripped binary; load base is printed so PIE offsets can be worked out).
static void crash_handler(int sig, siginfo_t* info, void*) {
  void* frames[48];
  const int n = backtrace(frames, 48);
  char buf[160];
  int len = std::snprintf(buf, sizeof buf, "[crash] signal %d (%s) addr=%p base=%p\n", sig, strsignal(sig), info ? info->si_addr : nullptr, reinterpret_cast<void*>(&crash_handler));
  if (write(2, buf, static_cast<size_t>(len)) < 0) {}
  if (g_logFile) { if (write(fileno(g_logFile), buf, static_cast<size_t>(len)) < 0) {} }
  backtrace_symbols_fd(frames, n, 2);
  if (g_logFile) backtrace_symbols_fd(frames, n, fileno(g_logFile));
  signal(sig, SIG_DFL); raise(sig);
}

bool platform_init() {
  if (const char* d = std::getenv("MKW_DATA_DIR")) g_dataDir = d;
  if (const char* l = std::getenv("MKW_LOG_FILE")) g_logFile = std::fopen(l, "w");
  { struct sigaction sa{}; sa.sa_sigaction = crash_handler; sa.sa_flags = SA_SIGINFO | SA_RESETHAND; for (int sig : {SIGSEGV, SIGBUS, SIGILL, SIGFPE, SIGABRT}) sigaction(sig, &sa, nullptr); }
  g_headless = std::getenv("MKW_HEADLESS") != nullptr;
  SDL_SetHint(SDL_HINT_VIDEO_DRIVER, "offscreen");
  SDL_SetHint(SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, "1");
  if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMEPAD | SDL_INIT_AUDIO | SDL_INIT_EVENTS)) {
    SHIM_LOG("[sdl] init failed: %s", SDL_GetError());
    // Video is only needed for event pumping; carry on without it.
    if (!SDL_Init(SDL_INIT_GAMEPAD | SDL_INIT_AUDIO | SDL_INIT_EVENTS)) { SHIM_LOG("[sdl] init failed again: %s", SDL_GetError()); return false; }
  }
  if (const char* map = std::getenv("SDL_GAMECONTROLLERCONFIG")) SDL_AddGamepadMapping(map);
  if (!gl::load_egl()) return false;

  const EGLint ctxAttribs[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
  EGLint cfgAttribs[] = {EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8,
                         EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 0, EGL_STENCIL_SIZE, 0, EGL_NONE};
  if (g_headless) {
    // Host: Mesa surfaceless platform + a pbuffer the compositor draws into.
    if (gl::eglGetPlatformDisplay) g_display = gl::eglGetPlatformDisplay(0x31DD /* EGL_PLATFORM_SURFACELESS_MESA */, EGL_DEFAULT_DISPLAY, nullptr);
    if (g_display == EGL_NO_DISPLAY) g_display = gl::eglGetDisplay(EGL_DEFAULT_DISPLAY);
    cfgAttribs[1] = EGL_PBUFFER_BIT;
  } else {
    g_display = gl::eglGetDisplay(EGL_DEFAULT_DISPLAY);
  }
  EGLint major = 0, minor = 0;
  if (g_display == EGL_NO_DISPLAY || !gl::eglInitialize(g_display, &major, &minor)) { SHIM_LOG("[egl] eglInitialize failed (0x%x)", gl::eglGetError()); return false; }
  SHIM_LOG("[egl] %d.%d vendor=%s", major, minor, gl::eglQueryString(g_display, EGL_VENDOR));
  gl::eglBindAPI(EGL_OPENGL_ES_API);
  EGLConfig config; EGLint numConfig = 0;
  if (!gl::eglChooseConfig(g_display, cfgAttribs, &config, 1, &numConfig) || numConfig < 1) { SHIM_LOG("[egl] no config (0x%x)", gl::eglGetError()); return false; }
  int w, h;
  if (g_headless) {
    w = 640; h = 480;
    if (const char* e = std::getenv("MKW_FB_WIDTH")) w = std::atoi(e);
    if (const char* e = std::getenv("MKW_FB_HEIGHT")) h = std::atoi(e);
    const EGLint pb[] = {EGL_WIDTH, w, EGL_HEIGHT, h, EGL_NONE};
    g_surface = gl::eglCreatePbufferSurface(g_display, config, pb);
  } else {
    fbdev_size(w, h);
    // The Mali fbdev EGL expects a pointer to {u16 width, u16 height}; keep it below 4 GiB in case
    // the blob narrows the handle.
    void* mem = mmap(reinterpret_cast<void*>(0x7f000000), 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
    if (mem == MAP_FAILED) mem = mmap(reinterpret_cast<void*>(0x40000000), 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) mem = std::malloc(4096);
    g_fbWindow = static_cast<FbdevWindow*>(mem);
    g_fbWindow->width = static_cast<uint16_t>(w); g_fbWindow->height = static_cast<uint16_t>(h);
    g_surface = gl::eglCreateWindowSurface(g_display, config, reinterpret_cast<EGLNativeWindowType>(g_fbWindow), nullptr);
  }
  if (g_surface == EGL_NO_SURFACE) { SHIM_LOG("[egl] surface failed (0x%x)", gl::eglGetError()); return false; }
  g_screen = {w, h};
  g_context = gl::eglCreateContext(g_display, config, EGL_NO_CONTEXT, ctxAttribs);
  if (g_context == EGL_NO_CONTEXT) { SHIM_LOG("[egl] context failed (0x%x)", gl::eglGetError()); return false; }
  if (!gl::eglMakeCurrent(g_display, g_surface, g_surface, g_context)) { SHIM_LOG("[egl] makecurrent failed (0x%x)", gl::eglGetError()); return false; }
  gl::eglSwapInterval(g_display, std::getenv("MKW_NO_VSYNC") ? 0 : 1);
  if (!gl::load_gl()) return false;
  SHIM_LOG("[gl] %s | %s | %s", gl::glGetString(GL_VENDOR), gl::glGetString(GL_RENDERER), gl::glGetString(GL_VERSION));
  SHIM_LOG("[platform] screen %dx%d data=%s", w, h, g_dataDir.c_str());
  // The GL thread (c3d.cpp) owns the context from here on.
  gl::eglMakeCurrent(g_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
  return true;
}
bool platform_make_current() {
  if (!gl::eglMakeCurrent(g_display, g_surface, g_surface, g_context)) { SHIM_LOG("[egl] makecurrent (gl thread) failed 0x%x", gl::eglGetError()); return false; }
  return true;
}
void platform_shutdown() {
  if (g_display != EGL_NO_DISPLAY) {
    gl::eglMakeCurrent(g_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (g_context != EGL_NO_CONTEXT) gl::eglDestroyContext(g_display, g_context);
    if (g_surface != EGL_NO_SURFACE) gl::eglDestroySurface(g_display, g_surface);
    gl::eglTerminate(g_display);
  }
  SDL_Quit();
  if (g_logFile) std::fclose(g_logFile);
}
void platform_swap() { gl::eglSwapBuffers(g_display, g_surface); }
bool platform_pump_events() {
  SDL_Event e;
  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_EVENT_QUIT) g_quit = true;
    if (e.type == SDL_EVENT_KEY_DOWN && e.key.key == SDLK_ESCAPE) g_quit = true;
  }
  return !g_quit;
}
void platform_request_quit() { g_quit = true; }
} // namespace shim

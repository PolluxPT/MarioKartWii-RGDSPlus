#pragma once
#include <array>
#include <cstdint>
#include <string>
namespace shim {
extern const char* kSceneVertexShader;
extern const char* kEffectVertexShader;
extern const char* kFragmentShader; // generic TexEnv interpreter (kept for reference/debug)
extern const char* kBlitVertexShader;
extern const char* kBlitFragmentShader;
extern const char* kMiniFragmentShader;

// Everything that changes the fragment program's code: the six TexEnv stages, which stages update
// the combiner buffer, the alpha test function, texture coordinate modes and per-unit v flips.
// Constant colors, the buffer color and the alpha reference stay uniforms.
struct FragKey {
  std::array<uint32_t, 13> w{};
  bool operator==(const FragKey& o) const { return w == o.w; }
};
struct FragKeyHash { size_t operator()(const FragKey& k) const { uint64_t h = 1469598103934665603ull; for (uint32_t v : k.w) { h ^= v; h *= 1099511628211ull; } return static_cast<size_t>(h); } };
// stage fields as the C3D_TexEnv stores them
struct StageDesc { uint16_t srcRgb, srcA, opRgb, opA; uint8_t funcRgb, funcA, scaleRgb, scaleA; };
FragKey make_frag_key(const StageDesc (&st)[6], unsigned bufUpdate, int alphaFunc, bool unit0Projection, bool unit2Tc1, unsigned flipMask, int vertexProgram);
std::string make_fragment_shader(const FragKey& key);
}

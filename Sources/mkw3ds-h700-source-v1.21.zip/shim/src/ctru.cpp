// libctru subset on Linux: threads, locks, time, allocators, services the game touches.
#include <3ds.h>
#include "shim.hpp"
#include <SDL3/SDL.h>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <cctype>
#include <vector>
#include <algorithm>
#include <cstring>
#include <ctime>
#include <mutex>
#include <pthread.h>
#include <sched.h>
#include <string>
#include <unordered_map>

// ---------------------------------------------------------------- time
extern "C" u64 svcGetSystemTick(void) {
  // 268.111856 MHz ARM11 clock expressed from the monotonic nanosecond clock.
  return static_cast<u64>((static_cast<unsigned __int128>(shim::platform_now_ns()) * 268111856ull) / 1000000000ull);
}
extern "C" Result svcSleepThread(s64 ns) {
  if (ns <= 0) { sched_yield(); return 0; }
  timespec ts{static_cast<time_t>(ns / 1000000000ll), static_cast<long>(ns % 1000000000ll)};
  while (nanosleep(&ts, &ts) == -1 && errno == EINTR) {}
  return 0;
}
extern "C" Result svcGetThreadPriority(s32* out, Handle) { if (out) *out = 0x30; return 0; }
extern "C" Result svcSetThreadPriority(Handle, s32) { return 0; }
extern "C" Result svcCreateEvent(Handle* event, ResetType) { if (event) *event = 1; return 0; }
extern "C" Result svcSignalEvent(Handle) { return 0; }
extern "C" Result svcClearEvent(Handle) { return 0; }
extern "C" Result svcWaitSynchronization(Handle, s64) { return 0; }
extern "C" Result svcCloseHandle(Handle) { return 0; }
extern "C" Result svcGetProcessInfo(s64* out, Handle, u32) { if (out) *out = 0; return 0; }
extern "C" u64 osGetTime(void) {
  return static_cast<u64>(std::chrono::duration_cast<std::chrono::milliseconds>(
                              std::chrono::system_clock::now().time_since_epoch()).count());
}
extern "C" void osSetSpeedupEnable(bool) {}
extern "C" bool osIsHeadsetConnected(void) { return false; }
extern "C" u32 osConvertVirtToPhys(const void* vaddr) { return static_cast<u32>(reinterpret_cast<uintptr_t>(vaddr)); }
extern "C" float osGet3DSliderState(void) { return 0.0f; }

// ---------------------------------------------------------------- locks
extern "C" void LightLock_Init(LightLock* l) { pthread_mutex_init(&l->m, nullptr); }
extern "C" void LightLock_Lock(LightLock* l) { pthread_mutex_lock(&l->m); }
extern "C" int LightLock_TryLock(LightLock* l) { return pthread_mutex_trylock(&l->m) == 0 ? 0 : 1; }
extern "C" void LightLock_Unlock(LightLock* l) { pthread_mutex_unlock(&l->m); }
extern "C" void RecursiveLock_Init(RecursiveLock* l) {
  pthread_mutexattr_t a; pthread_mutexattr_init(&a); pthread_mutexattr_settype(&a, PTHREAD_MUTEX_RECURSIVE);
  pthread_mutex_init(&l->m, &a); pthread_mutexattr_destroy(&a);
}
extern "C" void RecursiveLock_Lock(RecursiveLock* l) { pthread_mutex_lock(&l->m); }
extern "C" int RecursiveLock_TryLock(RecursiveLock* l) { return pthread_mutex_trylock(&l->m) == 0 ? 0 : 1; }
extern "C" void RecursiveLock_Unlock(RecursiveLock* l) { pthread_mutex_unlock(&l->m); }

extern "C" void LightEvent_Init(LightEvent* e, ResetType t) {
  pthread_mutex_init(&e->m, nullptr);
  pthread_condattr_t ca; pthread_condattr_init(&ca); pthread_condattr_setclock(&ca, CLOCK_MONOTONIC);
  pthread_cond_init(&e->c, &ca); pthread_condattr_destroy(&ca);
  e->signaled = false; e->sticky = t == RESET_STICKY;
}
extern "C" void LightEvent_Clear(LightEvent* e) { pthread_mutex_lock(&e->m); e->signaled = false; pthread_mutex_unlock(&e->m); }
extern "C" void LightEvent_Signal(LightEvent* e) {
  pthread_mutex_lock(&e->m); e->signaled = true;
  if (e->sticky) pthread_cond_broadcast(&e->c); else pthread_cond_signal(&e->c);
  pthread_mutex_unlock(&e->m);
}
extern "C" void LightEvent_Pulse(LightEvent* e) { pthread_mutex_lock(&e->m); pthread_cond_broadcast(&e->c); pthread_mutex_unlock(&e->m); }
extern "C" bool LightEvent_TryWait(LightEvent* e) {
  pthread_mutex_lock(&e->m); const bool ok = e->signaled; if (ok && !e->sticky) e->signaled = false;
  pthread_mutex_unlock(&e->m); return ok;
}
extern "C" void LightEvent_Wait(LightEvent* e) {
  pthread_mutex_lock(&e->m);
  while (!e->signaled) pthread_cond_wait(&e->c, &e->m);
  if (!e->sticky) e->signaled = false;
  pthread_mutex_unlock(&e->m);
}
extern "C" int LightEvent_WaitTimeout(LightEvent* e, s64 timeout_ns) {
  timespec deadline; clock_gettime(CLOCK_MONOTONIC, &deadline);
  deadline.tv_sec += static_cast<time_t>(timeout_ns / 1000000000ll);
  deadline.tv_nsec += static_cast<long>(timeout_ns % 1000000000ll);
  if (deadline.tv_nsec >= 1000000000l) { deadline.tv_sec += 1; deadline.tv_nsec -= 1000000000l; }
  pthread_mutex_lock(&e->m);
  int rc = 0;
  while (!e->signaled && rc == 0) rc = pthread_cond_timedwait(&e->c, &e->m, &deadline);
  const bool got = e->signaled;
  if (got && !e->sticky) e->signaled = false;
  pthread_mutex_unlock(&e->m);
  return got ? 0 : 1; // libctru: 0 = signaled, nonzero = timeout
}
extern "C" void LightSemaphore_Init(LightSemaphore* s, s16 initial, s16 max) {
  pthread_mutex_init(&s->m, nullptr); pthread_cond_init(&s->c, nullptr); s->count = initial; s->max = max;
}
extern "C" void LightSemaphore_Acquire(LightSemaphore* s, s32 count) {
  pthread_mutex_lock(&s->m); while (s->count < count) pthread_cond_wait(&s->c, &s->m); s->count -= count; pthread_mutex_unlock(&s->m);
}
extern "C" void LightSemaphore_Release(LightSemaphore* s, s32 count) {
  pthread_mutex_lock(&s->m); s->count += count; if (s->count > s->max) s->count = s->max; pthread_cond_broadcast(&s->c); pthread_mutex_unlock(&s->m);
}
extern "C" void CondVar_Init(CondVar* cv) { pthread_cond_init(&cv->c, nullptr); }
extern "C" void CondVar_Wait(CondVar* cv, LightLock* l) { pthread_cond_wait(&cv->c, &l->m); }
extern "C" void CondVar_Signal(CondVar* cv) { pthread_cond_signal(&cv->c); }
extern "C" void CondVar_Broadcast(CondVar* cv) { pthread_cond_broadcast(&cv->c); }

// ---------------------------------------------------------------- threads
struct Thread_tag {
  pthread_t thread{};
  ThreadFunc entry = nullptr;
  void* arg = nullptr;
  int rc = 0;
  bool detached = false;
  bool joined = false;
};
static void* thread_main(void* p) {
  auto* t = static_cast<Thread_tag*>(p);
  t->entry(t->arg);
  if (t->detached) delete t;
  return nullptr;
}
extern "C" Thread threadCreate(ThreadFunc entry, void* arg, size_t stack_size, int prio, int core_id, bool detached) {
  (void)prio; (void)core_id;
  auto* t = new Thread_tag{};
  t->entry = entry; t->arg = arg; t->detached = detached;
  pthread_attr_t a; pthread_attr_init(&a);
  if (stack_size < 1024 * 1024) stack_size = 1024 * 1024; // 3DS stacks are tiny; host code (GL driver) is not
  pthread_attr_setstacksize(&a, stack_size);
  if (detached) pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
  const int err = pthread_create(&t->thread, &a, thread_main, t);
  pthread_attr_destroy(&a);
  if (err != 0) { delete t; return nullptr; }
  return t;
}
extern "C" Handle threadGetHandle(Thread) { return 1; }
extern "C" int threadGetExitCode(Thread t) { return t ? t->rc : 0; }
extern "C" Result threadJoin(Thread t, u64) {
  if (!t || t->detached || t->joined) return 0;
  pthread_join(t->thread, nullptr); t->joined = true; return 0;
}
extern "C" void threadFree(Thread t) { if (t && !t->detached) { if (!t->joined) pthread_join(t->thread, nullptr); delete t; } }
extern "C" void threadDetach(Thread t) { if (t) { pthread_detach(t->thread); t->detached = true; } }
extern "C" Thread threadGetCurrent(void) { return nullptr; }
extern "C" void threadExit(int) { pthread_exit(nullptr); }

// ---------------------------------------------------------------- memory
// LINEAR (GPU-visible) and VRAM heaps are plain host memory. The space-free figures are budgets:
// the game plans texture residency around them.
static std::atomic<size_t> g_linearUsed{0}, g_vramUsed{0};
static constexpr size_t kLinearBudget = 160u << 20, kVramBudget = 48u << 20;
static std::mutex g_allocMutex;
static std::map<uintptr_t, size_t> g_allocSizes; // base -> size, ordered for containing-allocation lookups
extern "C" void shim_buffer_freed(const void* base);
static void* budgeted_alloc(size_t size, size_t align, std::atomic<size_t>& used) {
  if (align < 16) align = 16;
  size_t rounded = (size + align - 1) / align * align;
  void* p = std::aligned_alloc(align, rounded ? rounded : align);
  if (!p) return nullptr;
  std::lock_guard lock(g_allocMutex);
  g_allocSizes[reinterpret_cast<uintptr_t>(p)] = rounded;
  used += rounded;
  return p;
}
static void budgeted_free(void* p, std::atomic<size_t>& used) {
  if (!p) return;
  bool known = false;
  { std::lock_guard lock(g_allocMutex); auto it = g_allocSizes.find(reinterpret_cast<uintptr_t>(p)); if (it != g_allocSizes.end()) { used -= it->second; g_allocSizes.erase(it); known = true; } }
  if (known) shim_buffer_freed(p); // the GL copy of this memory, if any, goes with it
  std::free(p);
}
extern "C" void* linearAlloc(size_t size) { return budgeted_alloc(size, 0x80, g_linearUsed); }
extern "C" void* linearMemAlign(size_t size, size_t alignment) { return budgeted_alloc(size, alignment, g_linearUsed); }
extern "C" void* linearRealloc(void* mem, size_t size) {
  void* n = linearAlloc(size);
  if (n && mem) { size_t old = 0; { std::lock_guard lock(g_allocMutex); auto it = g_allocSizes.find(reinterpret_cast<uintptr_t>(mem)); if (it != g_allocSizes.end()) old = it->second; } std::memcpy(n, mem, old < size ? old : size); linearFree(mem); }
  return n;
}
extern "C" size_t linearGetSize(void* mem) { std::lock_guard lock(g_allocMutex); auto it = g_allocSizes.find(reinterpret_cast<uintptr_t>(mem)); return it == g_allocSizes.end() ? 0 : it->second; }
// The LINEAR/VRAM allocation containing p (for the GL buffer cache).
bool shim_linear_lookup(const void* p, const void** base, size_t* size) {
  std::lock_guard lock(g_allocMutex);
  const uintptr_t a = reinterpret_cast<uintptr_t>(p);
  auto it = g_allocSizes.upper_bound(a);
  if (it == g_allocSizes.begin()) return false;
  --it;
  if (a >= it->first + it->second) return false;
  *base = reinterpret_cast<const void*>(it->first); *size = it->second;
  return true;
}
extern "C" void linearFree(void* mem) { budgeted_free(mem, g_linearUsed); }
extern "C" u32 linearSpaceFree(void) { size_t u = g_linearUsed.load(); return static_cast<u32>(u < kLinearBudget ? kLinearBudget - u : 0); }
extern "C" void* vramAlloc(size_t size) { return budgeted_alloc(size, 0x80, g_vramUsed); }
extern "C" void* vramMemAlign(size_t size, size_t alignment) { return budgeted_alloc(size, alignment, g_vramUsed); }
extern "C" void* vramRealloc(void* mem, size_t size) { (void)mem; return vramAlloc(size); }
extern "C" size_t vramGetSize(void* mem) { return linearGetSize(mem); }
extern "C" void vramFree(void* mem) { budgeted_free(mem, g_vramUsed); }
extern "C" u32 vramSpaceFree(void) { size_t u = g_vramUsed.load(); return static_cast<u32>(u < kVramBudget ? kVramBudget - u : 0); }
bool shim_is_vram(const void* p) { return p != nullptr && false; }

// ---------------------------------------------------------------- services
extern "C" void shim_cpu_flush(const void* addr, u32 size);
extern "C" Result GSPGPU_FlushDataCache(const void* addr, u32 size) { shim_cpu_flush(addr, size); return 0; }
extern "C" Result GSPGPU_InvalidateDataCache(const void*, u32) { return 0; }
extern "C" Result DSP_FlushDataCache(const void*, u32) { return 0; }
extern "C" void gspWaitForEvent(GSPGPU_Event id, bool) { if (id == GSPGPU_EVENT_VBlank0 || id == GSPGPU_EVENT_VBlank1) shim::gfx_vblank_wait(); }
extern "C" Result romfsInit(void) { return -1; } // assets come from the data directory
extern "C" Result romfsExit(void) { return 0; }
extern "C" Result cfguInit(void) { return 0; }
extern "C" void cfguExit(void) {}
extern "C" Result CFGU_GetSystemModel(u8* model) { if (model) *model = 2; return 0; } // CFG_MODEL_N3DS
extern "C" Result APT_SetAppCpuTimeLimit(u32) { return 0; }
extern "C" Result APT_GetAppCpuTimeLimit(u32* percent) { if (percent) *percent = 80; return 0; }
extern "C" void aptHook(aptHookCookie*, aptHookFn, void*) {}
extern "C" void aptUnhook(aptHookCookie*) {}
extern "C" bool aptMainLoop(void) { return shim::platform_pump_events(); }
extern "C" void aptEventHandler(void*) {}
extern "C" PrintConsole* consoleInit(gfxScreen_t, PrintConsole*) { return nullptr; }

// ---------------------------------------------------------------- hid
static u32 g_keysHeld = 0, g_keysDown = 0, g_keysUp = 0, g_keysRepeat = 0, g_keysPrev = 0;
static u32 g_repeatDelay = 10, g_repeatInterval = 5, g_repeatCounter = 0;
static circlePosition g_circle{};
static SDL_Gamepad* g_pad = nullptr;
static u32 g_padRescanFrames = 0;
extern "C" Result hidInit(void) { return 0; }
extern "C" void hidExit(void) {}
extern "C" void hidSetRepeatParameters(u32 delay, u32 interval) { g_repeatDelay = delay; g_repeatInterval = interval; }
static void open_gamepad() {
  if (g_pad) return;
  int count = 0;
  SDL_JoystickID* ids = SDL_GetGamepads(&count);
  if (ids) {
    for (int i = 0; i < count && !g_pad; ++i) g_pad = SDL_OpenGamepad(ids[i]);
    SDL_free(ids);
  }
  if (g_pad) SHIM_LOG("[hid] gamepad: %s", SDL_GetGamepadName(g_pad));
}

// ---------------------------------------------------------------- button layout (controls.txt)
// ports/mkw3ds/controls.txt: "action = button [button...]" per line. Buttons are the handheld's
// physical buttons; actions are the game's. Missing file or lines keep the defaults below.
enum Phys { P_CROSS, P_CIRCLE, P_TRIANGLE, P_SQUARE, P_L1, P_R1, P_L2, P_R2, P_SELECT, P_START, P_MENU, P_L3, P_R3, P_UP, P_DOWN, P_LEFT, P_RIGHT, P_COUNT };
struct Binding { int phys; u32 keys; };
static std::vector<Binding> g_bindings;
static bool g_controlsLoaded = false, g_driftAddsGas = false;
static bool phys_pressed(int p) {
  switch (p) {
    case P_CROSS: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_SOUTH);
    case P_CIRCLE: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_EAST);
    case P_TRIANGLE: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_NORTH);
    case P_SQUARE: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_WEST);
    case P_L1: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_LEFT_SHOULDER);
    case P_R1: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER);
    case P_L2: return SDL_GetGamepadAxis(g_pad, SDL_GAMEPAD_AXIS_LEFT_TRIGGER) > 16000;
    case P_R2: return SDL_GetGamepadAxis(g_pad, SDL_GAMEPAD_AXIS_RIGHT_TRIGGER) > 16000;
    case P_SELECT: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_BACK);
    case P_START: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_START);
    case P_MENU: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_GUIDE);
    case P_L3: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_LEFT_STICK);
    case P_R3: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_RIGHT_STICK);
    case P_UP: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_DPAD_UP);
    case P_DOWN: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_DPAD_DOWN);
    case P_LEFT: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_DPAD_LEFT);
    case P_RIGHT: return SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_DPAD_RIGHT);
  }
  return false;
}
static int phys_from_name(std::string n) {
  for (char& c : n) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  struct { const char* name; int p; } names[] = {
      {"cross", P_CROSS}, {"bottom", P_CROSS}, {"b", P_CROSS}, {"circle", P_CIRCLE}, {"a", P_CIRCLE}, {"triangle", P_TRIANGLE}, {"top", P_TRIANGLE}, {"x", P_TRIANGLE},
      {"square", P_SQUARE}, {"y", P_SQUARE}, {"l1", P_L1}, {"l", P_L1}, {"r1", P_R1}, {"r", P_R1}, {"l2", P_L2}, {"r2", P_R2}, {"select", P_SELECT},
      {"start", P_START}, {"menu", P_MENU}, {"l3", P_L3}, {"r3", P_R3}, {"up", P_UP}, {"down", P_DOWN}, {"left", P_LEFT}, {"right", P_RIGHT}};
  for (auto& e : names) if (n == e.name) return e.p;
  return -1;
}
static void load_controls() {
  if (g_controlsLoaded) return;
  g_controlsLoaded = true;
  struct Action { const char* name; u32 keys; std::vector<int> phys; };
  std::vector<Action> actions = {
      {"gas", KEY_A, {P_CROSS}}, {"brake", KEY_B, {P_CIRCLE}}, {"trick", KEY_X, {P_TRIANGLE}}, {"wheelie", KEY_Y, {P_SQUARE}},
      {"item", KEY_L, {P_L1, P_L2}}, {"drift", KEY_R, {P_R1, P_R2}}, {"pause", KEY_START, {P_START}}, {"speedometer", KEY_SELECT, {P_SELECT}}, {"rearview", KEY_CSTICK_UP, {}}, {"firstperson", KEY_CSTICK_DOWN, {P_R3}},
      {"dpad_up", KEY_DUP, {P_UP}}, {"dpad_down", KEY_DDOWN, {P_DOWN}}, {"dpad_left", KEY_DLEFT, {P_LEFT}}, {"dpad_right", KEY_DRIGHT, {P_RIGHT}}};
  std::string path = std::string(shim::platform_data_dir()) + "/controls.txt";
  if (FILE* f = std::fopen(path.c_str(), "r")) {
    char line[256];
    while (std::fgets(line, sizeof line, f)) {
      std::string l(line);
      if (auto h = l.find('#'); h != std::string::npos) l.resize(h);
      const auto eq = l.find('=');
      if (eq == std::string::npos) continue;
      std::string key = l.substr(0, eq), val = l.substr(eq + 1);
      auto trim = [](std::string& t) { while (!t.empty() && std::isspace(static_cast<unsigned char>(t.back()))) t.pop_back(); size_t i = 0; while (i < t.size() && std::isspace(static_cast<unsigned char>(t[i]))) ++i; t.erase(0, i); };
      trim(key); for (char& c : key) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
      if (key == "drift_adds_gas") { trim(val); g_driftAddsGas = val == "yes" || val == "1" || val == "true"; continue; }
      for (Action& a : actions) if (key == a.name) {
        a.phys.clear();
        for (char& c : val) if (c == ',') c = ' ';
        size_t i = 0;
        while (i < val.size()) {
          while (i < val.size() && std::isspace(static_cast<unsigned char>(val[i]))) ++i;
          size_t j = i; while (j < val.size() && !std::isspace(static_cast<unsigned char>(val[j]))) ++j;
          if (j > i) { const int p = phys_from_name(val.substr(i, j - i)); if (p >= 0) a.phys.push_back(p); else SHIM_LOG("[hid] controls.txt: unknown button '%s'", val.substr(i, j - i).c_str()); }
          i = j;
        }
      }
    }
    std::fclose(f);
    SHIM_LOG("[hid] controls.txt loaded");
  }
  for (const Action& a : actions) for (int p : a.phys) g_bindings.push_back({p, a.keys});
}
void shim::input_update() {
  if (!g_pad && ++g_padRescanFrames % 60 == 1) open_gamepad();
  u32 keys = 0;
  g_circle = {};
  const bool* kb = SDL_GetKeyboardState(nullptr);
  if (g_pad) {
    load_controls();
    for (const Binding& bd : g_bindings) if (phys_pressed(bd.phys)) keys |= bd.keys;
    if (g_driftAddsGas && (keys & KEY_R)) keys |= KEY_A;
    const int ax = SDL_GetGamepadAxis(g_pad, SDL_GAMEPAD_AXIS_LEFTX), ay = SDL_GetGamepadAxis(g_pad, SDL_GAMEPAD_AXIS_LEFTY);
    g_circle.dx = static_cast<s16>(ax * 156 / 32767);
    g_circle.dy = static_cast<s16>(-ay * 156 / 32767);
    // stick directions with hysteresis (on past 70, off under 40) so a stick resting near the
    // threshold does not flicker into repeated presses
    static u32 stickDirs = 0;
    auto dir = [&](u32 bit, int v) { if (v > 70) stickDirs |= bit; else if (v < 40) stickDirs &= ~bit; };
    dir(KEY_CPAD_RIGHT, g_circle.dx); dir(KEY_CPAD_LEFT, -g_circle.dx); dir(KEY_CPAD_UP, g_circle.dy); dir(KEY_CPAD_DOWN, -g_circle.dy);
    keys |= stickDirs;
    // Handhelds without sticks (RG34XX): the d-pad also drives the circle pad when the stick rests.
    static const bool dpadSteer = !std::getenv("MKW_DPAD_STEER") || std::atoi(std::getenv("MKW_DPAD_STEER")) != 0;
    if (dpadSteer && std::abs(ax) < 8000 && std::abs(ay) < 8000) {
      // The d-pad becomes the circle pad: its own bits are dropped, or holding it to steer would
      // also trigger the game's d-pad tricks/wheelies. Tricks: X/Y (+ direction) or R on ramps.
      if (keys & KEY_DLEFT) { g_circle.dx = -156; keys |= KEY_CPAD_LEFT; }
      if (keys & KEY_DRIGHT) { g_circle.dx = 156; keys |= KEY_CPAD_RIGHT; }
      if (keys & KEY_DUP) { g_circle.dy = 156; keys |= KEY_CPAD_UP; }
      if (keys & KEY_DDOWN) { g_circle.dy = -156; keys |= KEY_CPAD_DOWN; }
      keys &= ~u32(KEY_DLEFT | KEY_DRIGHT | KEY_DUP | KEY_DDOWN);
    }
  }
  if (g_pad) {
    // Quit: Menu + Start, or Select + Start (no gptokeyb: it injected keys that quit the game)
    const bool start = SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_START);
    if (start && (SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_GUIDE) || SDL_GetGamepadButton(g_pad, SDL_GAMEPAD_BUTTON_BACK))) shim::platform_request_quit();
    // Diagnostics: the first presses of each raw button, with the name the mapping gives it
    static unsigned logged = 0;
    static bool rawPrev[32] = {};
    if (SDL_Joystick* js = SDL_GetGamepadJoystick(g_pad)) {
      const int n = std::min(32, SDL_GetNumJoystickButtons(js));
      for (int i = 0; i < n; ++i) {
        const bool now = SDL_GetJoystickButton(js, i);
        if (now && !rawPrev[i] && logged < 80) {
          ++logged;
          const char* name = "unmapped";
          for (int gb = 0; gb < SDL_GAMEPAD_BUTTON_COUNT; ++gb) {
            int count = 0;
            SDL_GamepadBinding** binds = SDL_GetGamepadBindings(g_pad, &count);
            for (int k = 0; binds && k < count; ++k)
              if (binds[k]->input_type == SDL_GAMEPAD_BINDTYPE_BUTTON && binds[k]->input.button == i && binds[k]->output_type == SDL_GAMEPAD_BINDTYPE_BUTTON && binds[k]->output.button == gb)
                name = SDL_GetGamepadStringForButton(static_cast<SDL_GamepadButton>(gb));
            SDL_free(binds);
          }
          SHIM_LOG("[hid] raw button %d pressed -> %s", i, name);
        }
        rawPrev[i] = now;
      }
    }
  }
  if (kb && !g_pad) { // host testing on a keyboard
    if (kb[SDL_SCANCODE_Z]) keys |= KEY_A; if (kb[SDL_SCANCODE_X]) keys |= KEY_B; if (kb[SDL_SCANCODE_A]) keys |= KEY_Y; if (kb[SDL_SCANCODE_S]) keys |= KEY_X;
    if (kb[SDL_SCANCODE_RETURN]) keys |= KEY_START; if (kb[SDL_SCANCODE_RSHIFT]) keys |= KEY_SELECT;
    if (kb[SDL_SCANCODE_Q]) keys |= KEY_L; if (kb[SDL_SCANCODE_W]) keys |= KEY_R;
    if (kb[SDL_SCANCODE_UP]) { keys |= KEY_DUP | KEY_CPAD_UP; g_circle.dy = 156; }
    if (kb[SDL_SCANCODE_DOWN]) { keys |= KEY_DDOWN | KEY_CPAD_DOWN; g_circle.dy = -156; }
    if (kb[SDL_SCANCODE_LEFT]) { keys |= KEY_DLEFT | KEY_CPAD_LEFT; g_circle.dx = -156; }
    if (kb[SDL_SCANCODE_RIGHT]) { keys |= KEY_DRIGHT | KEY_CPAD_RIGHT; g_circle.dx = 156; }
  }
  g_keysPrev = g_keysHeld;
  g_keysHeld = keys;
  g_keysDown = keys & ~g_keysPrev;
  g_keysUp = g_keysPrev & ~keys;
  // Held-key repeat (menus). The game sets it in 60 Hz frames; it is timed by the clock here so it
  // does not run faster when the game polls more often than once per 60 Hz frame.
  // MKW_MENU_REPEAT=0 turns it off: one press, one step.
  static const bool repeatOn = !std::getenv("MKW_MENU_REPEAT") || std::atoi(std::getenv("MKW_MENU_REPEAT")) != 0;
  static uint64_t nextRepeat = 0;
  const uint64_t now = SDL_GetTicks();
  if (g_keysDown) { g_keysRepeat = g_keysDown; nextRepeat = now + g_repeatDelay * 1000ull / 60; }
  else if (keys && repeatOn && now >= nextRepeat) { g_keysRepeat = keys; nextRepeat = now + std::max<u32>(g_repeatInterval, 1) * 1000ull / 60; }
  else g_keysRepeat = 0;
}
extern "C" void hidScanInput(void) { shim::input_update(); }
extern "C" u32 hidKeysHeld(void) { return g_keysHeld; }
extern "C" u32 hidKeysDown(void) { return g_keysDown; }
extern "C" u32 hidKeysDownRepeat(void) { return g_keysRepeat; }
extern "C" u32 hidKeysUp(void) { return g_keysUp; }
extern "C" void hidTouchRead(touchPosition* pos) { if (pos) *pos = {}; }
extern "C" void hidCircleRead(circlePosition* pos) { if (pos) *pos = g_circle; }
extern "C" void hidAccelRead(accelVector* v) { if (v) *v = {}; }
extern "C" void hidGyroRead(angularRate* r) { if (r) *r = {}; }

// ---------------------------------------------------------------- shader binary
// The PICA shader blob is not used; DVLB_ParseFile hands back a descriptor whose DVLE entries
// select the GLSL programs (0 = scene, 1 = NW4R EF particles). Uniform names map to the register
// layout the GLSL expects (c3d.cpp).
extern "C" DVLB_s* DVLB_ParseFile(u32* shbinData, u32 shbinSize) {
  (void)shbinData; (void)shbinSize;
  auto* dvlb = static_cast<DVLB_s*>(std::calloc(1, sizeof(DVLB_s)));
  dvlb->numDVLE = 2;
  dvlb->DVLE = static_cast<DVLE_s*>(std::calloc(2, sizeof(DVLE_s)));
  for (u32 i = 0; i < 2; ++i) { dvlb->DVLE[i].type = VERTEX_SHDR; dvlb->DVLE[i].mainOffset = i; }
  return dvlb;
}
extern "C" void DVLB_Free(DVLB_s* dvlb) { if (dvlb) { std::free(dvlb->DVLE); std::free(dvlb); } }
extern "C" Result shaderProgramInit(shaderProgram_s* program) { std::memset(program, 0, sizeof(*program)); return 0; }
extern "C" Result shaderProgramFree(shaderProgram_s* program) {
  std::free(program->vertexShader); std::free(program->geometryShader); std::memset(program, 0, sizeof(*program)); return 0;
}
extern "C" Result shaderProgramSetVsh(shaderProgram_s* program, DVLE_s* dvle) {
  auto* inst = static_cast<shaderInstance_s*>(std::calloc(1, sizeof(shaderInstance_s)));
  inst->dvle = dvle; program->vertexShader = inst; return 0;
}
extern "C" Result shaderProgramSetGsh(shaderProgram_s*, DVLE_s*, u8) { return -1; }
extern "C" Result shaderInstanceInit(shaderInstance_s* si, DVLE_s* dvle) { si->dvle = dvle; return 0; }
extern "C" Result shaderInstanceFree(shaderInstance_s*) { return 0; }
extern "C" Result shaderInstanceSetBool(shaderInstance_s*, int, bool) { return 0; }
extern "C" Result shaderInstanceGetBool(shaderInstance_s*, int, bool*) { return 0; }
int shim_uniform_location(int program, const char* name); // c3d.cpp
extern "C" s8 shaderInstanceGetUniformLocation(shaderInstance_s* si, const char* name) {
  const int program = si && si->dvle ? static_cast<int>(si->dvle->mainOffset) : 0;
  return static_cast<s8>(shim_uniform_location(program, name));
}
extern "C" Result dspInit(void) { return 0; }
extern "C" void dspExit(void) {}
extern "C" Result DSP_InvalidateDataCache(const void*, u32) { return 0; }
extern "C" PrintConsole* consoleGetDefault(void) { static PrintConsole c{}; return &c; }
extern "C" Result APT_CheckNew3DS(bool* out) { if (out) *out = true; return 0; }
extern "C" Result CFGU_GetModelNintendo2DS(u8* value) { if (value) *value = 1; return 0; } // 1 = not a 2DS
extern "C" Result CFGU_GetConfigInfoBlk2(u32 size, u32 blkID, void* outData) {
  // blkID 0xA0000 = username (UTF-16), 0x50001 = backlight... answer zeros
  if (outData) std::memset(outData, 0, size);
  (void)blkID;
  return 0;
}

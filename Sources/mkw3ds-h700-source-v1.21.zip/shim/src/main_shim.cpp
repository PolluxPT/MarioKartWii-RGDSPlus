// Process entry: bring the platform up, then run the game's own main() (compiled as mkw_app_main).
#include "shim.hpp"
#include <cstdio>
#include <cstdlib>
int mkw_app_main();
int main(int argc, char** argv) {
  (void)argc; (void)argv;
  std::setvbuf(stdout, nullptr, _IOLBF, 0); // the game's printf goes to the launcher's log: keep it in order with stderr
  if (!shim::platform_init()) { std::fprintf(stderr, "platform init failed\n"); return 1; }
  const int rc = mkw_app_main();
  shim::ndsp_shutdown();
  shim::platform_shutdown();
  return rc;
}

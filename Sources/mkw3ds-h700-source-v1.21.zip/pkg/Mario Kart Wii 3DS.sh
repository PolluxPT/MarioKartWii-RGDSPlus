#!/bin/bash
# Mario Kart Wii 3DS remake (MiniBandit/MKW-3DS) running natively on H700 muOS through a
# 3DS compatibility layer. Port: Matrioshka Brain. You build the game files yourself on a PC
# from your own USA (RMCE01) disc with the builder zip, then copy them into ports/mkw3ds/.

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}
if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR="/$directory/ports/mkw3ds"
cd "$GAMEDIR" || exit 1
> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1
echo "[launcher] $(date) GAMEDIR=$GAMEDIR CFW=$CFW_NAME DEVICE=$DEVICE_NAME ${DISPLAY_WIDTH}x${DISPLAY_HEIGHT}"

say() { echo "[launcher] $*"; command -v pm_message >/dev/null 2>&1 && pm_message "$*"; }

# ---- the game files you built on your PC ----
if [ ! -f "$GAMEDIR/3ds/mkw-3ds/content.txt" ] || [ ! -f "$GAMEDIR/3ds/mkw-3ds/Race/Common.szs" ]; then
  say "Game files missing: build them on your PC (builder zip, USA disc) and copy the 3ds folder into ports/mkw3ds/"
  sleep 8; exit 1
fi

# ---- bundled glibc: the binary's interpreter is /tmp/mkw3ds-ld.so ----
cp -f "$GAMEDIR/libs/ld-linux-aarch64.so.1" /tmp/mkw3ds-ld.so && chmod +x /tmp/mkw3ds-ld.so
GAME_LIBS="$GAMEDIR/libs:/usr/lib:/lib:/usr/lib/aarch64-linux-gnu"

# CPU: performance governor while the game runs (restored on exit).
GOV_FILE=/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
OLD_GOV=$(cat $GOV_FILE 2>/dev/null)
[ -n "$OLD_GOV" ] && echo performance > $GOV_FILE 2>/dev/null && echo "[launcher] cpu governor: $OLD_GOV -> performance"

export HOME="$GAMEDIR"
export XDG_DATA_HOME="$GAMEDIR"
# SDL3 pad mapping for muOS (same physical layout as muOS's own, renumbered for SDL3's key order).
MKW_PAD="19000000010000000100000000010000,muOS-Keys,a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,back:b6,start:b7,guide:b8,leftstick:b9,lefttrigger:b10,righttrigger:b11,rightstick:b12,dpup:h0.1,dpleft:h0.8,dpright:h0.2,dpdown:h0.4,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
export SDL_GAMECONTROLLERCONFIG="$MKW_PAD"
export SDL_JOYSTICK_DEVICE=/dev/input/event1
export MKW_DATA_DIR="$GAMEDIR"            # sdmc:/ -> ports/mkw3ds/
export MKW_LOG_FILE="$GAMEDIR/mkw3ds.log" # the game's own log (also in log.txt)
export MKW_FB_WIDTH=${MKW_FB_WIDTH:-$DISPLAY_WIDTH}
export MKW_FB_HEIGHT=${MKW_FB_HEIGHT:-$DISPLAY_HEIGHT}
# Screen: the game fills the display. env.txt can set MKW_LAYOUT=fit (keep the 3DS shape)
# and MKW_BOTTOM=1 (also draw the 3DS bottom screen: map + standings; costs speed).
# Button layout: controls.txt (made from controls.default.txt once; your edits are kept on updates)
[ -f "$GAMEDIR/controls.txt" ] || cp -f "$GAMEDIR/controls.default.txt" "$GAMEDIR/controls.txt"
# Settings (sharpness, layout): settings.txt, made from settings.default.txt once
[ -f "$GAMEDIR/settings.txt" ] || cp -f "$GAMEDIR/settings.default.txt" "$GAMEDIR/settings.txt"
set -a; . "$GAMEDIR/settings.txt"; set +a
echo "[launcher] settings: scale=$MKW_SCALE layout=$MKW_LAYOUT bottom=$MKW_BOTTOM"
[ -f "$GAMEDIR/env.txt" ] && . "$GAMEDIR/env.txt"   # optional overrides for testing

# No gptokeyb: the game reads the pad itself (gptokeyb's injected keys quit it). Quit = Menu+Start or Select+Start.
pm_platform_helper "$GAMEDIR/mkw3ds" >/dev/null 2>&1
LD_LIBRARY_PATH="$GAME_LIBS" ./mkw3ds
echo "[launcher] exit code $?"
[ -n "$OLD_GOV" ] && echo "$OLD_GOV" > $GOV_FILE 2>/dev/null
rm -f /tmp/mkw3ds-ld.so
pm_finish

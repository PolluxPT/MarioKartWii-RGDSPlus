Mario Kart Wii 3DS remake - H700 (muOS) port
=============================================

What this is
  The MKW-3DS remake (github.com/MiniBandit/MKW-3DS) running natively on the
  RG34XX-SP / other H700 handhelds. A small "3DS compatibility layer" translates
  the 3DS graphics, sound and controls to the handheld. No emulator involved.

Two parts
  1. This port (ports/mkw3ds + "Mario Kart Wii 3DS.sh") - the program.
  2. The game files - you make them ONCE on your PC with the builder zip and
     your own USA Mario Kart Wii disc (RMCE01). They cannot be downloaded.

Install
  1. Copy "Mario Kart Wii 3DS.sh" and the "mkw3ds" folder into /ROMS/PORTS
     (or wherever your other PortMaster ports live).
  2. On the PC: unzip the builder, follow its README-H700.txt. It ends with a
     folder   build/release/sd-card/3ds
  3. Copy that whole "3ds" folder into ports/mkw3ds/ on the SD card, so you have
         ports/mkw3ds/3ds/mkw-3ds/content.txt
         ports/mkw3ds/3ds/mkw-3ds/Race/Common.szs   (and lots more)
  4. Launch "Mario Kart Wii 3DS" from the Ports list.

Controls (positions: bottom / right / top / left face button)
  D-pad or stick ... steer (and move in menus)
  Bottom (Cross) ... accelerate / confirm
  Right (Circle) ... brake, reverse / back
  R1 or R2 ......... while accelerating: hop and drift (hold). Without gas: brake
  L1 or L2 ......... use item (only when you are holding one)
  Top / Left ....... trick when airborne off a ramp (with a direction) / bike wheelie
  Start ............ pause
  Select ........... speedometer, timer and mini map on/off
  L3 (stick click) . hold to look behind you
  R3 (stick click) . switch between normal and first-person view
  Menu + Start or Select + Start ..... quit

Changing the buttons
  Edit ports/mkw3ds/controls.txt (any text editor, or muOS's file manager).
  Instructions are inside it. Delete the file to get the original layout back.

Settings (sharpness, screen layout)
  Edit ports/mkw3ds/settings.txt:
     MKW_SCALE=1      picture sharpness: 1 (3DS, fastest), 1.5, 2 (sharpest)
     MKW_LAYOUT=full  full = fill the screen, fit = keep the 3DS shape
     MKW_BOTTOM=0     1 = also show the 3DS bottom screen in a corner
     MKW_MINIMAP=1    small course map with everyone on it (0 = off)
     MKW_HUD_Y=8      how far down the top of the race HUD sits (0 = 3DS original)
     MKW_MENU_REPEAT=1  holding a direction in menus keeps moving (0 = one step per press)
     MKW_FP_STYLE=hands  first person: hands (arms on the wheel), wheel, or clean
     MKW_FP_HANDS=0.5    hands style: lower = more forearm, higher = just hands
     MKW_FP_UP=75 MKW_FP_FWD=-45 MKW_FP_TILT=180   first-person camera position
  With the bottom screen off, the race timer is shown above the lap counter.
  (settings.txt is only created once; add new lines to it yourself.)

If it does not start
  Read ports/mkw3ds/log.txt (and mkw3ds.log). The most common message is
  "Game files missing" - see Install step 3. Send me the log.txt.

Not in this version
  Online play and 100cc/50cc (the remake itself only does 150cc), 3D effect,
  texture mipmaps, the 3DS's exact audio resampling.

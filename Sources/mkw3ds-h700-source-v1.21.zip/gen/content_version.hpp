#pragma once
#define MKW_CONTENT "cf69fd08237c86f0faa555dbecece969"
#define MKW_CONTENT_WINDOWS_LEGACY "0a4c701b08480f9ca6a85abcf4c55f31"
#define MKW_VERSION "0.5.2-h700"
#define MKW_WHATS_NEW "H700 port"
#define MKW_QUICK_UPDATE 0

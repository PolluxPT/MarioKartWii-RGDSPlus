#pragma once
#include <cstdint>
// H700: the PICA shader binary is replaced by GLSL programs selected through DVLB_ParseFile; this
// placeholder keeps the app's loader call sites intact.
alignas(4) static const uint8_t mkw_shader[] = {'G','L','S','L', 2, 0, 0, 0};

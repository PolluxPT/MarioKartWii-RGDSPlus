#pragma once
// H700 port helpers standing in for ARM11 builtins.
static inline unsigned mkw_get_fpscr() {
#if defined(__aarch64__)
  unsigned long v; asm volatile("mrs %0, fpcr" : "=r"(v)); return static_cast<unsigned>(v);
#else
  return 0;
#endif
}
static inline void mkw_set_fpscr(unsigned v) {
#if defined(__aarch64__)
  unsigned long x = v; asm volatile("msr fpcr, %0" ::"r"(x));
#else
  (void)v;
#endif
}
